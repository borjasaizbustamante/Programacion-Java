package factoriaDeVentanas.factoria.exception;

/**
 * Excepcion propia: Me pides un Panel que no existe 
 */
public class FactoryException extends Exception{

	private static final long serialVersionUID = -3186242211375152625L;

    public FactoryException() {
        super();
    }
    
	public FactoryException(String message) {
        super(message);
    }
	
    public FactoryException(Throwable cause) {
        super(cause);
    }
}
