package factoriaDeVentanas.factoria;

import javax.swing.JPanel;

import factoriaDeVentanas.factoria.exception.FactoryException;
import factoriaDeVentanas.factoria.panels.JPanelBlue;
import factoriaDeVentanas.factoria.panels.JPanelGreen;
import factoriaDeVentanas.factoria.panels.JPanelRed;

/**
 * Factory Pattern. Cuando necesitas un JPanel, se lo pides a esta clase usando
 * sus atributos estaticos. Si le pides un JPanel que no existe, te genera una
 * FactoryException
 */
public class PanelFactory {

	public static final String PANEL_ROJO = "PANEL_ROJO";
	public static final String PANEL_AZUL = "PANEL_AZUL";
	public static final String PANEL_VERDE = "PANEL_VERDE";

	/**
	 * Retorna el JPanel que le pides por parametro. Genera una FactoryException si
	 * el JPanel no existe
	 * 
	 * @param panelName
	 * @return el JPanel
	 * @throws FactoryException
	 */
	public static JPanel getJPanel(String panelName) throws FactoryException {
		switch (panelName) {
		case PANEL_ROJO:
			return new JPanelRed();
		case PANEL_AZUL:
			return new JPanelBlue();
		case PANEL_VERDE:
			return new JPanelGreen();
		default:
			throw new FactoryException(panelName + " no es un DBDUtils valido");
		}
	}
}
