package factoriaDeVentanas.factoria.panels;

import java.awt.Color;

import javax.swing.JPanel;

/**
 * Una JPanel verde
 */
public class JPanelGreen extends JPanel{

	private static final long serialVersionUID = 5411048255199458608L;

	public JPanelGreen () {
		super();
		this.setBounds(26, 21, 356, 156);
		this.setBackground(Color.green);
		this.setLayout(null);
	}
}
