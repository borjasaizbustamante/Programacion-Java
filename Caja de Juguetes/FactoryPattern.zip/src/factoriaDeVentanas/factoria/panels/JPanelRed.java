package factoriaDeVentanas.factoria.panels;

import java.awt.Color;

import javax.swing.JPanel;

/**
 * Una JPanel rojo
 */
public class JPanelRed extends JPanel{

	private static final long serialVersionUID = 5411048255199458608L;

	public JPanelRed () {
		super();
		this.setBounds(26, 21, 356, 156);
		this.setBackground(Color.red);
		this.setLayout(null);
	}
}
