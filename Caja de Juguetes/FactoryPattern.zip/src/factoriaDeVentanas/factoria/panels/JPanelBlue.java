package factoriaDeVentanas.factoria.panels;

import java.awt.Color;

import javax.swing.JPanel;

/**
 * Una JPanel azul
 */
public class JPanelBlue extends JPanel{

	private static final long serialVersionUID = 5411048255199458608L;

	public JPanelBlue () {
		super();
		this.setBounds(26, 21, 356, 156);
		this.setBackground(Color.blue);
		this.setLayout(null);
	}
}
