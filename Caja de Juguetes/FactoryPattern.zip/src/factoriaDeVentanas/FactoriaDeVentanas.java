package factoriaDeVentanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import factoriaDeVentanas.factoria.PanelFactory;
import factoriaDeVentanas.factoria.exception.FactoryException;

import java.awt.event.ActionListener;

/**
 * Esta clase pide a la factoria que le vaya dando JPanel de diferentes tipos.
 * Cada vez que cambia de panel, destruye el anterior.
 * 
 * Lo interesante de este ejemplo es el Patron Factory. Le pedimos a la clase
 * PanelFactory que nos vaya generando los objetos del tipo que nos interesa en
 * cada momento. La gracia es que podemos añadir cuantos paneles diferentes
 * queramos con tan solo añadir una nuevo y modificar un poco la clase
 * Panelfactory.
 */
public class FactoriaDeVentanas {

	private JFrame frame = null;
	private JButton jButtonPanel1 = null;
	private JButton jButtonPanel2 = null;
	private JButton jButtonPanel3 = null;
	private JPanel jpanel = null;

	public FactoriaDeVentanas() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		// Padimos al factory el panel inicial
		try {
			jpanel = PanelFactory.getJPanel(PanelFactory.PANEL_ROJO);
			frame.getContentPane().add(jpanel);
			frame.revalidate();
			frame.repaint();
		} catch (FactoryException e1) {
			System.out.println("No se ha podido mostrar el jPanel");
		}

		jButtonPanel1 = new JButton("Panel 1");
		jButtonPanel1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				swapJPanel(PanelFactory.PANEL_ROJO);
			}
		});
		jButtonPanel1.setBounds(42, 213, 89, 23);
		frame.getContentPane().add(jButtonPanel1);

		jButtonPanel2 = new JButton("Panel 2");
		jButtonPanel2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				swapJPanel(PanelFactory.PANEL_AZUL);
			}
		});
		jButtonPanel2.setBounds(162, 213, 89, 23);
		frame.getContentPane().add(jButtonPanel2);

		jButtonPanel3 = new JButton("Panel 3");
		jButtonPanel3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				swapJPanel(PanelFactory.PANEL_VERDE);
			}
		});
		jButtonPanel3.setBounds(293, 213, 89, 23);
		frame.getContentPane().add(jButtonPanel3);
	}

	/**
	 * Cambia el panel por el que le indicamos por parametro
	 * 
	 * @param jPanel
	 */
	private void swapJPanel(String jPanel) {
		try {
			// Cambiamos de panel por otro que sacamos del factory
			frame.getContentPane().remove(jpanel);
			jpanel = PanelFactory.getJPanel(jPanel);
			frame.getContentPane().add(jpanel);
			frame.repaint();
		} catch (FactoryException e1) {
			System.out.println("No se ha podido mostrar el jPanel");
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FactoriaDeVentanas window = new FactoriaDeVentanas();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
