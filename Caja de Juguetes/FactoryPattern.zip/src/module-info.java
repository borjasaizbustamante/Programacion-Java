module FactoryPattern {
	requires java.desktop;
}