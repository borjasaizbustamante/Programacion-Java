module CuteWebBrowser {
	requires java.desktop;
}