package navegador.engine;

import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Clase que busca en Google
 */
public class BuscadorGoogle {

	private static final String SCHEMA = "https://";
	private static final String SERVER = "www.google.es/search?q=";

	/**
	 * Lanza una peticion Http tipo GET al buscador de google. Retorna la pagina web
	 * en codigo html; el error del servidor de la RAE; o NULL si algo sale mal
	 * 
	 * @param palabra
	 * @return la pagina web de respuesta, el error o null
	 */
	public String buscar(String palabra) {
		String ret = null;
		try {
			// Montamos la direccion del recurso
			String resource = URLEncoder.encode(palabra, StandardCharsets.UTF_8.name());
			String direccion = SCHEMA + SERVER + resource;

			// Contruimos y abrimos la conexion
			URL url = new URL(direccion);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("GET");
			httpURLConnection.setRequestProperty("Conetent-type", "text/plain");
			httpURLConnection.setRequestProperty("charset", "utf-8");
			httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");

			// Envio de la peticion y procesamiento del codigo de respuesta HTTP
			int codigoRespuestaHttp = httpURLConnection.getResponseCode();

			// SI es 200 - OK
			StringBuilder respuesta = new StringBuilder();
			if (codigoRespuestaHttp == HttpURLConnection.HTTP_OK) {
				Reader reader = new InputStreamReader(httpURLConnection.getInputStream());
				int myByte;
				while ((myByte = reader.read()) != -1) {
					respuesta.append((char) myByte);
				}

				ret = respuesta.toString();
			} else {
				// Procesa los distintos codigos...
				switch (codigoRespuestaHttp) {

				case HttpURLConnection.HTTP_INTERNAL_ERROR:
					ret = "Servidor respondio: Internal Server Error";
					break;
				case HttpURLConnection.HTTP_NOT_FOUND:
					ret = "Servidor respondio: Not Found";
					break;
				default:
					ret = "Servidor respondio: HTTP Code Error : " + codigoRespuestaHttp;
				}
			}
			httpURLConnection.disconnect();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}
}
