package navegador;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.text.html.HTMLEditorKit;

import navegador.engine.BuscadorGoogle;

import javax.swing.JButton;
import javax.swing.JEditorPane;

/**
 * Clase que lanza peticiones Http para hacer consultas en Google. El resultado
 * de la peticion Http es una pagina html, que se muestra igual (mas o menos)
 * como si fuese un navegador web normal.
 * 
 * No, no muestra todo bien. 
 */
public class CuteWebBrowser {

	private JFrame myCuteBrowser;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CuteWebBrowser window = new CuteWebBrowser();
					window.myCuteBrowser.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CuteWebBrowser() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		myCuteBrowser = new JFrame();
		myCuteBrowser.setResizable(false);
		myCuteBrowser.setTitle("My Cute Little Browser!");
		myCuteBrowser.setBounds(100, 100, 450, 300);
		myCuteBrowser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myCuteBrowser.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Palabra ");
		lblNewLabel.setBounds(10, 11, 60, 14);
		myCuteBrowser.getContentPane().add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(80, 8, 234, 20);
		myCuteBrowser.getContentPane().add(textField);
		textField.setColumns(10);

		JEditorPane jEditorPane = new JEditorPane();
		jEditorPane.setEditorKit(new HTMLEditorKit());
		jEditorPane.setContentType("text/html");
		jEditorPane.setEditable(false);

		JScrollPane jScrollPane = new JScrollPane(jEditorPane);
		jScrollPane.setBounds(10, 37, 414, 199);
		myCuteBrowser.getContentPane().add(jScrollPane);

		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.setBounds(335, 7, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BuscadorGoogle buscadorGoogle = new BuscadorGoogle();
				if (textField.getText().length() != 0) {
					String pagina = buscadorGoogle.buscar(textField.getText());
					if (null == pagina) {
						jEditorPane.setText("<html>Page not found.</html>");
					} else {
						jEditorPane.setText(pagina);
					}
				} else {
					JOptionPane.showMessageDialog(new JFrame(), "Falta la palabra a buscar");
				}
			}
		});
		myCuteBrowser.getContentPane().add(btnNewButton);
	}

}
