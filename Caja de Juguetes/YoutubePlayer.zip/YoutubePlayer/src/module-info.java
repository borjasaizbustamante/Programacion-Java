module YoutubePlayer {
	requires java.desktop;
	requires jlayer;
}