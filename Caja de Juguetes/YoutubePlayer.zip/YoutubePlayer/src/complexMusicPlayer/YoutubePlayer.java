package complexMusicPlayer;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import javazoom.jl.player.Player;
import javax.swing.SwingConstants;

public class YoutubePlayer {

	private static final String THE_IMAGE_FILE = new File("").getAbsolutePath()
			+ "\\src\\complexMusicPlayer\\img\\choco.jpg";

	private static final String THE_MUSIC_PATH = "\\src\\complexMusicPlayer\\music\\";

	private List<String> files = new ArrayList<String>(
			Arrays.asList("FF3-Victory-Fanfare.mp3", "FF3-Victory-Fanfare.mp3", "FF3-Victory-Fanfare.mp3"));
	private int currentSong = 0;

	private JFrame jFrame = null;
	private JTextField textFieldNumCanciones;
	private JTextField textFieldCancionActual;

	private JButton jButtonPlay;
	private JButton jButtonStop;
	private JButton jButtonLast;
	private JButton jButtonPrevious;
	private JButton jButtonNext;
	private JButton jButtonFirst;

	private Player player = null;

	public YoutubePlayer() {
		initialize();
	}

	private void initialize() {
		jFrame = new JFrame();
		jFrame.setTitle("Youtube Player");
		jFrame.setResizable(false);
		jFrame.setBounds(100, 100, 447, 444);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.getContentPane().setLayout(null);

		jButtonPlay = new JButton("PLAY");
		jButtonPlay.setFont(new Font("Verdana Pro Cond", Font.PLAIN, 27));
		jButtonPlay.setEnabled(true);
		jButtonPlay.setBounds(10, 136, 141, 100);
		jButtonPlay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Paramos el reproductor por defecto
				if (player != null) {
					player.close();
				}

				jButtonPlay.setEnabled(false);
				jButtonStop.setEnabled(true);

				new Thread() {
					@Override
					public void run() {
						try {
							String song = new File("").getAbsolutePath() + THE_MUSIC_PATH + files.get(currentSong);
							FileInputStream fileInputStream = new FileInputStream(song);
							player = new Player(fileInputStream);
							player.play();
						} catch (Exception e) {
							// Nothing to see here...
							System.out.println(e);
						}
					}
				}.start();
			}
		});
		jFrame.getContentPane().add(jButtonPlay);

		jButtonStop = new JButton("STOP");
		jButtonStop.setFont(new Font("Verdana Pro Cond", Font.PLAIN, 27));
		jButtonStop.setEnabled(false);
		jButtonStop.setBounds(283, 136, 141, 100);
		jButtonStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (player != null) {
					player.close();
				}

				jButtonPlay.setEnabled(true);
				jButtonStop.setEnabled(false);
			}
		});
		jFrame.getContentPane().add(jButtonStop);

		JPanel jPanelImage = new JPanel();
		jPanelImage.setBounds(161, 136, 109, 100);

		ImageIcon imageIcon = null;
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File(THE_IMAGE_FILE));
			imageIcon = new ImageIcon(
					img.getScaledInstance(jPanelImage.getWidth(), jPanelImage.getHeight(), Image.SCALE_SMOOTH));
		} catch (IOException e) {
			// Nothing to see here...
		}

		JLabel jLabelImage = new JLabel("", imageIcon, JLabel.CENTER);
		jPanelImage.add(jLabelImage);
		jFrame.getContentPane().add(jPanelImage);

		jButtonFirst = new JButton("<<");
		jButtonFirst.setFont(new Font("Dialog", Font.PLAIN, 27));
		jButtonFirst.setEnabled(false);
		jButtonFirst.setBounds(10, 296, 88, 51);
		jButtonFirst.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Paramos el reproductor por defecto
				if (player != null) {
					player.close();
				}

				// Al principio de la lista
				currentSong = 0;
				textFieldCancionActual.setText(currentSong + 1 + "");

				jButtonPlay.setEnabled(true);
				jButtonStop.setEnabled(false);

				jButtonFirst.setEnabled(false);
				jButtonLast.setEnabled(true);
				jButtonPrevious.setEnabled(false);
				jButtonNext.setEnabled(true);
			}
		});
		jFrame.getContentPane().add(jButtonFirst);

		jButtonLast = new JButton(">>");
		jButtonLast.setFont(new Font("Dialog", Font.PLAIN, 27));
		jButtonLast.setEnabled(true);
		jButtonLast.setBounds(336, 296, 88, 51);
		jButtonLast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Paramos el reproductor por defecto
				if (player != null) {
					player.close();
				}

				// Al principio de la lista
				currentSong = files.size() - 1;
				textFieldCancionActual.setText(currentSong + 1 + "");

				jButtonPlay.setEnabled(true);
				jButtonStop.setEnabled(false);

				jButtonFirst.setEnabled(true);
				jButtonLast.setEnabled(false);
				jButtonPrevious.setEnabled(true);
				jButtonNext.setEnabled(false);
			}
		});
		jFrame.getContentPane().add(jButtonLast);

		jButtonPrevious = new JButton("<");
		jButtonPrevious.setFont(new Font("Dialog", Font.PLAIN, 27));
		jButtonPrevious.setEnabled(false);
		jButtonPrevious.setBounds(108, 296, 88, 51);
		jButtonPrevious.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Paramos el reproductor por defecto
				if (player != null) {
					player.close();
				}

				jButtonPlay.setEnabled(true);
				jButtonStop.setEnabled(false);

				jButtonLast.setEnabled(true);
				jButtonNext.setEnabled(true);
				currentSong--;
				if (currentSong > 0) {
					jButtonFirst.setEnabled(true);
					jButtonPrevious.setEnabled(true);
				} else {
					currentSong = 0;
					jButtonFirst.setEnabled(false);
					jButtonPrevious.setEnabled(false);
				}
				textFieldCancionActual.setText(currentSong + 1 + "");
			}
		});
		jFrame.getContentPane().add(jButtonPrevious);

		jButtonNext = new JButton(">");
		jButtonNext.setFont(new Font("Dialog", Font.PLAIN, 27));
		jButtonNext.setEnabled(true);
		jButtonNext.setBounds(238, 296, 88, 51);
		jButtonNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				// Paramos el reproductor por defecto
				if (player != null) {
					player.close();
				}

				jButtonPlay.setEnabled(true);
				jButtonStop.setEnabled(false);

				jButtonFirst.setEnabled(true);
				jButtonPrevious.setEnabled(true);
				currentSong++;
				if (currentSong < files.size() - 1) {
					jButtonLast.setEnabled(true);
					jButtonNext.setEnabled(true);
				} else {
					currentSong = files.size() - 1;
					jButtonLast.setEnabled(false);
					jButtonNext.setEnabled(false);
				}
				textFieldCancionActual.setText(currentSong + 1 + "");
			}
		});
		jFrame.getContentPane().add(jButtonNext);

		textFieldNumCanciones = new JTextField();
		textFieldNumCanciones.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldNumCanciones.setEditable(false);
		textFieldNumCanciones.setText(files.size() + "");
		textFieldNumCanciones.setBounds(10, 66, 96, 20);
		jFrame.getContentPane().add(textFieldNumCanciones);
		textFieldNumCanciones.setColumns(10);

		textFieldCancionActual = new JTextField();
		textFieldCancionActual.setHorizontalAlignment(SwingConstants.CENTER);
		textFieldCancionActual.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textFieldCancionActual.setEditable(false);
		textFieldCancionActual.setColumns(10);
		textFieldCancionActual.setText(currentSong + 1 + "");
		textFieldCancionActual.setBounds(161, 11, 109, 75);

		jFrame.getContentPane().add(textFieldCancionActual);

		JLabel lblNumCanciones = new JLabel("Numero Canciones");
		lblNumCanciones.setBounds(10, 42, 96, 14);
		jFrame.getContentPane().add(lblNumCanciones);

		if (null == files || files.size() == 0) {
			jButtonPlay.setEnabled(false);
			jButtonStop.setEnabled(false);
			jButtonFirst.setEnabled(false);
			jButtonLast.setEnabled(false);
			jButtonPrevious.setEnabled(false);
			jButtonNext.setEnabled(false);
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					YoutubePlayer window = new YoutubePlayer();
					window.jFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
