/**
 * 
 */
/**
 * @author borja
 *
 */
module SimpleMusicPlayer {
	requires java.desktop;
	requires jlayer;
}