package simpleMusicPlayer;

import java.awt.EventQueue;

import javax.swing.JFrame;

import javazoom.jl.player.Player;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.JPanel;
import javax.swing.JLabel;

/**
 * Clase que reproduce una cancion en formato mp3. Para escoger otra, debes
 * cambiar el path en THE_MUSIC_FILE. Puedes detener o reanudar la musica con
 * los botones. Este ejemplo no ofrece reproduccion de video ni nada de eso.
 * 
 * AVISO: Entender el codigo es dificil. Los Hilos en Java (Thread) se dan en 2º
 * de DAM, asi que ni lo intentes. Copia y pega el codigo, y listo.
 */
public class SimpleMusicPlayer {

	public static final String THE_MUSIC_FILE = new File("").getAbsolutePath()
			+ "\\src\\simpleMusicPlayer\\music\\FF3-Victory-Fanfare.mp3";

	public static final String THE_IMAGE_FILE = new File("").getAbsolutePath()
			+ "\\src\\simpleMusicPlayer\\img\\choco.jpg";

	private JFrame frmCutemediaplayer = null;

	private Player player = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SimpleMusicPlayer window = new SimpleMusicPlayer();
					window.frmCutemediaplayer.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SimpleMusicPlayer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCutemediaplayer = new JFrame();
		frmCutemediaplayer.setTitle("Cute Music Player");
		frmCutemediaplayer.setResizable(false);
		frmCutemediaplayer.setBounds(100, 100, 450, 184);
		frmCutemediaplayer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCutemediaplayer.getContentPane().setLayout(null);

		JButton jButtonPlay = new JButton("PLAY");
		jButtonPlay.setFont(new Font("Verdana Pro Cond", Font.PLAIN, 27));
		jButtonPlay.setBounds(10, 34, 141, 100);
		jButtonPlay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				play();
			}
		});
		frmCutemediaplayer.getContentPane().add(jButtonPlay);

		JButton jButtonStop = new JButton("STOP");
		jButtonStop.setFont(new Font("Verdana Pro Cond", Font.PLAIN, 27));
		jButtonStop.setBounds(283, 34, 141, 100);
		jButtonStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stop();
			}
		});
		frmCutemediaplayer.getContentPane().add(jButtonStop);

		JPanel jPanelImage = new JPanel();
		jPanelImage.setBounds(161, 34, 109, 100);

		// Aniadimos la imagen escalada para que quepa en el jPanel
		ImageIcon imageIcon = null;
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File(THE_IMAGE_FILE));
			imageIcon = new ImageIcon(
					img.getScaledInstance(jPanelImage.getWidth(), jPanelImage.getHeight(), Image.SCALE_SMOOTH));

			JLabel jLabelImage = new JLabel("", imageIcon, JLabel.CENTER);
			jPanelImage.add(jLabelImage);
			frmCutemediaplayer.getContentPane().add(jPanelImage);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Hace sonar la cancion
	 */
	private void play() {

		// No intentes entenderlo. Funciona y ya esta

		new Thread() {
			@Override
			public void run() {
				try {
					FileInputStream fileInputStream = new FileInputStream(THE_MUSIC_FILE);
					player = new Player(fileInputStream);
					player.play();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}.start();
	}

	/**
	 * Detiene la musica
	 */
	private void stop() {
		if (player != null) {
			player.close();
		}
	}
}
