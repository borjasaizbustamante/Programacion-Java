package random.groups;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Los alumnos se meten en el Array. El programa primero mezcla los alumnos en
 * el array randomized y luego vas sacando los grupos a mano.  
 */
public class GeneradorDeGrupos {

	public static String[] alumnos = { "Ekaitz Aguilar", "Inigo Aguirre", "Javier Bravo", "Faniel Edgar Caballero",
			"Liher Chamorro", "Aitor Cobo", "Ugaitz Cordero", "Gorka de la Iglesia", "Dayana Fernandez",
			"Javier Gaston", "Lucian Grecianu", "Dennis Hinojal", "Vanesa Klie", "Patrick Macedo", "Akira Sakakibara",
			"Jefferson Santana", "Julio Silva", "Violeta Urien", "Nahikari Vallejo", "Yifei Ye", "Jordy Viracocha",
			"Maria Jose Suarez", "Omaima Erreji" };

	public static String[] randomized = new String[alumnos.length];

	public static void main(String[] args) {

		System.out.println("And the winner is...");
		System.out.println("");
		
		// Mezcla los alumnos
		List<String> list = Arrays.asList(alumnos);
		Collections.shuffle(list);

		System.out.println("G1");
		System.out.println("--");
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		System.out.println(list.get(2));
		System.out.println(list.get(3));
		System.out.println("");

		System.out.println("G2");
		System.out.println("--");
		System.out.println(list.get(4));
		System.out.println(list.get(5));
		System.out.println(list.get(6));
		System.out.println(list.get(7));
		System.out.println("");

		System.out.println("G3");
		System.out.println("--");
		System.out.println(list.get(8));
		System.out.println(list.get(9));
		System.out.println(list.get(10));
		System.out.println("");

		System.out.println("G4");
		System.out.println("--");
		System.out.println(list.get(11));
		System.out.println(list.get(12));
		System.out.println(list.get(13));
		System.out.println("");

		System.out.println("G5");
		System.out.println("--");
		System.out.println(list.get(14));
		System.out.println(list.get(15));
		System.out.println(list.get(16));
		System.out.println("");

		System.out.println("G6");
		System.out.println("--");
		System.out.println(list.get(17));
		System.out.println(list.get(18));
		System.out.println(list.get(19));
		System.out.println("");

		System.out.println("G7");
		System.out.println("--");
		System.out.println(list.get(20));
		System.out.println(list.get(21));
		System.out.println(list.get(22));
		System.out.println("");
	}

}
