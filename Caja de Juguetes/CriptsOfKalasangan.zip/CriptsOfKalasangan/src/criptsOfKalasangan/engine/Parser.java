package criptsOfKalasangan.engine;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import criptsOfKalasangan.engine.beans.Block;
import criptsOfKalasangan.engine.beans.Blocks;
import criptsOfKalasangan.engine.beans.GoTo;
import criptsOfKalasangan.engine.utils.Utils;

/**
 * El parser Json.
 */
public class Parser {

	private static Parser instance = null;

	/**
	 * Constructor negado (Patron Singleton)
	 */
	private Parser() {

	}

	/**
	 * Retorna la unica instancia de Parser (Patron Singleton)
	 * 
	 * @return La unica instancia de Parser
	 */
	public static Parser getInstance() {
		if (null == instance)
			instance = new Parser();
		return instance;
	}

	/**
	 * Retorna los bloques processados del Json, o null si está vacio
	 * 
	 * @return Los bloques processados del Json
	 * @throws IOException    Si hay un error de E/S
	 * @throws ParseException Si hay un error de parseo del Json
	 */
	public Blocks processSeed() throws IOException, ParseException {
		Blocks ret = null;
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(new FileReader(Utils.THE_SEED_FILE));
		List<Block> blocks = processBlocks(parser, jsonObject);
		if (null != blocks) {
			ret = new Blocks();
			ret.setBlocks(blocks);
		}
		return ret;
	}

	/**
	 * Retorna una lista de bloques procesados, o null si no hay
	 * 
	 * @param parser
	 * @param jsonObject
	 * @return Listado de bloques procesados
	 * @throws ParseException Si hay un error de parseo del Json
	 */
	private List<Block> processBlocks(JSONParser parser, JSONObject jsonObject) throws ParseException {
		List<Block> ret = null;
		JSONArray blocks = (JSONArray) jsonObject.get("blocks");
		Block currentBlock = null;
		for (Object block : blocks) {
			if (null == ret) {
				ret = new ArrayList<Block>();
			}
			currentBlock = new Block();
			JSONObject currentBlockJson = (JSONObject) parser.parse(block.toString());
			currentBlock.setAt(Integer.parseInt((String) currentBlockJson.get("at")));
			currentBlock.setImg((String) currentBlockJson.get("img"));
			if (null != (String) currentBlockJson.get("text")){
				currentBlock.setText((String) currentBlockJson.get("text"));
				currentBlock.setAction((String) currentBlockJson.get("action"));
				currentBlock.setIgnore((String) currentBlockJson.get("ignore"));
			} else {
				currentBlock.setText("");
				currentBlock.setAction("");
				currentBlock.setIgnore("");
			}
			
			JSONArray goTosJson = (JSONArray) currentBlockJson.get("goTos");
			if (null != goTosJson) {
				List<GoTo> goTos = processGoTos(parser, goTosJson);
				currentBlock.setGoTos(goTos);
			}
			ret.add(currentBlock);
		}
		return ret;
	}

	/**
	 * Retorna una lista de goTos procesados, o null si no hay
	 * 
	 * @param parser
	 * @param goTosJson
	 * @return Listado de goTos procesados
	 * @throws ParseException Si hay un error de parseo del Json
	 */
	private List<GoTo> processGoTos(JSONParser parser, JSONArray goTosJson) throws ParseException {
		List<GoTo> ret = null;
		GoTo eachGoTo = null;
		for (Object theGoto : goTosJson) {
			if (null == ret) {
				ret = new ArrayList<GoTo>();
			}
			eachGoTo = new GoTo();
			JSONObject currentGotoJson = (JSONObject) parser.parse(theGoto.toString());
			eachGoTo.setDir((String) currentGotoJson.get("dir"));
			eachGoTo.setTo(Integer.parseInt((String) currentGotoJson.get("to")));
			ret.add(eachGoTo);
		}
		return ret;
	}
}
