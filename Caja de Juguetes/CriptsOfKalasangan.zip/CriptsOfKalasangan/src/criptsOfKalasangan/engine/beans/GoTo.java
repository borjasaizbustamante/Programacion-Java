package criptsOfKalasangan.engine.beans;

import java.io.Serializable;
import java.util.Objects;

/**
 * Las opciones de cada bloque
 */
public class GoTo implements Serializable {

	private static final long serialVersionUID = -8337501366632266425L;

	private String dir;
	private int to;
	
	public String getDir() {
		return dir;
	}

	public void setDir(String dir) {
		this.dir = dir;
	}

	public int getTo() {
		return to;
	}

	public void setTo(int to) {
		this.to = to;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dir, to);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GoTo other = (GoTo) obj;
		return Objects.equals(dir, other.dir) && to == other.to;
	}

	@Override
	public String toString() {
		return "GoTo [dir=" + dir + ", to=" + to + "]";
	}
}