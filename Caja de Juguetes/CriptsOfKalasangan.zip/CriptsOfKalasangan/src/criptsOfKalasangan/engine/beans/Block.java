package criptsOfKalasangan.engine.beans;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * Un Bloque
 */
public class Block implements Serializable {

	private static final long serialVersionUID = -578858462965845200L;

	private int at;
	private String img;
	private String text;
	private String action;
	private String ignore;
	private List<GoTo> goTos = null;

	public int getAt() {
		return at;
	}

	public void setAt(int at) {
		this.at = at;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getIgnore() {
		return ignore;
	}

	public void setIgnore(String ignore) {
		this.ignore = ignore;
	}

	public List<GoTo> getGoTos() {
		return goTos;
	}

	public void setGoTos(List<GoTo> goTos) {
		this.goTos = goTos;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(action, at, goTos, ignore, img, text);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Block other = (Block) obj;
		return Objects.equals(action, other.action) && at == other.at && Objects.equals(goTos, other.goTos)
				&& Objects.equals(ignore, other.ignore) && Objects.equals(img, other.img)
				&& Objects.equals(text, other.text);
	}

	@Override
	public String toString() {
		return "Block [at=" + at + ", img=" + img + ", text=" + text + ", action=" + action + ", ignore=" + ignore
				+ ", goTos=" + goTos + "]";
	}
}
