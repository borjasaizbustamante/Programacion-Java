package criptsOfKalasangan.engine.beans;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * El fichero seed.json guardado en memoria
 */
public class Blocks implements Serializable {
	
	private static final long serialVersionUID = -8087936318997287559L;
	
	private List<Block> blocks = null;

	public List<Block> getBlocks() {
		return blocks;
	}

	public void setBlocks(List<Block> blocks) {
		this.blocks = blocks;
	}

	@Override
	public int hashCode() {
		return Objects.hash(blocks);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Blocks other = (Blocks) obj;
		return Objects.equals(blocks, other.blocks);
	}

	@Override
	public String toString() {
		return "Blocks [blocks=" + blocks.toString() + "]";
	}
}
