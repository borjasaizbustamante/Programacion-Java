package criptsOfKalasangan.engine.utils;

import java.io.File;

/**
 * Constantes del proyecto
 */
public class Utils {

	public static final String THE_SEED_FILE = new File("").getAbsolutePath()
			+ "\\src\\criptsOfKalasangan\\seed\\seed.json";
	public static final String THE_MUSIC_FILE = new File("").getAbsolutePath()
			+ "\\src\\criptsOfKalasangan\\music\\Baldur's Gate 2 soundtrack - Battle Score.mp3";
}
