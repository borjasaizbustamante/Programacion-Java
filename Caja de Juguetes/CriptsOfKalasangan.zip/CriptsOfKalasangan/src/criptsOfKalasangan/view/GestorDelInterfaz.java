package criptsOfKalasangan.view;

import java.util.List;

import javax.swing.JOptionPane;

import criptsOfKalasangan.engine.beans.Block;
import criptsOfKalasangan.engine.beans.Blocks;
import criptsOfKalasangan.engine.beans.GoTo;

/**
 * Clase encargada de gestionar la interface
 */
public class GestorDelInterfaz {

	private static GestorDelInterfaz instance = null;

	/**
	 * Constructor negado (Patron Singleton)
	 */
	private GestorDelInterfaz() {

	}

	/**
	 * Retorna la unica instancia de Parser (Patron Singleton)
	 * 
	 * @return La unica instancia de Parser
	 */
	public static GestorDelInterfaz getInstance() {
		if (null == instance)
			instance = new GestorDelInterfaz();
		return instance;
	}
	
	/**
	 * Retorna el bloque inicial
	 * 
	 * @param blocks
	 * @return el bloque inicial
	 */
	public Block getInitialBlock (Blocks blocks) {
		return getBlock (blocks, 0);
	}
	
	/**
	 * Retorna el bloque indicado
	 * 
	 * @param blocks
	 * @param at
	 * @return el bloque 
	 */
	public Block getBlock (Blocks blocks, int at) {
		Block ret = null;
		if ((null != blocks) && (null != blocks.getBlocks())) {
			for (Block block : blocks.getBlocks()) {
				if (block.getAt() == at) {
					ret = block;
					break;
				}
			}
		}
		return ret;
	}
	
	/**
	 * Retorna los goTos del bloque indicado
	 * 
	 * @param blocks
	 * @param at
	 * @return lista de los goTos
	 */
	public List<GoTo> getGoTosAtPosition(Blocks blocks, int at) {
		List<GoTo> ret = null;
		if ((null != blocks) && (null != blocks.getBlocks())) {
			for (Block block : blocks.getBlocks()) {
				if (block.getAt() == at) {
					ret = block.getGoTos();
					break;
				}
			}
		} else {
			JOptionPane.showMessageDialog(null, "El fichero de texto está vacio.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return ret;
	}
}
