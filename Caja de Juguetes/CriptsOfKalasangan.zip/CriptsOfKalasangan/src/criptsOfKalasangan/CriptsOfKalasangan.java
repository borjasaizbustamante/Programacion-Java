package criptsOfKalasangan;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextPane;

import org.json.simple.parser.ParseException;

import criptsOfKalasangan.engine.Parser;
import criptsOfKalasangan.engine.beans.Block;
import criptsOfKalasangan.engine.beans.Blocks;
import criptsOfKalasangan.engine.beans.GoTo;
import criptsOfKalasangan.engine.utils.Utils;
import criptsOfKalasangan.view.GestorDelInterfaz;
import javazoom.jl.player.Player;

/**
 * Clase que permite recorrer un mapa de videojuego. En realidad se hace trampa,
 * pues lo que estamso haciendo es cambiar la imagen del mapa a cada paso que
 * damos. <br>
 * <br>
 * El fichero seed.json contiene la estructura del mapa. Cada "block" es una
 * casilla, que tiene la siguiente estructura:<br>
 * 
 * - "at": el numero de la casilla <br>
 * - "img": el mapa que hay que enseñar <br>
 * - "text": opcional, por si pones algo en esa casilla <br>
 * - "goTos": las direcciones a las que puede ir, indicada por "at". Si la
 * direccion es igual que la casilla en la que estas, los botones de direccion
 * estan deshabilitados.<br>
 * <br>
 * No estan todas las casillas del mapeado... que es un rollo de hacer... <br>
 * Tambien es posible utilizar las teclas de direccion del teclado en vez de
 * pulsar los botones. <br>
 * Hay musica sonando de fondo, que no puede detenerse si no es cerrando la
 * ventana.
 */
public class CriptsOfKalasangan {

	private JFrame frame = null;
	private JPanel imagePanel = null;
	private JButton btnWest = null;
	private JButton btnEast = null;
	private JButton btnNorth = null;
	private JButton btnSouth = null;
	private JButton btnSpace = null;
	private JButton btnEnter = null;
	private JTextPane textPane = null;
	private Player player = null;

	private Blocks blocks = null;
	private int currentBlock = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CriptsOfKalasangan window = new CriptsOfKalasangan();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CriptsOfKalasangan() {
		try {
			blocks = Parser.getInstance().processSeed();
		} catch (IOException | ParseException e) {
			JOptionPane.showMessageDialog(null, "Error en el fichero de texto.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		initialize();

		this.play();

		Block initialBlock = GestorDelInterfaz.getInstance().getInitialBlock(blocks);
		imagePanel = getImagePanel(initialBlock.getImg());
		frame.getContentPane().add(imagePanel);
		textPane.setText(initialBlock.getText());

		btnSpace = new JButton("Accion (ESP) ");
		btnSpace.setEnabled(false);
		btnSpace.setBounds(216, 425, 135, 23);
		frame.getContentPane().add(btnSpace);

		btnEnter = new JButton("Ignorar (ENTER)");
		btnEnter.setEnabled(false);
		btnEnter.setBounds(352, 425, 135, 23);
		frame.getContentPane().add(btnEnter);

		disableAllDirectionButtons();
		enableButtonsForPosition();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("The Cripts Of Kalasangan");
		frame.getContentPane().setLayout(null);

		btnWest = new JButton("West (A)");
		btnWest.setBounds(7, 391, 89, 23);
		btnWest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveTo("west");
			}
		});
		frame.getContentPane().add(btnWest);

		btnEast = new JButton("East (D)");
		btnEast.setBounds(107, 391, 89, 23);
		btnEast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveTo("east");
			}
		});
		frame.getContentPane().add(btnEast);

		btnNorth = new JButton("North (W)");
		btnNorth.setBounds(56, 357, 89, 23);
		btnNorth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveTo("north");
			}
		});
		frame.getContentPane().add(btnNorth);

		btnSouth = new JButton("South (S)");
		btnSouth.setBounds(56, 425, 89, 23);
		btnSouth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveTo("south");
			}
		});

		frame.getContentPane().add(btnSouth);
		frame.setBounds(100, 100, 510, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		textPane = new JTextPane();
		textPane.setFont(new Font("Tahoma", Font.BOLD, 14));
		textPane.setBounds(216, 356, 271, 47);
		frame.getContentPane().add(textPane);

		// Para usar las flechas del teclado
		frame.getContentPane().setFocusable(true);
		frame.getContentPane().addKeyListener((KeyListener) new KeyListener() {
			public void keyPressed(KeyEvent e) {
				switch (e.getKeyCode()) {
				case KeyEvent.VK_W:
					moveTo("north");
					break;
				case KeyEvent.VK_S:
					moveTo("south");
					break;
				case KeyEvent.VK_A:
					moveTo("west");
					break;
				case KeyEvent.VK_D:
					moveTo("east");
					break;
				case KeyEvent.VK_SPACE:
					action("space");
					break;
				case KeyEvent.VK_ENTER:
					action("ignore");
					break;
				}
			}

			@Override
			public void keyTyped(KeyEvent e) {
				// No lo necesitamos
			}

			@Override
			public void keyReleased(KeyEvent e) {
				// No lo necesitamos
			}
		});
	}

	/**
	 * Nos movemos en el mapa
	 * 
	 * @param move
	 */
	private void moveTo(String move) {
		List<GoTo> goTos = GestorDelInterfaz.getInstance().getGoTosAtPosition(blocks, currentBlock);
		if (null != goTos) {
			for (GoTo goTo : goTos) {
				if ((goTo.getDir().equals(move)) && (goTo.getTo() != currentBlock)) {
					currentBlock = goTo.getTo();
					break;
				}
			}
		}

		// Estamos quitando y aniadiendo componentes dinamicamente al JPanel
		// NO TE OLVIDES del revalidate / repaint
		frame.getContentPane().remove(imagePanel);
		frame.revalidate();
		frame.repaint();

		Block block = GestorDelInterfaz.getInstance().getBlock(blocks, currentBlock);
		imagePanel = getImagePanel(block.getImg());
		frame.getContentPane().add(imagePanel);
		frame.revalidate();
		frame.repaint();

		textPane.setText(block.getText());

		disableAllDirectionButtons();
		enableButtonsForPosition();
	}

	/**
	 * Hacemos una Accion en la casilla en la que estamos 
	 * 
	 * @param action
	 */
	private void action(String action) {
		Block block = GestorDelInterfaz.getInstance().getBlock(blocks, currentBlock);
		if (action.equalsIgnoreCase("space") ){
			textPane.setText(block.getAction());
		} else if (action.equalsIgnoreCase("ignore") ){
			textPane.setText(block.getIgnore());
		}
	}
	
	/**
	 * Nos devuelve un JPanel con la imagen
	 * 
	 * @param imageName
	 * @return el JPanel
	 */
	private JPanel getImagePanel(String imageName) {
		String image = new File("").getAbsolutePath() + "\\src\\criptsOfKalasangan\\img\\" + imageName + ".png";
		ImageIcon imageIcon = new ImageIcon(image);
		JLabel jLabelImage = new JLabel("", imageIcon, JLabel.CENTER);

		JPanel jPanelImage = new JPanel();
		jPanelImage.setBounds(7, 0, 480, 346);
		jPanelImage.add(jLabelImage, JPanel.CENTER_ALIGNMENT);

		return jPanelImage;
	}

	/**
	 * Deshabilita todos los botones de direccion y de accion
	 */
	private void disableAllDirectionButtons() {
		btnWest.setEnabled(false);
		btnEast.setEnabled(false);
		btnNorth.setEnabled(false);
		btnSouth.setEnabled(false);
		btnSpace.setEnabled(false);
		btnEnter.setEnabled(false);
	}

	/**
	 * Habilita solamente los botones de direccion de un block cuyo "to"
	 * corespondiente del "goTo" sea diferente del "at" de block actual. Los botones
	 * de accion los habilita si hay "text" en ese block
	 */
	private void enableButtonsForPosition() {
		
		// Enable botones de accion
		Block block = GestorDelInterfaz.getInstance().getBlock(blocks, currentBlock);
		if ((null != block) && (null != block.getText()) && (block.getText().length()!= 0) ){
			btnSpace.setEnabled(true);
			btnEnter.setEnabled(true);
		}
		
		// Enable botones de direccion
		List<GoTo> goTos = GestorDelInterfaz.getInstance().getGoTosAtPosition(blocks, currentBlock);
		if (null != goTos) {
			for (GoTo goTo : goTos) {
				switch (goTo.getDir()) {
				case "north":
					btnNorth.setEnabled(goTo.getTo() == currentBlock ? false : true);
					break;
				case "south":
					btnSouth.setEnabled(goTo.getTo() == currentBlock ? false : true);
					break;
				case "east":
					btnEast.setEnabled(goTo.getTo() == currentBlock ? false : true);
					break;
				case "west":
					btnWest.setEnabled(goTo.getTo() == currentBlock ? false : true);
					break;
				}
			}
		}
	}

	/**
	 * Reproduce la cancion del juego
	 */
	private void play() {
		new Thread() {
			@Override
			public void run() {
				try {
					FileInputStream fileInputStream = new FileInputStream(Utils.THE_MUSIC_FILE);
					player = new Player(fileInputStream);
					player.play();
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		}.start();
	}

	/**
	 * Detiene la cancion del juego
	 */
	@SuppressWarnings("unused")
	private void stop() {
		if (player != null) {
			player.close();
		}
	}
}
