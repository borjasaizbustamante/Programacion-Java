module MyProjectsForProgram {
	requires java.desktop;
	requires json.simple;
	requires jlayer;
}