package clienteCorreo;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import clienteCorreo.mail.EmailService;

import javax.swing.JTextArea;
import javax.mail.MessagingException;
import javax.swing.JButton;

/**
 * Una clase para enviar correos. Cambia los valores de USER y PASS con los de
 * tu cuenta de GMAIL. Ten cuidado, no se comprueba que lso correos esten bien
 * metidos...<br>
 * NOTA 1: Tienes que desproteger tu cuenta de gmail. Mira el PDF adjunto...<br>
 * NOTA 2: El que manda el correo (textFieldUser) es por defecto el USER, por
 * eso no se puede cambiar <br>
 */
public class ClienteCorreo {

	private static final String USER = "sender@gmail.com"; // Cambia esto...
	private static final String PASS = "The Generated Pass"; // Cambia esto...

	private JFrame frmClienteCorreo;
	private JTextField textFieldUser;
	private JTextField textFieldTo;
	private JTextField textFieldSubject;
	private JTextArea textAreaMessage;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClienteCorreo window = new ClienteCorreo();
					window.frmClienteCorreo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClienteCorreo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmClienteCorreo = new JFrame();
		frmClienteCorreo.setTitle("Cliente Correo");
		frmClienteCorreo.setBounds(100, 100, 362, 300);
		frmClienteCorreo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmClienteCorreo.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("De:");
		lblNewLabel.setBounds(10, 11, 46, 14);
		frmClienteCorreo.getContentPane().add(lblNewLabel);

		JLabel lblPara = new JLabel("Para:");
		lblPara.setBounds(10, 36, 46, 14);
		frmClienteCorreo.getContentPane().add(lblPara);

		JLabel lblAsunto = new JLabel("Asunto:");
		lblAsunto.setBounds(10, 61, 46, 14);
		frmClienteCorreo.getContentPane().add(lblAsunto);

		JLabel lblMensaje = new JLabel("Mensaje:");
		lblMensaje.setBounds(10, 88, 63, 14);
		frmClienteCorreo.getContentPane().add(lblMensaje);

		textFieldUser = new JTextField();
		textFieldUser.setBounds(66, 8, 268, 20);
		frmClienteCorreo.getContentPane().add(textFieldUser);
		textFieldUser.setColumns(10);
		textFieldUser.setText(USER);
		textFieldUser.setEnabled(false);

		textFieldTo = new JTextField();
		textFieldTo.setColumns(10);
		textFieldTo.setBounds(66, 33, 268, 20);
		frmClienteCorreo.getContentPane().add(textFieldTo);

		textFieldSubject = new JTextField();
		textFieldSubject.setColumns(10);
		textFieldSubject.setBounds(66, 58, 268, 20);
		frmClienteCorreo.getContentPane().add(textFieldSubject);

		textAreaMessage = new JTextArea();
		textAreaMessage.setBounds(10, 112, 324, 104);
		frmClienteCorreo.getContentPane().add(textAreaMessage);

		JButton btnSend = new JButton("Enviar");
		btnSend.setBounds(245, 227, 89, 23);
		btnSend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if ((textFieldTo.getText().length() == 0) || (textFieldSubject.getText().length() == 0)
						|| (textAreaMessage.getText().length() == 0))
					JOptionPane.showMessageDialog(new JFrame(), "Faltan campos por rellenar");
				else
					enviarCorreo();
			}
		});
		frmClienteCorreo.getContentPane().add(btnSend);
	}

	private void enviarCorreo() {
		String to = (null == textFieldTo.getText() ? "" : textFieldTo.getText());
		String subject = (null == textFieldSubject.getText() ? "" : textFieldSubject.getText());
		String message = (null == textAreaMessage.getText() ? "" : textAreaMessage.getText());

		EmailService emailService = new EmailService(USER, PASS, "smtp.gmail.com", 465);
		try {
			emailService.sendMail(to, subject, message);

			JOptionPane.showMessageDialog(new JFrame(), "Ok, mail enviado!");
		} catch (MessagingException e) {
			JOptionPane.showMessageDialog(new JFrame(), "Doh! " + e.getMessage());
		}

	}
}
