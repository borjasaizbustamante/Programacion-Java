/**
 * 
 */
/**
 * @author borja
 *
 */
module ClienteCorreo {
	requires java.desktop;
	requires java.mail;
}