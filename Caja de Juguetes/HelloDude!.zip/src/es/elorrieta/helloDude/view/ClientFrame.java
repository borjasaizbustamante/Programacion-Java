package es.elorrieta.helloDude.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import es.elorrieta.helloDude.dataBase.model.Message;
import es.elorrieta.helloDude.dataBase.model.User;
import es.elorrieta.helloDude.logic.Chrono;
import es.elorrieta.helloDude.logic.Logic;

/**
 * Defines the client Window
 */
public class ClientFrame extends JFrame {

	private static final long serialVersionUID = 7398467837254400777L;

	private JFrame frame;
	private JTextField jTextFieldLogin = null;
	private JTextField jTextFieldPass = null;
	private JTextField jTextFieldText = null;
	private JButton jButton = null;

	private Chrono chrono = null;

	public ClientFrame() {
		chrono = new Chrono();
	}

	/**
	 * Initializes the window
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setTitle("Hello, dude!");
		frame.setResizable(false);
		frame.setBounds(400, 100, 400, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.getContentPane().setLayout(null);

		JTextArea jTextArea = new JTextArea();
		jTextArea.setEnabled(false);
		jTextArea.setLineWrap(true);
		jTextArea.setWrapStyleWord(true);

		JScrollPane jScrollPane = new JScrollPane(jTextArea);
		jScrollPane.setBounds(10, 10, 365, 350);
		frame.getContentPane().add(jScrollPane);

		jTextFieldLogin = new JTextField("");
		jTextFieldLogin.setBounds(10, 370, 100, 20);
		jTextFieldLogin.setToolTipText("Login");
		frame.getContentPane().add(jTextFieldLogin);

		jTextFieldPass = new JTextField("");
		jTextFieldPass.setBounds(275, 370, 100, 20);
		jTextFieldPass.setToolTipText("Pass");
		frame.getContentPane().add(jTextFieldPass);

		JLabel jLabel = new JLabel();
		jLabel.setText("Text");
		jLabel.setBounds(30, 430, 40, 20);
		frame.getContentPane().add(jLabel);

		jTextFieldText = new JTextField("");
		jTextFieldText.setBounds(90, 430, 200, 20);
		jTextFieldText.setToolTipText("Message text...");
		jTextFieldText.setEnabled(false);
		frame.getContentPane().add(jTextFieldText);

		jButton = new JButton("Login");
		jButton.setBounds(150, 370, 80, 50);
		jButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonTriggered();
			}
		});
		frame.getContentPane().add(jButton);

		chrono.startScheduledDataBaseUpdate(frame, jTextArea);
	}

	/**
	 * Action button trigered
	 */
	private void buttonTriggered() {

		if (jButton.getText().equals("Login") && !jTextFieldLogin.getText().equals("")
				&& !jTextFieldPass.getText().equals("")) {
			doLogin();
		} else {
			doSend();
		}
	}

	/**
	 * Makes the login
	 */
	private void doLogin() {
		try {
			if (Logic.getInstance().login(jTextFieldLogin.getText(), jTextFieldPass.getText())) {
				jButton.setText("Send");
				jTextFieldLogin.setEnabled(false);
				jTextFieldPass.setEnabled(false);
				jTextFieldText.setEnabled(true);
			} else {
				JOptionPane.showMessageDialog(frame, "Login error", "ERROR!!", JOptionPane.ERROR_MESSAGE);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(frame, "Data Base error", "ERROR!!", JOptionPane.ERROR_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(frame, "An error has happened...", "ERROR!!", JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * ends a message
	 */
	private void doSend() {
		try {
			if (!jTextFieldText.getText().equals("")) {
				
				User user = Logic.getInstance().select(jTextFieldLogin.getText());
				
				Message message = new Message();
				message.setText(jTextFieldText.getText());
				message.setSender(user);
				message.setTimestamp(new Timestamp(new Date().getTime()));

				Logic.getInstance().insert(message);
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(frame, "Data Base error", "ERROR!!", JOptionPane.ERROR_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(frame, "An error has happened...", "ERROR!!", JOptionPane.ERROR_MESSAGE);
		}
	}
}