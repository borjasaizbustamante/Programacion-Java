package es.elorrieta.helloDude.dataBase.manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.elorrieta.helloDude.dataBase.model.Message;
import es.elorrieta.helloDude.dataBase.model.User;
import es.elorrieta.helloDude.dataBase.utils.DBUtils;

/**
 * Defines the Message Manager
 */
public class MessageManager extends ManagerAbstract {

	/**
	 * Returns all messages
	 * 
	 * @return null or the messages
	 * @throws SQLException
	 * @throws Exception
	 */
	public List<Message> selectAll() throws SQLException, Exception {
		List<Message> ret = null;

		String sql = "select * from " + TABLE_MESSAGES + " m inner join " + TABLE_USERS + " u on (m.id_fk = u.userId)";

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			ret = doSelectAll(connection, statement, resultSet, sql);
		} catch (SQLException sqle) {
			throw sqle;
		} catch (Exception e) {
			throw e;
		} finally {
			doClose(connection, statement, resultSet);
		}
		return ret;
	}

	/**
	 ** Returns all messages
	 * 
	 * @param connection
	 * @param statement
	 * @param resultSet
	 * @param sql
	 * @return null or the messages
	 * @throws SQLException
	 * @throws Exception
	 */
	private List<Message> doSelectAll(Connection connection, Statement statement, ResultSet resultSet, String sql)
			throws SQLException, Exception {
		List<Message> ret = null;

		Class.forName(DBUtils.DRIVER);
		connection = DriverManager.getConnection(DBUtils.URL, DBUtils.USER, DBUtils.PASS);
		statement = connection.createStatement();
		resultSet = statement.executeQuery(sql);

		while (resultSet.next()) {

			ret = null == ret ? new ArrayList<Message>() : ret;

			Message message = new Message();
			message.setMessageId(resultSet.getInt("messageId"));
			message.setText(resultSet.getString("text"));
			message.setTimestamp(resultSet.getTimestamp("timestamp"));

			User user = new User();
			user.setUserId(resultSet.getInt("id_fk"));
			user.setLogin(resultSet.getString("login"));
			user.setPass(resultSet.getString("pass"));

			message.setSender(user);
			ret.add(message);
		}

		return ret;
	}

	/**
	 * Inserts a new message
	 * 
	 * @param message
	 * @throws SQLException
	 * @throws Exception
	 */
	public void insert(Message message) throws SQLException, Exception {

		String sql = "insert into " + TABLE_MESSAGES + " (messageId, text, timestamp, id_fk) VALUES ('"
				+ message.getMessageId() + "', '" + message.getText() + "', '" + message.getTimestamp()
				+ "', '" + message.getSender().getUserId() + "')";

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			doInsert(message, connection, statement, resultSet, sql);
		} catch (SQLException sqle) {
			throw sqle;
		} catch (Exception e) {
			throw e;
		} finally {
			doClose(connection, statement, resultSet);
		}
	}

	/**
	 * Inserts a new Message
	 * 
	 * @param user
	 * @param connection
	 * @param statement
	 * @param resultSet
	 * @param sql
	 * @throws SQLException
	 * @throws Exception
	 */
	private void doInsert(Message message, Connection connection, Statement statement, ResultSet resultSet, String sql)
			throws SQLException, Exception {
		Class.forName(DBUtils.DRIVER);
		connection = DriverManager.getConnection(DBUtils.URL, DBUtils.USER, DBUtils.PASS);
		statement = connection.createStatement();
		statement.executeUpdate(sql);
	}

}
