package es.elorrieta.helloDude.dataBase.manager;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Defines a manager.
 */
public abstract class ManagerAbstract {

	protected static final String TABLE_USERS = "t_users";
	protected static final String TABLE_MESSAGES = "t_messages";

	protected void doClose(Connection connection, Statement statement, ResultSet resultSet) {
		doCloseResultSet(resultSet);
		doCloseStatement(statement);
		doCloseResultSet(connection);
	}

	private void doCloseResultSet(ResultSet resultSet) {
		try {
			if (resultSet != null)
				resultSet.close();
		} catch (Exception e) {
		}
	}

	private void doCloseStatement(Statement statement) {
		try {
			if (statement != null)
				statement.close();
		} catch (Exception e) {
		}
	}

	private void doCloseResultSet(Connection connection) {
		try {
			if (connection != null)
				connection.close();
		} catch (Exception e) {
		}
	}
}
