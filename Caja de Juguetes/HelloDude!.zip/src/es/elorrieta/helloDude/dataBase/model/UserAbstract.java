package es.elorrieta.helloDude.dataBase.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Defines a UserAbstract in our system
 */
public abstract class UserAbstract implements Serializable{

	private static final long serialVersionUID = 1839945573340488098L;

	private int userId = 0;
	private String login = null;
	private String pass = null;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(login, pass, userId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserAbstract other = (UserAbstract) obj;
		return Objects.equals(login, other.login) && Objects.equals(pass, other.pass) && userId == other.userId;
	}
}
