package es.elorrieta.helloDude.dataBase.model;

/**
 * Defines a User in our system
 */
public class User extends UserAbstract {

	private static final long serialVersionUID = -4022847852946434380L;

}
