package es.elorrieta.helloDude.dataBase.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * Defines a Message in our system
 */
public class Message implements Serializable {

	private static final long serialVersionUID = -450301356078612535L;

	private int messageId = 0;
	private String text = null;
	private User sender = null;
	private Timestamp timestamp = null;

	public int getMessageId() {
		return messageId;
	}

	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public User getSender() {
		return sender;
	}

	public void setSender(User sender) {
		this.sender = sender;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public int hashCode() {
		return Objects.hash(messageId, sender, text, timestamp);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Message other = (Message) obj;
		return messageId == other.messageId && Objects.equals(sender, other.sender) && Objects.equals(text, other.text)
				&& Objects.equals(timestamp, other.timestamp);
	}
}
