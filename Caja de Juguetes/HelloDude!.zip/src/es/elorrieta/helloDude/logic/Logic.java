package es.elorrieta.helloDude.logic;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import es.elorrieta.helloDude.dataBase.manager.MessageManager;
import es.elorrieta.helloDude.dataBase.manager.UserManager;
import es.elorrieta.helloDude.dataBase.model.Message;
import es.elorrieta.helloDude.dataBase.model.User;

/**
 * Defines the app logic. Implements Singleton Pattern
 */
public class Logic {

	private static Logic logic = null;

	private UserManager userManager = null;
	private MessageManager messageManager = null;

	private Logic() {
		userManager = new UserManager();
		messageManager = new MessageManager();
	}

	/**
	 * Returns the sole object of Logic
	 * 
	 * @return logic
	 */
	public static Logic getInstance() {
		return logic = logic == null ? new Logic() : logic;
	}

	/**
	 * Returns all messages
	 * 
	 * @return null or the messages
	 * @throws SQLException
	 * @throws Exception
	 */
	public List<Message> getMessages() throws SQLException, Exception {
		return messageManager.selectAll();
	}

	/**
	 * Filters all messages older than the given Timestamp and returns the newer
	 * 
	 * @param timestamp
	 * @return null or the messages
	 * @throws SQLException
	 * @throws Exception
	 */
	public List<Message> getFilteredOlderMessages(Timestamp timestamp) throws SQLException, Exception {
		List<Message> ret = new ArrayList<Message>();
		for (Message message : messageManager.selectAll()) {
			if (null != (message.getTimestamp().before(timestamp) ? message : null))
				ret.add(message);
		}
		return ret.size() == 0 ? null : ret;
	}

	/**
	 * Filters all messages newer than the given Timestamp and returns the older
	 * 
	 * @param timestamp
	 * @return null or the messages
	 * @throws SQLException
	 * @throws Exception
	 */
	public List<Message> getFilteredNewerMessages(Timestamp timestamp) throws SQLException, Exception {
		List<Message> ret = new ArrayList<Message>();
		for (Message message : messageManager.selectAll()) {
			if (null != (message.getTimestamp().after(timestamp) ? message : null))
				ret.add(message);
		}
		return ret.size() == 0 ? null : ret;
	}

	/**
	 * Returns true if the login and pass atches data base, false otherwise  
	 * 
	 * @param login
	 * @param pass
	 * @return true or false
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean login(String login, String pass) throws SQLException, Exception {
		User user = select(login);
		return null != user && null != user.getPass() && user.getPass().equals(pass);
	}
	
	/**
	 * Return the user of the given login
	 * 
	 * @param login
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public User select(String login) throws SQLException, Exception {
		return userManager.select(login);
	}

	/**
	 * Inserts a new message
	 * 
	 * @param message
	 * @throws SQLException
	 * @throws Exception
	 */
	public void insert(Message message) throws SQLException, Exception {
		messageManager.insert(message);
	}

	/**
	 * Inserts a new User
	 * 
	 * @param user
	 * @throws SQLException
	 * @throws Exception
	 */
	public void insert(User user) throws SQLException, Exception {
		userManager.insert(user);
	}
}
