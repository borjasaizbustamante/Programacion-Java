package es.elorrieta.helloDude.logic;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import es.elorrieta.helloDude.dataBase.model.Message;

/**
 * Defines an scheduled operation for updating the conversation
 */
public class Chrono {

	/**
	 * Updates the conversation each three seconds after one second delay
	 * 
	 * @param frame
	 */
	public void startScheduledDataBaseUpdate(JFrame frame, JTextArea jTextArea) {

		new Timer().scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				try {
					jTextArea.setText(null);
					List<Message> messages = Logic.getInstance().getMessages();

					messages = null == messages ? new ArrayList<Message>() : messages;
					for (Message message : messages) {
						jTextArea.append(message.getSender().getLogin() + " -> " + message.getText() + "\n");
					}

				} catch (Exception e) {
					JOptionPane.showMessageDialog(frame, "Chrono error!", "ERROR!!", JOptionPane.ERROR_MESSAGE);
				}
			}
		}, 1000, 3000);
	}
}
