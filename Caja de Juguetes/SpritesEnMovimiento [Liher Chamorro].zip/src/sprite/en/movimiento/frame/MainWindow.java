package sprite.en.movimiento.frame;

import javax.swing.JFrame;

import sprite.en.movimiento.panel.GamePanel;

/**
 * Clase para crear el frame y añadirle el Panel
 */
public class MainWindow extends JFrame{
	
	private static final long serialVersionUID = 1L;

	/**
	 * constructor
	 */
	public MainWindow() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setTitle("Rojo se mueve (Ayuda)");
		
		GamePanel gamePanel = new GamePanel();
		add(gamePanel);
		
		pack();
		setLocationRelativeTo(null);
	}
	
}
