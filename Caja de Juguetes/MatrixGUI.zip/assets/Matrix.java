package assets;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;

/**
 * @author Mindusting
 * @see https://drive.google.com/drive/folders/1swnODIsjZXUugHT9RhZvriEoluiGSe8E
 */
public class Matrix extends JFrame {

	private static final long serialVersionUID = 1L;
	private static JPanel contentPane;
	
	private static int matrixWidth = 55;  // 55
	private static int matrixHeight = 26; // 26
	private static int numWidth = 8;
	private static int numHeight = 10;
	
	private static JLabel[][] matrix = new JLabel[matrixWidth][matrixHeight];
	private static String[] chars = {" ", " ", " ", "0", "1"};

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		Matrix frame = new Matrix();
		frame.setVisible(true);
		
		int width = matrix.length;
		int height = matrix[0].length;
		
		while (true) {
			matrix[(int)(Math.random() * width)][(int)(Math.random() * height)]
			.setText(chars[(int)(Math.random() * chars.length)]);
			
			try {
			    Thread.sleep(1);
			} catch (InterruptedException ie) {
			    Thread.currentThread().interrupt();
			}
		}
	}

	/**
	 * Create the frame.
	 */
	public Matrix() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, matrixWidth * numWidth, matrixHeight * numHeight);
		setTitle("Matrix");
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		for (int i = 0; i < matrixWidth; i++) {
			for (int j = 0; j < matrixHeight; j++) {
				JLabel newLabel = new JLabel(String.valueOf((int)(Math.random() * 2)));
				newLabel.setBounds(i * numWidth, j * numHeight, numWidth, numHeight);
				newLabel.setForeground(new Color(0, 255, 0));
				contentPane.add(newLabel);
				matrix[i][j] = newLabel;
			}
		}
	}
}
