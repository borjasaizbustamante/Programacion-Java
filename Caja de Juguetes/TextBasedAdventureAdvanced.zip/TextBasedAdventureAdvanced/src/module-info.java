/**
 * 
 */
/**
 * @author borja
 *
 */
module TextBasedAdventureAdvanced {
	requires java.desktop;
	requires json.simple;
}