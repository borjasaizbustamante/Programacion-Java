package textBasedAdventureAdvanced;

import java.awt.Color;
import java.awt.EventQueue;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import org.json.simple.parser.ParseException;

import textBasedAdventureAdvanced.engine.Parser;
import textBasedAdventureAdvanced.engine.beans.Blocks;
import textBasedAdventureAdvanced.engine.beans.GoTo;
import textBasedAdventureAdvanced.engine.utils.Utils;
import textBasedAdventureAdvanced.view.GestorDelInterfaz;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

/**
 * Un programita sencillo para hacer aventuras de tipo texto. Para escribir tu
 * propia aventura, solo tienes que cambiar el ficheo seed.json por lo que
 * quieras poner.
 * 
 * Esta variante a demas te obliga a superar dificultades. Para ver si las superas, 
 * se lanza un dado virtual. Si se supera el limite, te aparece una u otra opcion. 
 * 
 * REGLAS:  - No puedes repetir IDs.
 * 			- Las IDs de los GoTos es a donde quieres ir
 * 			- No puede haber mas de cuatro opciones
 * 			- Si quieres terminar un camino [Un final] pon GoTos vacios. 
 * 			- "target" indica que hay que tirar el dado y la dificultad
			- "miss" indica la id del texto que se muestra si se falla 
 */
public class TextBasedAdventureAdvanced{

	private JFrame frmAventuraDeTexto;
	private JTextPane textPanel = null;
	private JTextPane textPaneRoll = null;
	private JLabel labelRoll = null;
	private JButton buttonGoto1 = null;
	private JButton buttonGoto2 = null;
	private JButton buttonGoto3 = null;
	private JButton buttonGoto4 = null;
	private Blocks blocks = null;
	private int currentBlockId = 0;

	/**
	 * Main de la clase
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TextBasedAdventureAdvanced window = new TextBasedAdventureAdvanced();
					window.frmAventuraDeTexto.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructor
	 */
	public TextBasedAdventureAdvanced() {
		try {
			blocks = Parser.getInstance().processSeed();
		} catch (IOException | ParseException e) {
			JOptionPane.showMessageDialog(null, "Error en el fichero de texto.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		initialize();
		showAllButtonGotos();
		textPanel.setText(GestorDelInterfaz.getInstance().displayInitialBlock(blocks));
		
		textPaneRoll = new JTextPane();
		textPaneRoll.setFont(new Font("Tahoma", Font.BOLD, 40));
		textPaneRoll.setBounds(681, 80, 93, 55);
		textPaneRoll.setVisible(false);
		
		StyledDocument styledDocument = textPaneRoll.getStyledDocument();
		SimpleAttributeSet center = new SimpleAttributeSet();
		StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
		styledDocument.setParagraphAttributes(0, styledDocument.getLength(), center, false);
		
		frmAventuraDeTexto.getContentPane().add(textPaneRoll);
		
		labelRoll = new JLabel("Tu Tirada");
		labelRoll.setFont(new Font("Tahoma", Font.PLAIN, 16));
		labelRoll.setBounds(690, 26, 70, 43);
		labelRoll.setVisible(false);
		frmAventuraDeTexto.getContentPane().add(labelRoll);
		int numberOfGoTos = GestorDelInterfaz.getInstance().getNumberOfGoTos(blocks, 0);
		showHideButtonGotos(numberOfGoTos);
	}

	/**
	 * Inicializa la ventana
	 */
	private void initialize() {
		frmAventuraDeTexto = new JFrame();
		frmAventuraDeTexto.setTitle("Aventura de Texto");
		frmAventuraDeTexto.setBounds(300, 100, 800, 320);
		frmAventuraDeTexto.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAventuraDeTexto.getContentPane().setLayout(null);

		textPanel = new JTextPane();
		textPanel.setFont(new Font("Verdana Pro", Font.PLAIN, 14));
		textPanel.setEditable(false);
		textPanel.setBounds(10, 26, 510, 222);
		frmAventuraDeTexto.getContentPane().add(textPanel);

		buttonGoto1 = new JButton("Opcion 1");
		buttonGoto1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(1);
			}
		});
		buttonGoto1.setBounds(530, 26, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto1);

		buttonGoto2 = new JButton("Opcion 2");
		buttonGoto2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(2);
			}
		});
		buttonGoto2.setBounds(530, 86, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto2);

		buttonGoto3 = new JButton("Opcion 3");
		buttonGoto3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(3);
			}
		});
		buttonGoto3.setBounds(530, 146, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto3);

		buttonGoto4 = new JButton("Opcion 4");
		buttonGoto4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(4);
			}
		});
		buttonGoto4.setBounds(530, 206, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto4);
		
	}

	/**
	 * Muestra todos los botones
	 */
	private void showAllButtonGotos() {
		buttonGoto1.setVisible(true);
		buttonGoto2.setVisible(true);
		buttonGoto3.setVisible(true);
		buttonGoto4.setVisible(true);
	}

	/**
	 * Oculta los botones en base al numero de goTos del bloque actual
	 * 
	 * @param numberOfGoTos
	 */
	private void showHideButtonGotos(int numberOfGoTos) {
		switch (numberOfGoTos) {
		case 0:
			buttonGoto1.setVisible(false);
		case 1:
			buttonGoto2.setVisible(false);
		case 2:
			buttonGoto3.setVisible(false);
		case 3:
			buttonGoto4.setVisible(false);
		case 4: // Nothing...
		}
	}

	/**
	 * Seleccionamos la opcion del menu
	 * 
	 * @param opcion
	 */
	private void moveToOption(int opcion) {
		List<GoTo> goTos = GestorDelInterfaz.getInstance().getGoTosToDisplay(blocks, currentBlockId);
		if (null != goTos) {
			GoTo goTo = goTos.get(opcion - 1);
			if (null != goTo) {
				if (goTo.getTarget() != GoTo.NO_TARGET) {
					textPaneRoll.setText(null);
					int roll = Utils.roll();
					textPaneRoll.setText(roll + "");
					textPaneRoll.setVisible(true);
					labelRoll.setVisible(true);
					if (roll > goTo.getTarget()) {
						currentBlockId = goTo.getId();
						textPaneRoll.setBackground(Color.WHITE);
					} else {
						currentBlockId = goTo.getMiss();
						textPaneRoll.setBackground(Color.RED);
					}
				} else {
					currentBlockId = goTo.getId();
					textPaneRoll.setVisible(false);
					labelRoll.setVisible(false);
				}
				showAllButtonGotos();
				textPanel.setText(GestorDelInterfaz.getInstance().displayBlock(blocks, currentBlockId));
				int numberOfGoTos = GestorDelInterfaz.getInstance().getNumberOfGoTos(blocks, currentBlockId);
				showHideButtonGotos(numberOfGoTos);
			}
		}
	}
}
