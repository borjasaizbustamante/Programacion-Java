package textBasedAdventureAdvanced.view;

import java.util.List;

import javax.swing.JOptionPane;

import textBasedAdventureAdvanced.engine.beans.Block;
import textBasedAdventureAdvanced.engine.beans.Blocks;
import textBasedAdventureAdvanced.engine.beans.GoTo;

/**
 * Clase encargada de gestionar la interface
 */
public class GestorDelInterfaz {

	private static GestorDelInterfaz instance = null;

	/**
	 * Constructor negado (Patron Singleton)
	 */
	private GestorDelInterfaz() {

	}

	/**
	 * Retorna la unica instancia de Parser (Patron Singleton)
	 * 
	 * @return La unica instancia de Parser
	 */
	public static GestorDelInterfaz getInstance() {
		if (null == instance)
			instance = new GestorDelInterfaz();
		return instance;
	}

	/**
	 * Retorna el texto del bloque indicado
	 * 
	 * @param blockId
	 * @return Texto que se muestra
	 */
	public String getTextToDisplay(Blocks blocks, int blockId) {
		String ret = null;
		if ((null != blocks) && (null != blocks.getBlocks())) {
			for (Block block : blocks.getBlocks()) {
				if (block.getId() == blockId) {
					ret = block.getText();
					break;
				}
			}
		} else {
			JOptionPane.showMessageDialog(null, "El fichero de texto está vacio.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return ret;
	}

	/**
	 * Retorna los goTos del bloque indicado
	 * 
	 * @param blockId
	 * @return Lista de goTos
	 */
	public String getFormattedGoTosToDisplay(Blocks blocks, int blockId) {
		String ret = null;
		List<GoTo> goTos = getGoTosToDisplay(blocks, blockId);
		if (null != goTos) {
			int i = 1;
			for (GoTo goTo : goTos) {
				if (null == ret)
					ret = "";
				ret += "     " + i++ + ") " + goTo.getText() + "\n" + "\n";
			}
		}
		return ret;
	}

	/**
	 * Retorna los goTos del bloque indicado
	 * 
	 * @param blockId
	 * @return Lista de goTos
	 */
	public List<GoTo> getGoTosToDisplay(Blocks blocks, int blockId) {
		List<GoTo> ret = null;
		if ((null != blocks) && (null != blocks.getBlocks())) {
			for (Block block : blocks.getBlocks()) {
				if (block.getId() == blockId) {
					ret = block.getGoTos();
					break;
				}
			}
		} else {
			JOptionPane.showMessageDialog(null, "El fichero de texto está vacio.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return ret;
	}

	/**
	 * Retorna el numero de goTos del bloque indicado
	 * 
	 * @param blockId
	 * @return Lista de goTos
	 */
	public int getNumberOfGoTos(Blocks blocks, int blockId) {
		int ret = 0;
		if ((null != blocks) && (null != blocks.getBlocks())) {
			for (Block block : blocks.getBlocks()) {
				if (block.getId() == blockId) {
					ret = block.getGoTos() == null? 0 : block.getGoTos().size(); 
					break;
				}
			}
		} else {
			JOptionPane.showMessageDialog(null, "El fichero de texto está vacio.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return ret;
	}

	/**
	 * Retorna un texto inicial para mostrarlo
	 * 
	 * @param blocks
	 * @return el texto para mostrar del bloque
	 */
	public String displayInitialBlock(Blocks blocks) {
		return displayBlock(blocks, 0);
	}

	/**
	 * Retorna un texto de un bloque para mostrarlo
	 * 
	 * @param blocks
	 * @param blockId
	 * @return el texto para mostrar del bloque
	 */
	public String displayBlock(Blocks blocks, int blockId) {
		String ret = ""; 
		String text = getTextToDisplay(blocks, blockId);
		ret += text == null? "" : text;
		ret += "\n";
		ret += "\n";
		String goTos = getFormattedGoTosToDisplay(blocks, blockId);
		ret += goTos == null? "" : goTos;
		return ret;
	}
}
