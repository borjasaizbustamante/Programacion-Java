package textBasedAdventureAdvanced.engine.beans;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

/**
 * Un Bloque
 */
public class Block implements Serializable {

	private static final long serialVersionUID = -578858462965845200L;

	private int id;
    private String text;
    private List<GoTo> goTos = null;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public List<GoTo> getGoTos() {
		return goTos;
	}

	public void setGoTos(List<GoTo> goTos) {
		this.goTos = goTos;
	}

	@Override
	public int hashCode() {
		return Objects.hash(goTos, id, text);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Block other = (Block) obj;
		return Objects.equals(goTos, other.goTos) && Objects.equals(id, other.id) && Objects.equals(text, other.text);
	}

	@Override
	public String toString() {
		return "Block [id=" + id + ", text=" + text + ", goTos=" + goTos + "]";
	}
}
