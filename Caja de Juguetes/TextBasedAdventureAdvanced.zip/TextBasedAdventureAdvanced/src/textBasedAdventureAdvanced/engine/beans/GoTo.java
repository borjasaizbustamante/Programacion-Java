package textBasedAdventureAdvanced.engine.beans;

import java.io.Serializable;
import java.util.Objects;

/**
 * Las opciones de cada bloque
 */
public class GoTo implements Serializable {

	private static final long serialVersionUID = -8337501366632266425L;

	private int id;
	private String text;
	private int target;
	private int miss;

	public static final int NO_TARGET = -1; 
	public static final int MAX_TARGET = 10;
	public static final int MIN_TARGET = 1;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getTarget() {
		return target;
	}

	public void setTarget(int target) {
		this.target = target;
	}

	public int getMiss() {
		return miss;
	}

	public void setMiss(int miss) {
		this.miss = miss;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, miss, target, text);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GoTo other = (GoTo) obj;
		return id == other.id && miss == other.miss && target == other.target && Objects.equals(text, other.text);
	}

	@Override
	public String toString() {
		return "GoTo [id=" + id + ", text=" + text + ", target=" + target + ", miss=" + miss + "]";
	}
}