module SendingEmailFromJFrame {
	requires java.desktop;
	requires java.mail;
	requires java.activation;
}