package main;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

/**
 * Una clase para enviar correos. Cambia los valores de USER y PASS con los de
 * tu cuenta de GMAIL. Ten cuidado, no se comprueba que los correos esten bien
 * metidos... Este programa permite enviar ficheros adjuntos<br>
 * NOTA 1: Tienes que desproteger tu cuenta de gmail. Mira el PDF adjunto...<br>
 * NOTA 2: El que manda el correo (textFieldUser) es por defecto el USER, por
 * eso no se puede cambiar <br>
 */
public class ClienteCorreoAvanzado extends JFrame {

	private static final long serialVersionUID = 7544316256471631010L;

	private JPanel contentPane;
	private JTextField text_emisor;
	private JTextField text_receptor;
	private JTextField txtPrueba;
	private JTextField txtReceptor;
	private JTextField txtMensaje;
	private JTextField text_mensaje;
	private JTextField txtAsunto;
	private JTextField text_asunto;
	private JTextField text_CCo;
	private JTextField txtCco;
	private String url;

	// CAMBIAR POR LA CLAVE DE TU CUENTA GMAIL
	private static final String PASS = "drvttwgeychshfcn";
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClienteCorreoAvanzado frame = new ClienteCorreoAvanzado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ClienteCorreoAvanzado() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 715, 507);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		text_emisor = new JTextField();
		text_emisor.setBounds(40, 42, 329, 20);
		contentPane.add(text_emisor);
		text_emisor.setColumns(10);

		text_receptor = new JTextField();
		text_receptor.setBounds(40, 104, 329, 20);
		contentPane.add(text_receptor);
		text_receptor.setColumns(10);

		txtPrueba = new JTextField();
		txtPrueba.setEditable(false);
		txtPrueba.setText("EMISOR:");
		txtPrueba.setBounds(40, 11, 86, 20);
		contentPane.add(txtPrueba);
		txtPrueba.setColumns(10);

		txtReceptor = new JTextField();
		txtReceptor.setEditable(false);
		txtReceptor.setText("RECEPTOR:");
		txtReceptor.setBounds(40, 73, 86, 20);
		contentPane.add(txtReceptor);
		txtReceptor.setColumns(10);

		txtMensaje = new JTextField();
		txtMensaje.setEditable(false);
		txtMensaje.setText("MENSAJE:");
		txtMensaje.setBounds(40, 259, 86, 20);
		contentPane.add(txtMensaje);
		txtMensaje.setColumns(10);

		text_mensaje = new JTextField();
		text_mensaje.setBounds(40, 290, 329, 20);
		contentPane.add(text_mensaje);
		text_mensaje.setColumns(10);

		JButton btnNewButton = new JButton("ENVIAR CORREO");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SendEmail sendEmail = new SendEmail();
				sendEmail.getInfo(text_emisor.getText().toString(), PASS, text_receptor.getText().toString(),
						text_CCo.getText().toString(), text_asunto.getText().toString(),
						text_mensaje.getText().toString(), url);
			}
		});
		btnNewButton.setBounds(506, 415, 172, 23);
		contentPane.add(btnNewButton);

		txtAsunto = new JTextField();
		txtAsunto.setEditable(false);
		txtAsunto.setText("ASUNTO");
		txtAsunto.setBounds(40, 197, 86, 20);
		contentPane.add(txtAsunto);
		txtAsunto.setColumns(10);

		text_asunto = new JTextField();
		text_asunto.setBounds(40, 228, 329, 20);
		contentPane.add(text_asunto);
		text_asunto.setColumns(10);

		text_CCo = new JTextField();
		text_CCo.setBounds(40, 166, 329, 20);
		contentPane.add(text_CCo);
		text_CCo.setColumns(10);

		txtCco = new JTextField();
		txtCco.setEditable(false);
		txtCco.setText("CCo");
		txtCco.setBounds(40, 135, 86, 20);
		contentPane.add(txtCco);
		txtCco.setColumns(10);

		JButton btnNewButton_1 = new JButton("Añadir Adjunto");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				final JFrame frame = new JFrame("Open File Example");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLayout(new BorderLayout());

				JFileChooser chooser = new JFileChooser();
				if (chooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
					File archivo = chooser.getSelectedFile();
					url = archivo.getPath();
					System.out.println("URL" + url);
				}

				frame.pack();
				frame.setLocationByPlatform(true);
				frame.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(56, 415, 89, 23);
		contentPane.add(btnNewButton_1);
	}
}
