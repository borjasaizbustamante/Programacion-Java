package main;

import java.util.ArrayList;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendEmail {

	// Server mail user & pass account
	private String user = null;
	private String pass = null;

	// DNS Host + SMTP Port
	private String smtp_host = null;
	private int smtp_port = 0;

	public SendEmail() {
	}

	/**
	 * Builds the EmailService.
	 * 
	 * @param user User account login
	 * @param pass User account password
	 * @param host The Server DNS
	 * @param port The Port
	 */
	public SendEmail(String user, String pass, String host, int port) {
		this.user = user;
		this.pass = pass;
		this.smtp_host = host;
		this.smtp_port = port;
	}

	/**
	 * Sends the given <b>text</b> from the <b>sender</b> to the <b>receiver</b>. In
	 * any case, both the <b>sender</b> and <b>receiver</b> must exist and be valid
	 * mail addresses. The sender, mail's FROM part, is taken from this.user by
	 * default<br/>
	 * <br/>
	 * 
	 * Note the <b>user</b> and <b>pass</b> for the authentication is provided in
	 * the class constructor. Ideally, the <b>sender</b> and the <b>user</b>
	 * coincide.
	 * 
	 * @param receiver The mail's TO part
	 * @param subject  The mail's SUBJECT
	 * @param text     The proper MESSAGE
	 * @throws MessagingException Is something awry happens
	 * 
	 */
	private void sendMail(String receiver, String subject, String text, String url) throws MessagingException {

		// Mail properties
		Properties properties = new Properties();
		properties.put("mail.smtp.auth", true);
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", smtp_host);
		properties.put("mail.smtp.port", smtp_port);
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.ssl.trust", smtp_host);
		properties.put("mail.imap.partialfetch", false);

		// Authenticator knows how to obtain authentication for a network connection.
		Session session = Session.getInstance(properties, new Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, pass);
			}
		});

		// MIME message to be sent
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(user));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receiver)); // Ej: receptor@gmail.com
		message.setSubject(subject); // Asunto del mensaje

		// A mail can have several parts
		MimeMultipart multipart = new MimeMultipart();
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		BodyPart adjunto = new MimeBodyPart();

		messageBodyPart.setContent(text, "text/html");

		adjunto.setDataHandler(new DataHandler(new FileDataSource(url)));
		multipart.addBodyPart(adjunto);
		multipart.addBodyPart(messageBodyPart);
		message.setContent(multipart);
		Transport.send(message);
	}

	/**
	 * Prepares the mail to be sent
	 * 
	 * @param user
	 * @param pass
	 * @param to
	 * @param CCo
	 * @param subject
	 * @param strMessage
	 * @param url
	 */
	public void getInfo(String user, String pass, String to, String CCo, String subject, String strMessage, String url) {

		SendEmail emailService = new SendEmail(user, pass, "smtp.gmail.com", 465);
		String[] CCoList = CCo.split(",");

		ArrayList<String> listaEnviados = new ArrayList<String>();
		listaEnviados.add(to);

		try {
			emailService.sendMail(to, subject, strMessage, url);
			if (CCo == null || CCo == " ") {
				for (int i = 0; i < CCoList.length; i++) {
					String emailEnviar = CCoList[i];
					for (int j = 0; j < listaEnviados.size(); j++) {
						if (listaEnviados.get(j).equalsIgnoreCase(emailEnviar)) {
							System.out.println("MAL ");
						} else {
							System.out.println("ENVIADO ");
							listaEnviados.add(emailEnviar);
							emailService.sendMail(emailEnviar, subject, strMessage, url);
						}
					}
				}
			}
		} catch (MessagingException e) {
			System.out.println("Doh! " + e.getMessage());
		}
	}
}
