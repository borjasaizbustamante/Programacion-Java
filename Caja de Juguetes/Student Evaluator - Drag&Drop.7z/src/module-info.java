/**
 * 
 */
/**
 * 
 */
module StudentEvaluator {
	requires java.desktop;
}