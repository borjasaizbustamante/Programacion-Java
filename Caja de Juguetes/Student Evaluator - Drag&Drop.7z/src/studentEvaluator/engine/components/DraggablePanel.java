package studentEvaluator.engine.components;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * A panel that can be dragged & dropped
 */
public class DraggablePanel extends JPanel {

	private static final long serialVersionUID = -516538266092751398L;
	
	private final int id;

	public DraggablePanel(String label, int id) {
		this.id = id;
		this.add(new JLabel(label));
	}

	public int getId() {
		return id;
	}
	
}
