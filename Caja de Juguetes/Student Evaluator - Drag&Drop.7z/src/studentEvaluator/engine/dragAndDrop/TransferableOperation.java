package studentEvaluator.engine.dragAndDrop;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

import studentEvaluator.engine.components.DraggablePanel;

/**
 * Provides data for a transfer operation (Drag & Drop). If we transfer more
 * than DraggablePanels, we must add more "flavors"
 * 
 * A "flavor", or more specifically, the PANEL_FLAVOR is the "meta information"
 * about data transferred. It this case, we transfer DraggablePanels. There are
 * a lot of different meta data
 * 
 * @see PanelDropTargetAdapter
 */
public class TransferableOperation implements Transferable {

	public static final DataFlavor PANEL_FLAVOR = new DataFlavor(DraggablePanel.class, "DraggablePanel");

	private final DraggablePanel panel;

	public TransferableOperation(DraggablePanel panel) {
		this.panel = panel;
	}

	@Override
	public DataFlavor[] getTransferDataFlavors() {
		return new DataFlavor[] { PANEL_FLAVOR };
	}

	@Override
	public boolean isDataFlavorSupported(DataFlavor flavor) {
		return flavor.equals(PANEL_FLAVOR);
	}

	@Override
	public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException {
		if (flavor.equals(PANEL_FLAVOR)) {
			return panel;
		}
		throw new UnsupportedFlavorException(flavor);
	}
}
