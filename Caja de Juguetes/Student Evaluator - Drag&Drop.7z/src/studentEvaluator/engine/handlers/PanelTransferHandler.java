package studentEvaluator.engine.handlers;

import java.awt.datatransfer.Transferable;
import studentEvaluator.engine.components.DraggablePanel;

import javax.swing.JComponent;
import javax.swing.TransferHandler;

import studentEvaluator.engine.dragAndDrop.TransferableOperation;

/**
 * Handles the transfer of a Transferable to and from Swing components. 
 */
public class PanelTransferHandler extends TransferHandler {

	private static final long serialVersionUID = 1787033441730540129L;

	@Override
	protected Transferable createTransferable(JComponent c) {
		return new TransferableOperation((DraggablePanel) c);
	}

	@Override
	public int getSourceActions(JComponent c) {
		return MOVE;
	}
}
