package studentEvaluator.engine.adapter;

import java.awt.datatransfer.Transferable;

import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.util.ArrayList;

import studentEvaluator.engine.WindowFrame;
import studentEvaluator.engine.components.DraggablePanel;
import studentEvaluator.engine.dragAndDrop.TransferableOperation;

/**
 * An adapter for a panel receiving drop target events
 * 
 * @see TransferableOperation
 */
public class PanelDropTargetAdapter extends DropTargetAdapter {

	private WindowFrame frame = null;
	
	private ArrayList<DraggablePanel> targetList;
	private ArrayList<DraggablePanel> sourceList;

	/**
	 * Main constructor. 
	 * 
	 * @param frame The frame
	 * @param targetList The list attached to where you "drop" the elements   
	 * @param sourceList The list attached to where you "drag" the elements
	 */
	public PanelDropTargetAdapter(WindowFrame frame, ArrayList<DraggablePanel> targetList,
			ArrayList<DraggablePanel> sourceList) {
		this.frame = frame;
		this.targetList = targetList;
		this.sourceList = sourceList;
	}

	/**
	 * Called when the drag operation has terminated with a drop 
	 */
	@Override
	public void drop(DropTargetDropEvent dropTargetDropEvent) {
		try {
			dropTargetDropEvent.acceptDrop(DnDConstants.ACTION_MOVE);
			Transferable transferable = dropTargetDropEvent.getTransferable();

			// Whatever is dragged into the panel, is it supported? 
			if (transferable.isDataFlavorSupported(TransferableOperation.PANEL_FLAVOR)) {
				DraggablePanel draggedPanel = (DraggablePanel) transferable
						.getTransferData(TransferableOperation.PANEL_FLAVOR);

				// Use the panel ID to find and move the panel in the list
				if (sourceList.removeIf(panel -> panel.getId() == draggedPanel.getId())) {
					targetList.add(draggedPanel);
					frame.refreshPanels();
					dropTargetDropEvent.dropComplete(true);
				} else {
					dropTargetDropEvent.rejectDrop();
				}
			} else {
				// Not supported
				dropTargetDropEvent.rejectDrop();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			dropTargetDropEvent.dropComplete(false);
		}
	}
}
