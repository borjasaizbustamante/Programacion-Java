package studentEvaluator.engine.adapter;

import java.awt.datatransfer.Transferable;

import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDropEvent;
import java.util.ArrayList;

import studentEvaluator.engine.WindowFrame;
import studentEvaluator.engine.components.DraggablePanel;
import studentEvaluator.engine.dragAndDrop.TransferableOperation;
import studentEvaluator.engine.handlers.PanelTransferHandler;

/**
 * An adapter for a panel receiving drop target events
 * 
 * @see TransferableOperation
 */
public class PanelDropTargetAdapter extends DropTargetAdapter {

	private WindowFrame frame = null;

	private ArrayList<DraggablePanel> targetList;
	private ArrayList<DraggablePanel> sourceList;

	/**
	 * Main constructor.
	 * 
	 * @param frame      The frame
	 * @param targetList The list attached to where you "drop" the elements
	 * @param sourceList The list attached to where you "drag" the elements
	 */
	public PanelDropTargetAdapter(WindowFrame frame, ArrayList<DraggablePanel> targetList,
			ArrayList<DraggablePanel> sourceList) {
		this.frame = frame;
		this.targetList = targetList;
		this.sourceList = sourceList;
	}

	/**
	 * Called when the drag operation has terminated with a drop
	 */
	@Override
	public void drop(DropTargetDropEvent dropTargetDropEvent) {
		try {
			dropTargetDropEvent.acceptDrop(DnDConstants.ACTION_MOVE);
			Transferable transferable = dropTargetDropEvent.getTransferable();

			// Whatever is dragged into the panel, is it supported?
			if (transferable.isDataFlavorSupported(TransferableOperation.PANEL_FLAVOR)) {
				DraggablePanel draggedPanel = (DraggablePanel) transferable
						.getTransferData(TransferableOperation.PANEL_FLAVOR);

				// Use the panel ID to find and move the panel in the list
				if (sourceList.removeIf(panel -> panel.getId() == draggedPanel.getId())) {

					// These attributes are lost when dropped somewhere
					draggedPanel.setTransferHandler(new PanelTransferHandler());
					draggedPanel.addMouseListener(new DragMouseAdapter());

					targetList.add(draggedPanel);
					frame.refreshPanels();
					dropTargetDropEvent.dropComplete(true);
				} else {

					// This try catch is WRONG. But the only easy way to prevent Exception when
					// rejectDrop() is called when you drop an element in the same panel it was.
					try {
						dropTargetDropEvent.rejectDrop();
					} catch (Exception e) {

					}
				}
			} else {
				// Not supported
				dropTargetDropEvent.rejectDrop();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			dropTargetDropEvent.dropComplete(false);
		}
	}
}
