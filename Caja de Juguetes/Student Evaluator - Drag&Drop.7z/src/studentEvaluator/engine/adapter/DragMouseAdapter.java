package studentEvaluator.engine.adapter;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.TransferHandler;

import studentEvaluator.engine.components.DraggablePanel;

/**
 * An adapter for when you press and holds the mouse button
 */
public class DragMouseAdapter extends MouseAdapter {
	
	@Override
	public void mousePressed(MouseEvent e) {
		DraggablePanel draggedPanel = (DraggablePanel) e.getSource();
		TransferHandler handler = draggedPanel.getTransferHandler();
		handler.exportAsDrag(draggedPanel, e, TransferHandler.MOVE);
	}
}
