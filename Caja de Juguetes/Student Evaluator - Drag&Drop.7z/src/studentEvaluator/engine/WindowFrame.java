package studentEvaluator.engine;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.dnd.DropTarget;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

import studentEvaluator.engine.adapter.DragMouseAdapter;
import studentEvaluator.engine.adapter.PanelDropTargetAdapter;
import studentEvaluator.engine.components.DraggablePanel;
import studentEvaluator.engine.handlers.PanelTransferHandler;

public class WindowFrame {

	public JFrame frame = null;

	private JPanel panelA = null;
	private JPanel panelB = null;

	private ArrayList<DraggablePanel> panelAElements = null;
	private ArrayList<DraggablePanel> panelBElements = null;

	public WindowFrame() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();

		frame.setTitle("Programa de Notas");
		frame.setSize(800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(1, 2));

		panelA = new JPanel(new GridLayout(2, 2, 10, 10));
		panelA.setBorder(BorderFactory.createTitledBorder("APROBADOS"));
		frame.getContentPane().add(panelA);

		panelB = new JPanel(new GridLayout(2, 2, 10, 10));
		panelB.setBorder(BorderFactory.createTitledBorder("SUSPENDIDOS"));
		frame.getContentPane().add(panelB);

		panelAElements = new ArrayList<DraggablePanel>();
		panelBElements = new ArrayList<DraggablePanel>();

		// Enable Drag & Drop on both panels
		new DropTarget(panelA, new PanelDropTargetAdapter(this, panelAElements, panelBElements));
		new DropTarget(panelB, new PanelDropTargetAdapter(this, panelBElements, panelAElements));

		// Add draggablePanels to panelA
		for (int i = 1; i <= 4; i++) {
			DraggablePanel draggablePanel = createDraggablePanel(getRandomName (), i);
			panelAElements.add(draggablePanel);
			panelA.add(draggablePanel);
		}

		refreshPanels();
	}

	/**
	 * Returns a DraggablePanel, which is basically a JPanel that can be dragged
	 * with the mouse
	 * 
	 * @param text The text in the DraggablePanel
	 * @param id   The id used to identify the DraggablePanel
	 * @return the DraggablePanel
	 */
	private DraggablePanel createDraggablePanel(String text, int id) {
		DraggablePanel ret = new DraggablePanel(text, id);
		ret.setBackground(new Color((int) (Math.random() * 0x1000000))); // Random color
		ret.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		ret.setPreferredSize(new Dimension(100, 100));

		// Enable to be dragged
		ret.setTransferHandler(new PanelTransferHandler());
		ret.addMouseListener(new DragMouseAdapter());

		return ret;
	}

	/**
	 * Refreshes, repaints and revalidates the panels
	 */
	public void refreshPanels() {
		refreshPanelA();
		refreshPanelB();
	}

	private void refreshPanelA() {
		panelA.removeAll();
		for (DraggablePanel p : panelAElements) {
			panelA.add(p);
		}
		panelA.revalidate();
		panelA.repaint();
	}

	private void refreshPanelB() {
		panelB.removeAll();
		for (DraggablePanel p : panelBElements) {
			panelB.add(p);
		}
		panelB.revalidate();
		panelB.repaint();
	}

	private String getRandomName () {
		String array [] = {"Alain", "Alvaro", "Solange", "Ruben", "Haritz", "Khaled"};
		return array[new Random().nextInt(array.length)];
	}
	
	public JPanel getPanelA() {
		return panelA;
	}

	public JPanel getPanelB() {
		return panelB;
	}

	public ArrayList<DraggablePanel> getPanelAComponents() {
		return panelAElements;
	}

	public ArrayList<DraggablePanel> getPanelBComponents() {
		return panelBElements;
	}
}
