package studentEvaluator;

import java.awt.EventQueue;
import studentEvaluator.engine.WindowFrame;

public class StudentEvaluatorMainLauncherClass {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					(new WindowFrame()).frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
