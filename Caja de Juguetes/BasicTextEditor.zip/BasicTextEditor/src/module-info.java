/**
 * 
 */
/**
 * @author borja
 *
 */
module BasicTextEditor {
	requires java.desktop;
}