/**
 * 
 */
/**
 * @author borja
 *
 */
module TextBasedAdventure {
	requires java.desktop;
	requires json.simple;
}