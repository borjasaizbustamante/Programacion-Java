package textBasedAdventure;

import java.awt.EventQueue;
import java.io.IOException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;

import org.json.simple.parser.ParseException;

import textBasedAdventure.engine.Parser;
import textBasedAdventure.engine.beans.Blocks;
import textBasedAdventure.engine.beans.GoTo;
import textBasedAdventure.view.GestorDelInterfaz;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

/**
 * Un programita sencillo para hacer aventuras de tipo texto. Para escribir tu
 * propia aventura, solo tienes que cambiar el ficheo seed.json por lo que
 * quieras poner.
 * 
 * REGLAS:  - No puedes repetir IDs.
 * 			- Las IDs de los GoTos es a donde quieres ir
 * 			- No puede haber mas de cuatro opciones
 * 			- Si quieres terminar un camino [Un final] pon GoTos vacios.  
 */
public class TextBasedAdventure {

	private JFrame frmAventuraDeTexto;
	private JTextPane textPanel = null;
	JButton buttonGoto1 = null;
	JButton buttonGoto2 = null;
	JButton buttonGoto3 = null;
	JButton buttonGoto4 = null;
	private Blocks blocks = null;
	private int currentBlockId = 0;

	/**
	 * Main de la clase
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TextBasedAdventure window = new TextBasedAdventure();
					window.frmAventuraDeTexto.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructor
	 */
	public TextBasedAdventure() {
		try {
			blocks = Parser.getInstance().processSeed();
		} catch (IOException | ParseException e) {
			JOptionPane.showMessageDialog(null, "Error en el fichero de texto.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		initialize();
		showAllButtonGotos();
		textPanel.setText(GestorDelInterfaz.getInstance().displayInitialBlock(blocks));
		int numberOfGoTos = GestorDelInterfaz.getInstance().getNumberOfGoTos(blocks, 0);
		showHideButtonGotos(numberOfGoTos);
	}

	/**
	 * Inicializa la ventana
	 */
	private void initialize() {
		frmAventuraDeTexto = new JFrame();
		frmAventuraDeTexto.setTitle("Aventura de Texto");
		frmAventuraDeTexto.setBounds(300, 100, 800, 320);
		frmAventuraDeTexto.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAventuraDeTexto.getContentPane().setLayout(null);

		textPanel = new JTextPane();
		textPanel.setFont(new Font("Verdana Pro", Font.PLAIN, 14));
		textPanel.setEditable(false);
		textPanel.setBounds(10, 26, 510, 222);
		frmAventuraDeTexto.getContentPane().add(textPanel);

		buttonGoto1 = new JButton("Opcion 1");
		buttonGoto1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(1);
			}
		});
		buttonGoto1.setBounds(582, 26, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto1);

		buttonGoto2 = new JButton("Opcion 2");
		buttonGoto2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(2);
			}
		});
		buttonGoto2.setBounds(582, 86, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto2);

		buttonGoto3 = new JButton("Opcion 3");
		buttonGoto3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(3);
			}
		});
		buttonGoto3.setBounds(582, 146, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto3);

		buttonGoto4 = new JButton("Opcion 4");
		buttonGoto4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(4);
			}
		});
		buttonGoto4.setBounds(582, 206, 143, 49);
		frmAventuraDeTexto.getContentPane().add(buttonGoto4);
	}

	/**
	 * Muestra todos los botones
	 */
	private void showAllButtonGotos() {
		buttonGoto1.setVisible(true);
		buttonGoto2.setVisible(true);
		buttonGoto3.setVisible(true);
		buttonGoto4.setVisible(true);
	}

	/**
	 * Oculta los botones en base al numero de goTos del bloque actual
	 * 
	 * @param numberOfGoTos
	 */
	private void showHideButtonGotos(int numberOfGoTos) {
		switch (numberOfGoTos) {
		case 0:
			buttonGoto1.setVisible(false);
		case 1:
			buttonGoto2.setVisible(false);
		case 2:
			buttonGoto3.setVisible(false);
		case 3:
			buttonGoto4.setVisible(false);
		case 4: // Nothing...
		}
	}

	/**
	 * Seleccionamos la opcion del menu
	 * 
	 * @param opcion
	 */
	private void moveToOption(int opcion) {
		List<GoTo> goTos = GestorDelInterfaz.getInstance().getGoTosToDisplay(blocks, currentBlockId);
		if (null != goTos) {
			GoTo goTo = goTos.get(opcion - 1);
			if (null != goTo) {
				currentBlockId = goTo.getId();
				showAllButtonGotos();
				textPanel.setText(GestorDelInterfaz.getInstance().displayBlock(blocks, currentBlockId));
				int numberOfGoTos = GestorDelInterfaz.getInstance().getNumberOfGoTos(blocks, currentBlockId);
				showHideButtonGotos(numberOfGoTos);
			}
		}
	}
}
