package date;

import java.awt.EventQueue;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JFrame;

import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;

/**
 * Para que funcione, el datepicker.jar tiene que estar metido en
 * project>properties>libraries> CLASSPATH, no en modulepath 
 */
public class DatePicker {

	private JFrame frame;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DatePicker window = new DatePicker();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public DatePicker() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 300, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JDatePickerImpl datePicker = new JDatePickerImpl(new JDatePanelImpl(null));
		datePicker.setBounds(50, 50, 150, 30);

		datePicker.addActionListener(e -> {
			GregorianCalendar calendar = (GregorianCalendar) datePicker.getModel().getValue();
			Date selectedDate = calendar.getTime();
			System.out.println("Selected Date: " + selectedDate);
		});

		frame.getContentPane().add(datePicker);

	}

}
