package textBasedAdventure.pojo;

public class Ente {
	
	private String nombre = null;
	private String tipo = null;
	private int puntosVida = 0;
	private int puntosVidaActual = 0;
	private int puntosCombate = 0;
	private int puntosOscuros = 0;
	
	public Ente() {
		
	}

	public Ente(String nombre, String tipo, int puntosVida, int puntosVidaActual, int puntosCombate,
			int puntosOscuros) {
		super();
		this.nombre = nombre;
		this.tipo = tipo;
		this.puntosVida = puntosVida;
		this.puntosVidaActual = puntosVidaActual;
		this.puntosCombate = puntosCombate;
		this.puntosOscuros = puntosOscuros;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPuntosVida() {
		return puntosVida;
	}
	public void setPuntosVida(int puntosVida) {
		this.puntosVida = puntosVida;
	}
	public int getPuntosVidaActual() {
		return puntosVidaActual;
	}
	public void setPuntosVidaActual(int puntosVidaActual) {
		this.puntosVidaActual = puntosVidaActual;
	}
	public int getPuntosCombate() {
		return puntosCombate;
	}
	public void setPuntosCombate(int puntosCombate) {
		this.puntosCombate = puntosCombate;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getPuntosOscuros() {
		return puntosOscuros;
	}
	public void setPuntosOscuros(int puntosOscuros) {
		this.puntosOscuros = puntosOscuros;
	}

	@Override
	public String toString() {
		return "Ente [nombre=" + nombre + ", tipo=" + tipo + ", puntosVida=" + puntosVida + ", puntosVidaActual="
				+ puntosVidaActual + ", puntosCombate=" + puntosCombate + ", puntosOscuros=" + puntosOscuros + "]";
	}
	
	

}
