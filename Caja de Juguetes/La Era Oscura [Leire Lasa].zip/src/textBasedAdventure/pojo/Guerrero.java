package textBasedAdventure.pojo;

public class Guerrero {
	private String nombre = null;
	private int puntosVida = 0;
	private int puntosVidaActual = 0;
	private int puntosLuminicos = 0;
	private int puntosLuminicosActual = 0;
	private double fraccionResistencia = 0;
	private int puntosCombate = 0;
	private int fuerzaContraTerrenal = 0;
	private int fuerzaContraEspiritual = 0;
	
	public Guerrero() {
		
	}
	
	public Guerrero(String nombre, int puntosVida, int puntosVidaActual, int puntosLuminicos, int puntosLuminicosActual,
			double fraccionResistencia, int puntosCombate, int fuerzaContraTerrenal, int fuerzaContraEspiritual) {
		super();
		this.nombre = nombre;
		this.puntosVida = puntosVida;
		this.puntosVidaActual = puntosVidaActual;
		this.puntosLuminicos = puntosLuminicos;
		this.puntosLuminicosActual = puntosLuminicosActual;
		this.fraccionResistencia = fraccionResistencia;
		this.puntosCombate = puntosCombate;
		this.fuerzaContraTerrenal = fuerzaContraTerrenal;
		this.fuerzaContraEspiritual = fuerzaContraEspiritual;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getPuntosVida() {
		return puntosVida;
	}
	public void setPuntosVida(int puntosVida) {
		this.puntosVida = puntosVida;
	}
	public int getPuntosLuminicos() {
		return puntosLuminicos;
	}
	public void setPuntosLuminicos(int puntosLuminicos) {
		this.puntosLuminicos = puntosLuminicos;
	}
	public double getFraccionResistencia() {
		return fraccionResistencia;
	}
	public void setFraccionResistencia(double fraccionResistencia) {
		this.fraccionResistencia = fraccionResistencia;
	}
	public int getPuntosCombate() {
		return puntosCombate;
	}
	public void setPuntosCombate(int puntosCombate) {
		this.puntosCombate = puntosCombate;
	}
	public int getPuntosVidaActual() {
		return puntosVidaActual;
	}
	public void setPuntosVidaActual(int puntosVidaActual) {
		this.puntosVidaActual = puntosVidaActual;
	}
	public int getPuntosLuminicosActual() {
		return puntosLuminicosActual;
	}
	public void setPuntosLuminicosActual(int puntosLuminicosActual) {
		this.puntosLuminicosActual = puntosLuminicosActual;
	}
	public int getFuerzaContraTerrenal() {
		return fuerzaContraTerrenal;
	}
	public void setFuerzaContraTerrenal(int fuerzaContraTerrenal) {
		this.fuerzaContraTerrenal = fuerzaContraTerrenal;
	}
	public int getFuerzaContraEspiritual() {
		return fuerzaContraEspiritual;
	}
	public void setFuerzaContraEspiritual(int fuerzaContraEspiritual) {
		this.fuerzaContraEspiritual = fuerzaContraEspiritual;
	}
	@Override
	public String toString() {
		return "Guerrero [nombre=" + nombre + ", puntosVida=" + puntosVida + ", puntosVidaActual=" + puntosVidaActual
				+ ", puntosLuminicos=" + puntosLuminicos + ", puntosLuminicosActual=" + puntosLuminicosActual
				+ ", fraccionResistencia=" + fraccionResistencia + ", puntosCombate=" + puntosCombate
				+ ", fuerzaContraTerrenal=" + fuerzaContraTerrenal + ", fuerzaContraEspiritual="
				+ fuerzaContraEspiritual + "]";
	}
	
	
}
