package textBasedAdventure;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.io.IOException;
import java.util.List;
import java.util.random.RandomGenerator;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

import org.json.simple.parser.ParseException;

import textBasedAdventure.engine.Parser;
import textBasedAdventure.engine.beans.Blocks;
import textBasedAdventure.engine.beans.GoTo;
import textBasedAdventure.pojo.Ente;
import textBasedAdventure.pojo.Guerrero;
import textBasedAdventure.view.GestorDelInterfaz;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Image;
import java.awt.Insets;

/**
 * Un programita sencillo para hacer aventuras de tipo texto. Para escribir tu
 * propia aventura, solo tienes que cambiar el ficheo seed.json por lo que
 * quieras poner.
 * 
 * REGLAS: - No puedes repetir IDs. - Las IDs de los GoTos es a donde quieres ir
 * - No puede haber mas de cuatro opciones - Si quieres terminar un camino [Un
 * final] pon GoTos vacios.
 */
public class LaEraOscura {

	private JFrame frameLaEraOscura;
	private JTextPane textPanel = null;
	private JScrollPane scrollPane = null;
	JButton buttonGoto1 = null;
	JButton buttonGoto2 = null;
	JButton buttonGoto3 = null;
	JButton buttonGoto4 = null;
	JPanel panelFoto = null;
	JLabel labelFoto = null;
	JPanel panelFondo = null;
	JLabel labelFondo = null;
	JProgressBar barraVida = null;
	JProgressBar barraLum = null;
	JLabel labelVida = null;
	JLabel labelLum = null;
	JLabel labelPCombate = null;
	JProgressBar barraVidaEnte = null;
	JLabel labelVidaEnte = null;
	JLabel labelPCombateEnte = null;
	JLabel labelPOscurosEnte = null;
	private Blocks blocks = null;
	private int currentBlockId = 0;
	private Guerrero guerrero = null;
	private Ente ente = null;
	private Ente lobo = null;
	private Ente oso = null;
	private Ente ave = null;
	private Ente dragon = null;
	private Ente lunaEsp = null;
	private Ente lunaTer = null;
	private Ente maestro = null;
	private Ente mujerTribu = null;
	private Ente metamorfo = null;
	private Ente guardianEsp = null;
	private Ente guardianTer = null;
	private Ente oscuro = null;
	private int random = 0;
	private int contadorCamino2 = 0;

	/**
	 * Main de la clase
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LaEraOscura window = new LaEraOscura();
					window.frameLaEraOscura.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Constructor
	 */
	public LaEraOscura() {
		try {
			blocks = Parser.getInstance().processSeed();
		} catch (IOException | ParseException e) {
			JOptionPane.showMessageDialog(null, "Error en el fichero de texto.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		initialize();
		showAllButtonGotos();
		textPanel.setText(GestorDelInterfaz.getInstance().displayInitialBlock(blocks));
		// addImage(panelFoto, labelFoto,
		// GestorDelInterfaz.getInstance().getFotoToDisplay(blocks, currentBlockId));
		addImage(panelFondo, labelFondo, GestorDelInterfaz.getInstance().getFondoToDisplay(blocks, currentBlockId));
		int numberOfGoTos = GestorDelInterfaz.getInstance().getNumberOfGoTos(blocks, 0);
		showHideButtonGotos(numberOfGoTos);
		hideBars();
		hideBarEnte();
	}

	/**
	 * Inicializa la ventana
	 */
	private void initialize() {
		inicializarEntesYGuerrero();

		frameLaEraOscura = new JFrame();
		frameLaEraOscura.setBounds(100, 100, 1000, 700);
		frameLaEraOscura.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameLaEraOscura.setLocationRelativeTo(null);
		frameLaEraOscura.setTitle("La Era Oscura");
		frameLaEraOscura.getContentPane().setLayout(null);
		frameLaEraOscura.getContentPane().setBackground(Color.black);
		/*
		 * panelFoto = new JPanel(); panelFoto.setBackground(Color.BLACK);
		 * panelFoto.setBounds(10, 260, 300, 200);
		 * frmAventuraDeTexto.getContentPane().add(panelFoto); panelFoto.setLayout(new
		 * BorderLayout(0, 0));
		 * 
		 * labelFoto = new JLabel(""); panelFoto.add(labelFoto, BorderLayout.CENTER);
		 */
		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

		textPanel = new JTextPane();
		textPanel.setFont(new Font("Verdana Pro", Font.PLAIN, 14));
		textPanel.setEditable(false);
		textPanel.setMargin(new Insets(20, 20, 20, 20));
		textPanel.setBackground(Color.black);
		textPanel.setForeground(Color.white);

		scrollPane.setBounds(0, 550, 800, 150);
		scrollPane.getViewport().add(textPanel);
		scrollPane.setBorder(null);
		frameLaEraOscura.getContentPane().add(scrollPane);

		buttonGoto1 = new JButton("Opcion 1");
		buttonGoto1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(1);
			}
		});
		buttonGoto1.setBounds(850, 550, 120, 35);
		frameLaEraOscura.getContentPane().add(buttonGoto1);

		buttonGoto2 = new JButton("Opcion 2");
		buttonGoto2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(2);
			}
		});
		buttonGoto2.setBounds(850, 590, 120, 35);
		frameLaEraOscura.getContentPane().add(buttonGoto2);

		buttonGoto3 = new JButton("Opcion 3");
		buttonGoto3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(3);
			}
		});
		buttonGoto3.setBounds(850, 630, 120, 35);
		frameLaEraOscura.getContentPane().add(buttonGoto3);

		buttonGoto4 = new JButton("Opcion 4");
		buttonGoto4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveToOption(4);
			}
		});
		buttonGoto4.setBounds(850, 670, 120, 35);
		frameLaEraOscura.getContentPane().add(buttonGoto4);

		barraVida = new JProgressBar();
		barraVida.setMaximum(guerrero.getPuntosVida());
		barraVida.setBounds(70, 25, 70, 20);
		frameLaEraOscura.getContentPane().add(barraVida);
		barraVida.setValue(guerrero.getPuntosVidaActual());

		barraLum = new JProgressBar();
		barraLum.setMaximum(guerrero.getPuntosLuminicos());
		barraLum.setBounds(200, 25, 70, 20);
		frameLaEraOscura.getContentPane().add(barraLum);
		barraLum.setValue(guerrero.getPuntosLuminicosActual());

		labelVida = new JLabel("");
		labelVida.setForeground(Color.white);
		labelVida.setBounds(70, 40, 70, 20);
		frameLaEraOscura.getContentPane().add(labelVida);

		labelLum = new JLabel("");
		labelLum.setForeground(Color.white);
		labelLum.setBounds(200, 40, 70, 20);
		frameLaEraOscura.getContentPane().add(labelLum);

		labelPCombate = new JLabel("");
		labelPCombate.setForeground(Color.white);
		labelPCombate.setBounds(340, 25, 70, 20);
		frameLaEraOscura.getContentPane().add(labelPCombate);

		barraVidaEnte = new JProgressBar();
		barraVidaEnte.setMaximum(ente.getPuntosVida());
		barraVidaEnte.setBounds(70, 500, 70, 20);
		frameLaEraOscura.getContentPane().add(barraVidaEnte);
		barraVidaEnte.setValue(ente.getPuntosVidaActual());

		labelVidaEnte = new JLabel("");
		labelVidaEnte.setForeground(Color.white);
		labelVidaEnte.setBounds(70, 515, 70, 20);
		frameLaEraOscura.getContentPane().add(labelVidaEnte);

		labelPCombateEnte = new JLabel("");
		labelPCombateEnte.setForeground(Color.white);
		labelPCombateEnte.setBounds(310, 500, 70, 20);
		frameLaEraOscura.getContentPane().add(labelPCombateEnte);

		labelPOscurosEnte = new JLabel("");
		labelPOscurosEnte.setForeground(Color.white);
		labelPOscurosEnte.setBounds(210, 500, 70, 20);
		frameLaEraOscura.getContentPane().add(labelPOscurosEnte);

		panelFondo = new JPanel();
		panelFondo.setBackground(Color.RED);
		panelFondo.setBounds(0, 0, 1000, 550);
		frameLaEraOscura.getContentPane().add(panelFondo);
		panelFondo.setLayout(new BorderLayout(0, 0));

		labelFondo = new JLabel("");
		panelFondo.add(labelFondo, BorderLayout.CENTER);
	}

	/**
	 * Muestra todos los botones
	 */
	private void showAllButtonGotos() {
		buttonGoto1.setVisible(true);
		buttonGoto2.setVisible(true);
		buttonGoto3.setVisible(true);
		buttonGoto4.setVisible(true);
	}

	/**
	 * Oculta los botones en base al numero de goTos del bloque actual
	 * 
	 * @param numberOfGoTos
	 */
	private void showHideButtonGotos(int numberOfGoTos) {
		switch (numberOfGoTos) {
		case 0:
			buttonGoto1.setVisible(false);
		case 1:
			buttonGoto2.setVisible(false);
		case 2:
			buttonGoto3.setVisible(false);
		case 3:
			buttonGoto4.setVisible(false);
		case 4: // Nothing...
		}
	}

	/**
	 * Seleccionamos la opcion del menu
	 * 
	 * @param opcion
	 */
	private void moveToOption(int opcion) {

		List<GoTo> goTos = GestorDelInterfaz.getInstance().getGoTosToDisplay(blocks, currentBlockId);
		if (null != goTos) {
			GoTo goTo = goTos.get(opcion - 1);
			if (null != goTo) {
				/*
				 * System.out.println(currentBlockId); System.out.println(guerrero.toString());
				 * System.out.println(ente.toString());
				 */
				currentBlockId = goTo.getId();
				showAllButtonGotos();
				textPanel.setText(GestorDelInterfaz.getInstance().displayBlock(blocks, currentBlockId));
				// addImage(panelFoto, labelFoto,
				// GestorDelInterfaz.getInstance().getFotoToDisplay(blocks, currentBlockId));
				addImage(panelFondo, labelFondo,
						GestorDelInterfaz.getInstance().getFondoToDisplay(blocks, currentBlockId));
				int numberOfGoTos = GestorDelInterfaz.getInstance().getNumberOfGoTos(blocks, currentBlockId);
				showHideButtonGotos(numberOfGoTos);
				if (currentBlockId == 0) {
					hideBars();
				}
				
				if (currentBlockId == 9) {
					contadorCamino2++;
				}
				
				recorrerCaminos();
				
				cambiarFondo();
				
				if (guerrero.getNombre() != null) {
					haMuerto();
				}

			}
		}
	}

	private void addImage(JPanel panel, JLabel label, String direccion) {
		ImageIcon icon = new ImageIcon(direccion);
		Image img = icon.getImage();
		Image resizedImg = img.getScaledInstance(panel.getWidth(), panel.getHeight(), Image.SCALE_SMOOTH);
		icon.setImage(resizedImg);
		label.setIcon(icon);
	}

	private void hideBars() {
		barraVida.setVisible(false);
		barraLum.setVisible(false);
		labelVida.setVisible(false);
		labelLum.setVisible(false);
		labelPCombate.setVisible(false);
	}

	private void showBars() {
		barraVida.setVisible(true);
		barraLum.setVisible(true);
		labelVida.setVisible(true);
		labelLum.setVisible(true);
		labelPCombate.setVisible(true);
	}

	private void hideBarEnte() {
		barraVidaEnte.setVisible(false);
		labelVidaEnte.setVisible(false);
		labelPCombateEnte.setVisible(false);
		labelPOscurosEnte.setVisible(false);
	}

	private void showBarEnte() {
		barraVidaEnte.setVisible(true);
		labelVidaEnte.setVisible(true);
		labelPCombateEnte.setVisible(true);
		labelPOscurosEnte.setVisible(true);

		labelPCombateEnte.setText("" + ente.getPuntosCombate());
		labelPOscurosEnte.setText("" + ente.getPuntosOscuros());
		labelVidaEnte.setText(ente.getPuntosVidaActual() + "/" + ente.getPuntosVida());
		barraVidaEnte.setMaximum(ente.getPuntosVida());
		barraVidaEnte.setValue(ente.getPuntosVidaActual());
	}

	private void crearGuerrero(int num) {
		if (num == 4) {
			guerrero = new Guerrero("Darkcal", 200, 200, 120, 120, 0.2, 25, 1, 2);
		} else if (num == 5) {
			guerrero = new Guerrero("Isur", 300, 300, 100, 100, 0, 40, 2, 1);
		}

		actualizarPanelesGuerrero();
	}

	private void combate(Ente ente) {
		showBarEnte();

		int vidaEnte = ente.getPuntosVidaActual();
		int vidaGuerrero = guerrero.getPuntosVidaActual();
		int lumGuerrero = guerrero.getPuntosLuminicosActual();
		int pCombateGuerrero = guerrero.getPuntosCombate();
		int pCombateEnte = ente.getPuntosCombate();
		int pOscurosEnte = ente.getPuntosOscuros();

		do {
			if (vidaGuerrero > 0 && lumGuerrero > 0 && vidaEnte > 0) {
				if (ente.getTipo().equalsIgnoreCase("terrenal")) {
					pCombateGuerrero *= guerrero.getFuerzaContraTerrenal();
				} else if (ente.getTipo().equalsIgnoreCase("espiritual")) {
					pCombateGuerrero *= guerrero.getFuerzaContraEspiritual();
				}

				vidaEnte -= pCombateGuerrero;

				if (vidaEnte < 0) {
					vidaEnte = 0;
				}

				if (vidaEnte > 0) {
					vidaGuerrero -= pCombateEnte;
					lumGuerrero -= pOscurosEnte - pOscurosEnte * guerrero.getFraccionResistencia();

					if (vidaGuerrero < 0) {
						vidaGuerrero = 0;
					}
					if (lumGuerrero < 0) {
						lumGuerrero = 0;
					}
				}
			}
			guerrero.setPuntosVidaActual(vidaGuerrero);
			guerrero.setPuntosLuminicosActual(lumGuerrero);
			ente.setPuntosVidaActual(vidaEnte);
		} while ((vidaEnte > 0) && (vidaGuerrero > 0) && (lumGuerrero > 0));

		actualizarPanelesGuerrero();
		actualizarPanelesEnte();
	}

	private void subirStats(int extraVida, int extraLum, int extraCombate) {
		guerrero.setPuntosVida((guerrero.getPuntosVida()) + extraVida);
		guerrero.setPuntosLuminicos((guerrero.getPuntosLuminicos()) + extraLum);
		guerrero.setPuntosCombate((guerrero.getPuntosCombate()) + extraCombate);

		actualizarPanelesGuerrero();
	}

	private void subirNivel(int extraVida, int extraLum, int extraCombate) {
		guerrero.setPuntosVida((guerrero.getPuntosVida()) + extraVida);
		guerrero.setPuntosVidaActual((guerrero.getPuntosVidaActual()) + extraVida);

		guerrero.setPuntosLuminicos((guerrero.getPuntosLuminicos()) + extraLum);
		guerrero.setPuntosLuminicosActual((guerrero.getPuntosLuminicosActual()) + extraLum);

		guerrero.setPuntosCombate((guerrero.getPuntosCombate()) + extraCombate);

		actualizarPanelesGuerrero();
	}

	private void restablecerStats(String tipo) {
		int vida = 0;
		int lum = 0;

		if (tipo.equalsIgnoreCase("vendaje")) {
			vida = 15;
			if ((guerrero.getPuntosVidaActual() + vida) > guerrero.getPuntosVida()) {
				guerrero.setPuntosVidaActual(guerrero.getPuntosVida());
			} else {
				guerrero.setPuntosVidaActual(guerrero.getPuntosVidaActual() + vida);
			}
		} else if (tipo.equalsIgnoreCase("botiquin")) {
			vida = 30;
			if ((guerrero.getPuntosVidaActual() + vida) > guerrero.getPuntosVida()) {
				guerrero.setPuntosVidaActual(guerrero.getPuntosVida());
			} else {
				guerrero.setPuntosVidaActual(guerrero.getPuntosVidaActual() + vida);
			}
		} else if (tipo.equalsIgnoreCase("purificador")) {
			lum = 20;
			if ((guerrero.getPuntosLuminicosActual() + lum) > guerrero.getPuntosLuminicos()) {
				guerrero.setPuntosLuminicosActual(guerrero.getPuntosLuminicos());
			} else {
				guerrero.setPuntosLuminicosActual(guerrero.getPuntosLuminicosActual() + lum);
			}
		} else if (tipo.equalsIgnoreCase("superpurificador")) {
			lum = 50;
			if ((guerrero.getPuntosLuminicosActual() + lum) > guerrero.getPuntosLuminicos()) {
				guerrero.setPuntosLuminicosActual(guerrero.getPuntosLuminicos());
			} else {
				guerrero.setPuntosLuminicosActual(guerrero.getPuntosLuminicosActual() + lum);
			}
		}

		actualizarPanelesGuerrero();
	}

	private void actualizarPanelesGuerrero() {
		barraVida.setMaximum(guerrero.getPuntosVida());
		barraLum.setMaximum(guerrero.getPuntosLuminicos());

		barraVida.setValue(guerrero.getPuntosVidaActual());
		barraLum.setValue(guerrero.getPuntosLuminicosActual());

		labelVida.setText(guerrero.getPuntosVidaActual() + "/" + guerrero.getPuntosVida());
		labelLum.setText(guerrero.getPuntosLuminicosActual() + "/" + guerrero.getPuntosLuminicos());

		labelPCombate.setText("" + guerrero.getPuntosCombate());
	}

	private void actualizarPanelesEnte() {
		labelVidaEnte.setText(ente.getPuntosVidaActual() + "/" + ente.getPuntosVida());
		barraVidaEnte.setValue(ente.getPuntosVidaActual());
	}

	private void cambiarPuntos(String tipo, int puntos) {
		int vida = 0;
		int lum = 0;

		if (tipo.equalsIgnoreCase("vida")) {
			vida = puntos;
			guerrero.setPuntosVidaActual(guerrero.getPuntosVidaActual() + vida);
		} else if (tipo.equalsIgnoreCase("lum")) {
			lum = puntos;
			guerrero.setPuntosLuminicosActual(guerrero.getPuntosLuminicosActual() + lum);
		}

		actualizarPanelesGuerrero();
	}

	private void haMuerto() {
		int vida = guerrero.getPuntosVidaActual();
		int lum = guerrero.getPuntosLuminicosActual();
		if ((vida <= 0) || (lum <= 0)) {
			currentBlockId = 65;
			addImage(panelFondo, labelFondo, "img/bgDeath.jpeg");
			hideBarEnte();
			textPanel.setText("Tu Guerrero del Sol ha fallecido.\n\n     1) Reintentar");

			inicializarEntesYGuerrero();
			contadorCamino2 = 0;
		}
	}
	
	private int generarRandom() {
		 int ret = RandomGenerator.getDefault().nextInt(0, 3);
		 System.out.println(ret);

		return ret;
	}
	
	private void cambiarFondo() {
		if (contadorCamino2 != 0) {
			if (currentBlockId == 32) {
				addImage(panelFondo, labelFondo, "img/bg129.jpeg");
			} else if (currentBlockId == 35 || currentBlockId == 39) {
				addImage(panelFondo, labelFondo, "img/bg130.jpeg");
			} else if (currentBlockId == 37 || currentBlockId == 41) {
				addImage(panelFondo, labelFondo, "img/bg131.jpeg");
			} else if (currentBlockId == 36) {
				addImage(panelFondo, labelFondo, "img/bg134.jpeg");
			} else if (currentBlockId == 42) {
				addImage(panelFondo, labelFondo, "img/bg132.jpeg");
			} else if (currentBlockId == 38 || currentBlockId == 40) {
				addImage(panelFondo, labelFondo, "img/bg133.jpeg");
			} else if (currentBlockId == 33) {
				addImage(panelFondo, labelFondo, "img/bg135.jpeg");
			} else if (currentBlockId == 43) {
				addImage(panelFondo, labelFondo, "img/bg136.jpeg");
			} else if (currentBlockId == 44) {
				addImage(panelFondo, labelFondo, "img/bg137.jpeg");
			} else if (currentBlockId == 47) {
				addImage(panelFondo, labelFondo, "img/bg138.jpeg");
			} else if (currentBlockId == 45) {
				addImage(panelFondo, labelFondo, "img/bg139.jpeg");
			} else if (currentBlockId == 46) {
				addImage(panelFondo, labelFondo, "img/bg140.jpeg");
			} else if (currentBlockId == 48) {
				addImage(panelFondo, labelFondo, "img/bg141.jpeg");
			} else if (currentBlockId == 34) {
				addImage(panelFondo, labelFondo, "img/bg142.jpeg");
			} else if (currentBlockId == 49) {
				addImage(panelFondo, labelFondo, "img/bg143.jpeg");
			} else if (currentBlockId == 51) {
				addImage(panelFondo, labelFondo, "img/bg144.jpeg");
			} else if (currentBlockId == 52) {
				addImage(panelFondo, labelFondo, "img/bg145.jpeg");
			} else if (currentBlockId == 50) {
				addImage(panelFondo, labelFondo, "img/bg146.jpeg");
			} else if (currentBlockId == 53 || currentBlockId == 55) {
				addImage(panelFondo, labelFondo, "img/bg147.jpeg");
			} else if (currentBlockId == 54) {
				addImage(panelFondo, labelFondo, "img/bg148.jpeg");
			} else if (currentBlockId == 30) {
				addImage(panelFondo, labelFondo, "img/bg127.jpeg");
			} else if (currentBlockId == 31) {
				addImage(panelFondo, labelFondo, "img/bg72.jpeg");
			}
		}
	}
	
	private void inicializarEntesYGuerrero() {
		guerrero = new Guerrero();
		ente = new Ente();

		lobo = new Ente("Lobo", "terrenal", 85, 85, 15, 10);
		lunaEsp = new Ente("Guerrero de la Luna", "espiritual", 120, 120, 60, 30);
		oso = new Ente("Oso", "terrenal", 90, 90, 20, 15);
		ave = new Ente("Ave", "espiritual", 90, 90, 25, 10);
		
		maestro = new Ente("El Maestro", "humano", 85, 85, 30, 0);
		metamorfo = new Ente("Metamorfo", "terrenal", 90, 90, 15, 10);
		guardianEsp = new Ente("Guardian del Molino", "espiritual", 300, 300, 40, 20);
		oscuro = new Ente("Oscuro", "dios", 500, 500, 120, 120);

		dragon = new Ente("Dragon", "espiritual", 100, 100, 25, 15);
		lunaTer = new Ente("Guerrero de la Luna", "terrenal", 100, 100, 50, 15);
		guardianTer = new Ente("Guardian del Molino", "terrenal", 300, 300, 40, 20);
		mujerTribu = new Ente("Mujer de la Aldea del Bosque", "humano", 70, 70, 20, 0);
	}
	
	private void recorrerCaminos() {
		if (currentBlockId == 4) {
			crearGuerrero(currentBlockId);
		} else if (currentBlockId == 5) {
			crearGuerrero(currentBlockId);
		} else if (currentBlockId == 6) {
			showBars();
		} else if (currentBlockId == 10) {
			ente = lobo;
			showBarEnte();
		} else if (currentBlockId == 11) {
			hideBarEnte();
			cambiarPuntos("lum", -30);
		} else if (currentBlockId == 12) {
			combate(ente);
		} else if (currentBlockId == 13) {
			hideBarEnte();
			restablecerStats("vendaje");
			restablecerStats("purificador");
		} else if (currentBlockId == 14) {
			ente = lunaEsp;
			showBarEnte();
		} else if (currentBlockId == 15) {
			random = generarRandom();
			if (random == 1 || random == 2 || random == 3) {
				lunaEsp.setPuntosCombate(90);
				lunaEsp.setPuntosOscuros(40);
				lunaEsp.setPuntosVida(175);
				lunaEsp.setPuntosVidaActual(175);
			}
			ente = lunaEsp;
			showBarEnte();
		} else if (currentBlockId == 16) {
			combate(ente);
		} else if (currentBlockId == 17) {
			hideBarEnte();
			subirNivel(20, 10, 10);
		} else if (currentBlockId == 22) {
			restablecerStats("vendaje");
			cambiarPuntos("lum", 20);
		} else if (currentBlockId == 23) {
			cambiarPuntos("lum", -20);
		} else if (currentBlockId == 21) {
			ente = oso;
			showBarEnte();
		} else if (currentBlockId == 25) {
			combate(ente);
		} else if (currentBlockId == 26) {
			hideBarEnte();
			restablecerStats("botiquin");
		} else if (currentBlockId == 27) {
			subirStats(20, 0, 0);
			restablecerStats("botiquin");
		} else if (currentBlockId == 28) {
			ente = ave;
			showBarEnte();
		} else if (currentBlockId == 29) {
			combate(ente);
		} else if (currentBlockId == 24) {
			hideBarEnte();
		} else if (currentBlockId == 30) {
			subirStats(0, 30, 0);
			guerrero.setFraccionResistencia(guerrero.getFraccionResistencia() + 0.25);
			restablecerStats("vendaje");
			restablecerStats("purificador");
			restablecerStats("purificador");
		} else if (currentBlockId == 35) {
			ente = maestro;
			showBarEnte();
			labelPOscurosEnte.setVisible(false);
		} else if (currentBlockId == 37) {
			combate(ente);
			labelPOscurosEnte.setVisible(false);
		} else if (currentBlockId == 38) {
			hideBarEnte();
		} else if (currentBlockId == 39) {
			maestro.setPuntosVida(100);
			maestro.setPuntosVidaActual(100);
			ente = maestro;
			showBarEnte();
			labelPOscurosEnte.setVisible(false);
		} else if (currentBlockId == 41) {
			combate(ente);
			labelPOscurosEnte.setVisible(false);
		} else if (currentBlockId == 42) {
			hideBarEnte();
			subirStats(0, 0, 40);
			restablecerStats("botiquin");
			restablecerStats("botiquin");
		} else if (currentBlockId == 44) {
			ente = metamorfo;
			showBarEnte();
		} else if (currentBlockId == 47) {
			combate(ente);
		} else if (currentBlockId == 48) {
			hideBarEnte();
		} else if (currentBlockId == 45) {
			subirStats(20, 0, 30);
			cambiarPuntos("lum", -10);
			cambiarPuntos("vida", 50);
		} else if (currentBlockId == 46) {
			restablecerStats("botiquin");
			restablecerStats("purificador");
		} else if (currentBlockId == 49) {
			if (contadorCamino2 == 0) {
				ente = guardianEsp;
			} else {
				ente = guardianTer;
			}
			showBarEnte();
		} else if (currentBlockId == 51) {
			combate(guardianEsp);
		} else if (currentBlockId == 52) {
			hideBarEnte();
			subirNivel(20, 10, 30);
			restablecerStats("botiquin");
			restablecerStats("superpurificador");
		} else if (currentBlockId == 50) {
			restablecerStats("vendaje");
		} else if (currentBlockId == 53) {
			ente = oscuro;
			showBarEnte();
		} else if (currentBlockId == 54) {
			combate(ente);
		} else if (currentBlockId == 55) {
			oscuro.setPuntosCombate(80);
			oscuro.setPuntosOscuros(90);
			oscuro.setPuntosVidaActual(250);
			oscuro.setPuntosVida(250);
			showBarEnte();
		} else if (currentBlockId == 56) {
			hideBarEnte();
		} else if (currentBlockId == 57) {
			combate(ente);
			hideBarEnte();
		}

		
		
		else if (currentBlockId == 9) {
			cambiarPuntos("lum", -10);
		} else if (currentBlockId == 58) {
			ente = dragon;
			showBarEnte();
		} else if (currentBlockId == 60) {
			combate(ente);
		} else if (currentBlockId == 61) {
			hideBarEnte();
		} else if (currentBlockId == 59) {
			cambiarPuntos("lum", -30);
		} else if (currentBlockId == 62) {
			restablecerStats("vendaje");
			restablecerStats("purificador");
		} else if (currentBlockId == 66) {
			cambiarPuntos("vida", -20);
		} else if (currentBlockId == 69) {
			ente = lunaTer;
			showBarEnte();
		} else if (currentBlockId == 70) {
			random = generarRandom();
			if (random == 1 || random == 2 || random == 3) {
				lunaTer.setPuntosCombate(70);
				lunaTer.setPuntosOscuros(30);
				lunaTer.setPuntosVida(150);
				lunaTer.setPuntosVidaActual(150);
			}
			ente = lunaTer;
			showBarEnte();
		} else if (currentBlockId == 71) {
			combate(ente);
		} else if (currentBlockId == 72) {
			hideBarEnte();
			subirNivel(20, 10, 10);
			restablecerStats("botiquin");
		} else if (currentBlockId == 75) {
			ente = lunaTer;
			showBarEnte();
		} else if (currentBlockId == 77) {
			combate(ente);
		} else if (currentBlockId == 78) {
			hideBarEnte();
			subirNivel(20, 10, 10);
			subirStats(20, 0, 0);
			restablecerStats("botiquin");
		} else if (currentBlockId == 76) {
			cambiarPuntos("vida", 15);
			cambiarPuntos("lum", -20);
		} else if (currentBlockId == 80) {
			lunaTer.setPuntosCombate(60);
			lunaTer.setPuntosOscuros(20);
			lunaTer.setPuntosVida(120);
			lunaTer.setPuntosVidaActual(120);
			ente = lunaTer;
			showBarEnte();
		} else if (currentBlockId == 81) {
			combate(ente);
		} else if (currentBlockId == 82) {
			hideBarEnte();
			subirNivel(20, 10, 10);
		} else if (currentBlockId == 74) {
			cambiarPuntos("lum", -10);
		} else if (currentBlockId == 83) {
			ente = mujerTribu;
			showBarEnte();
			labelPOscurosEnte.setVisible(false);
		} else if (currentBlockId == 85) {
			combate(ente);
			labelPOscurosEnte.setVisible(false);
		} else if (currentBlockId == 86) {
			hideBarEnte();
			restablecerStats("vendaje");
		} else if (currentBlockId == 84) {
			restablecerStats("botiquin");
			restablecerStats("purificador");
		}
	}

}
