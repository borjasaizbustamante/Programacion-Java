package textBasedAdventure.engine.utils;

import java.io.File;

/**
 * Constantes del proyecto
 */
public class Utils {

	public static final String THE_SEED_FILE = new File("").getAbsolutePath() + "/src/textBasedAdventure/seed/seed.json";
	
}
