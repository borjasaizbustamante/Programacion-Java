package textBasedAdventure.engine.beans;

import java.io.Serializable;
import java.util.Objects;

/**
 * Las opciones de cada bloque
 */
public class GoTo implements Serializable {

	private static final long serialVersionUID = -8337501366632266425L;
	
	private int id;
	private String text;
	private String foto;
	private String fondo;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	public String getFondo() {
		return fondo;
	}
	public void setFondo(String fondo) {
		this.fondo = fondo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(foto, fondo, id, text);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GoTo other = (GoTo) obj;
		return Objects.equals(foto, other.foto) && Objects.equals(fondo, other.fondo) && id == other.id
				&& Objects.equals(text, other.text);
	}
	@Override
	public String toString() {
		return "GoTo [id=" + id + ", text=" + text + ", foto=" + foto + ", fondo=" + fondo + "]";
	}

	
}
