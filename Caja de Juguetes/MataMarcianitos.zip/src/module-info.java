/**
 * 
 */
/**
 * @author Jon
 *
 */
module MiniErronka {
	requires java.desktop;
}