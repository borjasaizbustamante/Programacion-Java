package arcade;

import arcade.game.Window;

/**
 * Inicia el juego - teclas w, a, s, d, espace
 */
public class MataMarcianitos {

	public static void main(String[] args) {
		(new Window()).initialize();
	}
}
