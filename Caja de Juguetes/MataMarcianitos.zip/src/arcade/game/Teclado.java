package arcade.game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Teclado del juego. Informa de que tecla esta siendo pulsada en ese instante
 */
public class Teclado implements KeyListener {

	private boolean teclaArriba = false;
	private boolean teclaAbajo = false;
	private boolean teclaIzquierda = false;
	private boolean teclaDerecha = false;
	private boolean teclaDisparo = false;

	@Override
	public void keyTyped(KeyEvent e) {
		cambiarEstadotecla(e);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		cambiarEstadotecla(e);
	}

	@Override
	public void keyReleased(KeyEvent e) {
		cambiarEstadotecla(e);
	}

	private void cambiarEstadotecla(KeyEvent e) {
		int tecla = e.getKeyCode();
		if (tecla == KeyEvent.VK_W)
			teclaArriba = !teclaArriba;
		if (tecla == KeyEvent.VK_S)
			teclaAbajo = !teclaAbajo;
		if (tecla == KeyEvent.VK_A)
			teclaIzquierda = !teclaIzquierda;
		if (tecla == KeyEvent.VK_D)
			teclaDerecha = !teclaDerecha;
		if (tecla == KeyEvent.VK_SPACE)
			teclaDisparo = !teclaDisparo;
	}

	public boolean isTeclaArriba() {
		return teclaArriba;
	}

	public boolean isTeclaAbajo() {
		return teclaAbajo;
	}

	public boolean isTeclaIzquierda() {
		return teclaIzquierda;
	}

	public boolean isTeclaDerecha() {
		return teclaDerecha;
	}

	public boolean isTeclaDisparo() {
		return teclaDisparo;
	}
}
