package arcade.game;

/**
 * Decide cuando dos objetos chocan entre ellos
 */
public class Colision {

	/**
	 * Retorna true cuando el proyectil colisiona con el enemigo, false en cualquier
	 * otro caso
	 * 
	 * @param coordenadaXProyectil
	 * @param coordenadaYProyectil
	 * @param anchoProyectil
	 * @param altoProyectil
	 * @param coordenadaXEnemigo
	 * @param coordenadaYEnemigo
	 * @param anchoEnemigo
	 * @param altoEnemigo
	 * @return true or false
	 */
	public static boolean ifColision(int coordenadaXProyectil, int coordenadaYProyectil, int anchoProyectil,
			int altoProyectil, int coordenadaXEnemigo, int coordenadaYEnemigo, int anchoEnemigo, int altoEnemigo) {

		boolean ifColisionX = false;
		boolean ifColisionY = false;

		if (coordenadaXProyectil + anchoProyectil > coordenadaXEnemigo
				&& coordenadaXProyectil < coordenadaXEnemigo + anchoEnemigo) {
			ifColisionX = true;
		}

		if (coordenadaYProyectil + altoProyectil > coordenadaYEnemigo
				&& coordenadaYProyectil < coordenadaYEnemigo + altoEnemigo) {
			ifColisionY = true;
		}

		return ifColisionX && ifColisionY;

	}
}
