package arcade.game.engine;

public class Cooldown {

	private static Cooldown instance = null;
	
	private static int cooldownDisparo = 0;
	private static int cooldownEnemigos = 0;
	
	public static final int DEFAULT_COOLDOWN_DISPARO = 100;
	public static final int DEFAULT_COOLDOWN_ENEMIGOS = 500;
	
	private Cooldown () {
		cooldownDisparo = 0;
		cooldownEnemigos = 0;
	}

	public static Cooldown getInstance () {
		return instance = null == instance?  new Cooldown() : instance;
	}
	
	/**
	 * Actualiza los cooldown
	 */
	public static void actualizarCooldown() {
		if (cooldownDisparo > 0)
			cooldownDisparo = cooldownDisparo - 1;
		if (cooldownEnemigos > 0)
			cooldownEnemigos = cooldownEnemigos - 1;
	}

	public static int getCooldownDisparo() {
		return cooldownDisparo;
	}

	public static void setCooldownDisparo(int cooldownDisparo) {
		Cooldown.cooldownDisparo = cooldownDisparo;
	}

	public static int getCooldownEnemigos() {
		return cooldownEnemigos;
	}

	public static void setCooldownEnemigos(int cooldownEnemigos) {
		Cooldown.cooldownEnemigos = cooldownEnemigos;		
	}
}
