package arcade.game.objetos;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * Cada uno de los diferentes objetos del juego 
 */
public abstract class ObjetoAbstract {

	private int x = 0;
	private int y = 0;
	private int velocidad = 0;
	private boolean colision = false;
	private Rectangle superficieDeColision = null;
	private BufferedImage imagen;
	
	/**
	 * Recalcula la posicion del objeto en la pantalla
	 */
	public abstract void reCalcular();
	
	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}

	public boolean isColision() {
		return colision;
	}

	public void setColision(boolean colision) {
		this.colision = colision;
	}

	public Rectangle getSuperficieDeColision() {
		return superficieDeColision;
	}

	public void setSuperficieDeColision(Rectangle superficieDeColision) {
		this.superficieDeColision = superficieDeColision;
	}
	
	public BufferedImage getImagen() {
		return imagen;
	}

	public void setImagen(String path) {
		try {
			imagen = ImageIO.read(new FileInputStream(path));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
