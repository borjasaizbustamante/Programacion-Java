package arcade.game.objetos;

public class Enemigo extends ObjetoAbstract {
	
	private int spawn = 0;

	public Enemigo() {
		super ();
	}

	public int getSpawn() {
		return spawn;
	}

	public void setSpawn(int spawn) {
		this.spawn = spawn;
	}

	@Override
	public void reCalcular() {
		setX(getX() - getVelocidad());
	}
}
