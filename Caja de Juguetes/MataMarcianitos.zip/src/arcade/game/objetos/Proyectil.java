package arcade.game.objetos;

public class Proyectil extends ObjetoAbstract {

	@Override
	public void reCalcular() {
		setX(getX() + getVelocidad());
	}
}
