package arcade.game.objetos;

/**
 * Nave - la nave del jugador
 */
public class Nave extends ObjetoAbstract {

	@Override
	public void reCalcular() {
		// TODO Auto-generated method stub
		
	}
}
