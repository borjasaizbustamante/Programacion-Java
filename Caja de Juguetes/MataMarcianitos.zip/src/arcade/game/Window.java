package arcade.game;

import javax.swing.JFrame;

/**
 * JFrame del juego
 */
public class Window extends JFrame{

	private static final long serialVersionUID = -8959091959193034760L;

	public void initialize() {
		
		// Ventana JFrame
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);	
		this.setTitle("Mata Marcianitos");
		
		// JPanel del juego
		Pantalla pantalla = new Pantalla();
		this.add(pantalla);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		// Iniciamos el juego
		pantalla.iniciarJuego();
	}
}
