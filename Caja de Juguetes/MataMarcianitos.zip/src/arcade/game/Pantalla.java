package arcade.game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;

import arcade.game.engine.Cooldown;
import arcade.game.objetos.Enemigo;
import arcade.game.objetos.Nave;
import arcade.game.objetos.Proyectil;

/**
 * Jpanel del juego
 */
public class Pantalla extends JPanel implements Runnable {

	private static final long serialVersionUID = -1722983958367637467L;

	private static final int PIXELES_SPRITE = 16;
	private static final int ESCALA = 3;
	private static final int TAMANIO_SPRITE = PIXELES_SPRITE * ESCALA;

	private final int alturaPantallaCuadra = 12;
	private final int anchuraPantallaCuadrada = 8;
	private final int alturaPantalla = TAMANIO_SPRITE * alturaPantallaCuadra;
	private final int anchuraPantalla = TAMANIO_SPRITE * anchuraPantallaCuadrada;

	private final int FPS = 20;

	private Thread thread = null;
	private Teclado teclado = null;

	private Nave nave = null;
	private List<Proyectil> proyectiles = null;
	private List<Enemigo> enemigosEnReserva = null;
	private List<Enemigo> enemigos = null;

	public Pantalla() {
		teclado = new Teclado();

		proyectiles = new ArrayList<Proyectil>();
		enemigosEnReserva = new ArrayList<Enemigo>();
		enemigos = new ArrayList<Enemigo>();

		this.setPreferredSize(new Dimension(alturaPantalla, anchuraPantalla));
		this.setBackground(Color.white);
		this.setDoubleBuffered(true);
		this.addKeyListener(teclado);
		this.setFocusable(true);
	}

	/**
	 * Crea el hilo de ejecucion para el juego. Ordena ejecutar de forma paralela al
	 * resto del programa el metodo run() de esta clase.
	 */
	public void iniciarJuego() {
		thread = new Thread(this);
		thread.start();
	}

	/**
	 * Pinta los componentes de la pantalla. Este metodo se dispara automaticamente.
	 */
	@Override
	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		Graphics2D graphics2D = (Graphics2D) graphics;

		// Los objetos se han movido, se repintan
		rePintarNave(graphics2D);
		rePintarProyectiles(graphics2D);
		rePintarEnemigos(graphics2D);

		// Algunos objetos han chocado con otro, se eliminan
		resolverColisiones();

		graphics2D.dispose();
	}

	/**
	 * Repinta la nave en su nueva posicion
	 * 
	 * @param graphics2D
	 */
	private void rePintarNave(Graphics2D graphics2D) {
		graphics2D.drawImage(nave.getImagen(), nave.getX(), nave.getY(), TAMANIO_SPRITE, TAMANIO_SPRITE, null);
	}

	/**
	 * Repinta los proyectiles en su nueva posicion
	 * 
	 * @param graphics2D
	 */
	private void rePintarProyectiles(Graphics2D graphics2D) {
		for (Proyectil proyectil : proyectiles) {
			proyectil.reCalcular();
			graphics2D.drawImage(proyectil.getImagen(), proyectil.getX(), proyectil.getY(), PIXELES_SPRITE,
					PIXELES_SPRITE, null);
		}
	}

	/**
	 * Repinta los enemigos en su nueva posicion
	 * 
	 * @param graphics2D
	 */
	private void rePintarEnemigos(Graphics2D graphics2D) {
		for (Enemigo enemigo : enemigos) {
			enemigo.reCalcular();
			graphics2D.drawImage(enemigo.getImagen(), enemigo.getX(), enemigo.getY(), TAMANIO_SPRITE, TAMANIO_SPRITE,
					null);
		}
	}

	/**
	 * Resuelve las colisiones de la nave, proyectiles y balas
	 * 
	 * @param proyectiles
	 * @param enemigos
	 */
	private void resolverColisiones() {
		List <Proyectil> proyectilesForDelete = Collections.synchronizedList(new ArrayList<Proyectil>());
		List <Enemigo> enemigosForDelete  = Collections.synchronizedList(new ArrayList<Enemigo>());
		
		for (Proyectil proyectil : proyectiles) {
			for (Enemigo enemigo : enemigos) {
				boolean ifColision = Colision.ifColision(proyectil.getX(), proyectil.getY(), PIXELES_SPRITE,
						PIXELES_SPRITE, enemigo.getX(), enemigo.getY(), TAMANIO_SPRITE, TAMANIO_SPRITE);
				if (ifColision) {
					proyectilesForDelete.add(proyectil);
					enemigosForDelete.add(enemigo);
				}
			}
		}
		
		for (Proyectil proyectil : proyectilesForDelete) {
			proyectiles.remove(proyectil);
		}
		
		for (Enemigo enemigo : enemigosForDelete) {
			enemigos.remove(enemigo);
		}
	}

	@Override
	public void run() {

		// Preparamos la Pantalla cargando la Nave, los enemigos, etc...

		// Añadimos la nave del jugador
		nave = new Nave();
		nave.setX(100);
		nave.setY(100);
		nave.setVelocidad(1);
		nave.setImagen("res/Nave.png");

		// Añadimos los enemigos en posiciones iniciales aleatorias
		// en el eje Y. En la X, fuera de la pantalla
		Random random = new Random();
		for (int i = 0; i < 100; i++) {
			Enemigo enemigo = new Enemigo();
			enemigo.setX(600);
			enemigo.setY(random.nextInt(300));
			enemigo.setVelocidad(1);
			enemigo.setSpawn(i);
			enemigo.setImagen("res/Invader.png");
			enemigosEnReserva.add(enemigo);
		}

		// Bucle de ejecucion del juego. Recalculamos las posiciones de
		// la nave, de los enemigos, etc., los repintamos en su nueva posición,
		// y luego esperamos
		Double drawInterval = (double) (100000000 / FPS);
		double nextDrawTime = System.nanoTime() + drawInterval;
		while (thread != null) {

			// Recalculamos la posicion de nave, enemigos...
			reCalcularPosicion(nave, proyectiles);

			// Repintamos la pantalla
			repaint();

			// Esperamos...
			try {
				double remainingTime = nextDrawTime - System.nanoTime();
				remainingTime = remainingTime / 10000000;
				if (remainingTime < 0)
					remainingTime = 0;

				Thread.sleep((long) remainingTime);
				nextDrawTime = nextDrawTime + drawInterval;
			} catch (InterruptedException e) {
				// Nothing to do here...
			}
		}
	}

	/**
	 * Recalcula la posicion de la nave en base al boton pulsado del teclado.
	 * 
	 * @param nave
	 * @param proyectiles
	 */
	private void reCalcularPosicion(Nave nave, List<Proyectil> proyectiles) {
		Cooldown.actualizarCooldown();
		moverNave(nave);
		addEnemigos();
	}

	/**
	 * Mueve la nave segun las teclas pulsadas y genera un disparo
	 * 
	 * @param nave
	 */
	private void moverNave(Nave nave) {
		if (teclado.isTeclaArriba())
			nave.setY(nave.getY() - nave.getVelocidad());
		if (teclado.isTeclaAbajo())
			nave.setY(nave.getY() + nave.getVelocidad());
		if (teclado.isTeclaIzquierda())
			nave.setX(nave.getX() - nave.getVelocidad());
		if (teclado.isTeclaDerecha())
			nave.setX(nave.getX() + nave.getVelocidad());
		if (teclado.isTeclaDisparo() && Cooldown.getCooldownDisparo() == 0) {
			addProyectil();
		}
	}

	/**
	 * Añade un disparo nuevo a la lista de proyectiles
	 */
	private void addProyectil() {
		Proyectil proyectil = new Proyectil();
		proyectil.setX(nave.getX() + 64);
		proyectil.setY(nave.getY() + 16);
		proyectil.setVelocidad(1);
		proyectil.setImagen("res/Bala.png");
		proyectiles.add(proyectil);
		Cooldown.setCooldownDisparo(Cooldown.DEFAULT_COOLDOWN_DISPARO);
	}

	/**
	 * Añade enemigos nuevo
	 */
	private void addEnemigos() {
		if (Cooldown.getCooldownEnemigos() == 0) {
			if (enemigosEnReserva.size() >= 0) {
				enemigos.add(enemigosEnReserva.get(0));
				enemigosEnReserva.remove(0);
			}
			Cooldown.setCooldownEnemigos(Cooldown.DEFAULT_COOLDOWN_ENEMIGOS);
		}
	}
}
