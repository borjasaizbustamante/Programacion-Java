package algoritmos.algoritmos;

import java.util.Scanner;

/**
 * Classe principal del programa
 */
public class Menu {

	private int[] array = null;
	private int numberOfItems = 0;
	private static final int MAX_SIZE = 10; // Truco  
	private GestorAlgoritmos gestorAlgoritmos = null;

	private Scanner teclado = null;

	public Menu() {
		array = new int[MAX_SIZE];
		gestorAlgoritmos = new GestorAlgoritmos();
		teclado = new Scanner(System.in);
	}

	/**
	 * Inicia el programa
	 */
	public void iniciar() {
		int opcion = 0;
		do {
			opcion = opcionMenuInicial();
			if (opcion != 0) {
				ejecutarOpcionMenuInicial(opcion);
			}
		} while (opcion != 0);
	}

	/**
	 * Retorna la opcion de menu seleccionada para el menu inicial
	 * 
	 * @return la opcion seleccionada
	 */
	private int opcionMenuInicial() {
		int ret = 0;
		do {
			try {
				escribirMenuInicial();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > 3));
		return ret;
	}

	/**
	 * Muestra el menu inicial
	 */
	private void escribirMenuInicial() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - Salir ");
		System.out.println("---- 1 - Introducir valor ");
		System.out.println("---- 2 - Buscar valor ");
		System.out.println("---- 3 - Borrar valor ");
		System.out.println("--------------");
		mostrarArray();
	}

	/**
	 * Ejecuta la opcion seleccionada en el menu inicial
	 * 
	 * @param opcion
	 */
	private void ejecutarOpcionMenuInicial(int opcion) {
		switch (opcion) {
		case 0:
			System.out.print("Adios!!!");
			break;
		case 1:
			nuevoValor();
			break;
		case 2:
			buscarValor();
			break;
		case 3:
			borrarValor();
			break;
		}
	}

	/**
	 * Permite aniadir un valor al array. Busca si el valor existe mediante Busqueda
	 * Binaria; si hay un hueco libre mediante Busqueda Secuencial; y si se
	 * modificado el array, lo reordena mediante Bubbleshort
	 */
	private void nuevoValor() {
		if (numberOfItems < MAX_SIZE) {
			int valor = getValue();
			int posicion = gestorAlgoritmos.busquedaBinaria(array, 0, array.length - 1, valor);
			if (posicion == -1) {
				int posicionLibre = gestorAlgoritmos.busquedaSecuencial(array, 0);
				array [posicionLibre] = valor;
				numberOfItems++;
				gestorAlgoritmos.bubbleShort(array);
				System.out.println("El numero se ha aniadido al array");
			} else {
				System.out.println("El numero ya existe en el array");
			}
		} else {
			System.out.println("El numero array esta lleno");
		}
	}

	/**
	 * Busca un numero mediante Busqueda Binaria
	 */
	private void buscarValor() {
		int posicion = gestorAlgoritmos.busquedaBinaria(array, 0, array.length - 1, getValue());
		if (posicion == -1) {
			System.out.println("El numero no existe");
		} else {
			System.out.println("El numero se encuentra en la posicion " + posicion);
		}
	}

	/**
	 * Busca un numero mediante Busqueda Binaria. Si existe en el array, lo borra y
	 * lo reordena mediante Bubbleshort. Si no, da un mensaje de error
	 */
	private void borrarValor() {
		int posicion = gestorAlgoritmos.busquedaBinaria(array, 0, array.length - 1, getValue());
		if (posicion == -1) {
			System.out.println("El numero no existe");
		} else {
			array[posicion] = 0;
			numberOfItems--;
			gestorAlgoritmos.bubbleShort(array);
			System.out.println("Numero eliminado");
		}
	}

	private void mostrarArray() {
		System.out.print("Array [" + MAX_SIZE + "] - [");
		for (int value : array) {
			System.out.print(value + ", ");
		}
		System.out.print("]");
		System.out.println (" ");
	}
	
	/**
	 * Retorna un valor entero por teclado. Si el valor no es un entero positivo
	 * superior a cero, vuelve a pedir el valor
	 * 
	 * @return el numero introducido
	 */
	private int getValue() {
		System.out.println("----");
		System.out.println("Introduce un numero entero positivo");
		int ret = -1;
		do {
			try {
				System.out.print("Valor: ");
				ret = teclado.nextInt();
			} catch (Exception e) {
				System.out.println("No es un numero entero positivo...");
				teclado.nextLine();
				ret = -1;
			}
		} while (ret <= 0);
		return ret;
	}
}
