package algoritmos;

import algoritmos.algoritmos.Menu;

/**
 * Inicia el programa 
 */
public class Algoritmos {

	/**
	 * Inicia el programa con los parametros indicados
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		(new Menu()).iniciar();
	}
}
