package excepciones;

import java.util.ArrayList;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import excepciones.miException.PatataException;
import excepciones.utils.Utils;

/**
 * Vamos a poner un log4j para no ensuciar la consola...
 * 
 * 1) A�ade las librer�as log4j-1.2-api-2.17.2.jar y log4j-core-2.17.2.jar
 * 
 * 2) Crea la variable log
 * 
 * 3) Crea una carpeta properties en src. Crea ahi un fichero log4j.properties
 * 
 * 4) Configura el log en el fichero log4j.properties
 * 
 * 5) Poner el log en las excepciones o donde queramos...
 * 
 */
public class Excepciones {

	// La variable log es la que gestiona el log
	private static final Logger log = LogManager.getLogger(Excepciones.class);  
	 
	private void iniciar() {
		int opcion = 0;
		do {
			opcion = Utils.opcionMenu();
			if (opcion != 0) {
				switch (opcion) {
				case 1:
					excepcionNoControlada();
					break;
				case 2:
					excepcionControladaTryCatch();
					break;
				case 3:
					excepcionControladaThrows();
					break;
				case 4:
					excepcionControladaPropia();
					break;
				default:
					System.out.println("ADIOS!!!");
					break;
				}
			}
		} while (opcion != 0);
	}

	@SuppressWarnings({ "null", "removal" })
	private void excepcionNoControlada() {
		// Una Excepcion no controlada es un error monumental
		// No deberia ocurrir, porque detiene el programa.
		// Por ejemplo, vamos a provocar una Excepci�n no controlada
		// intentando acceder a una variable null
		// Se genera una NullPointerException

		System.out.println("Generando excepcion no controlada...");
		System.out.println("La variable var es NULL... ");
		ArrayList<Integer> var = null;
		System.out.println("Tratamos de meter un valor a var... ");
		var.add(new Integer(10));
	}

	@SuppressWarnings({ "null", "removal" })
	private void excepcionControladaTryCatch() {
		// Para evitar la Excepci�n, decidimos CAPTURARLA
		// Lo que hacemos es usar un bloque try-catch
		// Si se produce una Excepcion, se ejecuta el catch
		// El programa ya no falla

		System.out.println("Generando excepcion controlada (try - catch)...");
		System.out.println("La variable var es NULL... ");
		ArrayList<Integer> var = null;
		try {
			System.out.println("Tratamos de meter un valor a var... ");
			var.add(new Integer(10));

			// Date cuenta de que esta linea NUNCA se va a mostrar
			// Si se produce una Excepcion
			System.out.println("Esto no deberia de mostrarse...");

		} catch (NullPointerException e) {
			// Se ejecuta esto si se genera una NullPointerException
			log.error("Se ha producido una NullPointerException");
		} catch (Exception e) {
			// Se ejecuta esto si se genera cualqueir otra Exception
			log.error("Se ha producido una Exception");
		} finally {
			// Esto se va a mostrar tanto si hay Excepcion como si no...
			System.out.println("Volvemos al menu... ");
			System.out.println(" ");
		}
	}

	private void excepcionControladaThrows() {
		// No estamos obligados a tratar la Excepcion en el metodo
		// que la produce. Podemos pasarle la responsabilidad a
		// los metodos que llaman a ese metodo. Para eso se usa el
		// Throws. 
		// F�jate que quien genera la excepcion NO ES este metodo, 
		// sino lanzaThrows ()
		
		System.out.println("Generando excepcion controlada (throws)...");
		try {
			
			// Este metodo genera excepciones...
			lanzaThrows();
			
			// Date cuenta de que esta linea NUNCA se va a mostrar
			// Si se produce una Excepcion
			System.out.println("Esto no deberia de mostrarse...");

		} catch (NullPointerException e) {
			// Se ejecuta esto si se genera una NullPointerException
			log.error("lanzaThrows () ha producido una NullPointerException");
		} catch (Exception e) {
			// Se ejecuta esto si se genera cualqueir otra Exception
			log.error("lanzaThrows () ha producido una Exception");
		} finally {
			// Esto se va a mostrar tanto si hay Excepcion como si no...
			System.out.println("Volvemos al menu... ");
			System.out.println(" ");
		}
	}

	// Este metodo no trata NullPointerException, le pasa la 
	// responsabilidad a quien le llame...
	@SuppressWarnings({ "null", "removal" })
	private void lanzaThrows() throws NullPointerException {
		ArrayList<Integer> var = null;
		var.add(new Integer(10));
	}

	private void excepcionControladaPropia() {
		// Tambien es posible generar y lanzar nuestra propia 
		// Excepcion inventada...

		System.out.println("Generando excepcion propia...");
		try {
			
			// Este metodo genera excepciones...
			lanzaPatatas();
			
			// Date cuenta de que esta linea NUNCA se va a mostrar
			// Si se produce una Excepcion
			System.out.println("Esto no deberia de mostrarse...");

		} catch (PatataException e) {
			// Se ejecuta esto si se genera una PatataException
			log.error("lanzaPatatas () ha producido una PatataException: " + e.getMessage());
		} catch (Exception e) {
			// Se ejecuta esto si se genera cualqueir otra Exception
			log.error("lanzaPatatas () ha producido una Exception");
		} finally {
			// Esto se va a mostrar tanto si hay Excepcion como si no...
			System.out.println("Volvemos al menu... ");
			System.out.println(" ");
		}
	}

	// Lanzamos la PatataException porque nos apetece...
	private void lanzaPatatas() throws PatataException {
		throw new PatataException(" Excepcion patatal generada por mi! ");
	}
	
	//-- ------------------------------- --//
	
	public static void main(String[] args) {
		(new Excepciones()).iniciar();
	}

}
