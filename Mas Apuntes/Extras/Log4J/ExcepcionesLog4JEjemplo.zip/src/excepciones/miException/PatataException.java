package excepciones.miException;

/**
 *	Si queremos que las excepciones tengan un mensaje adicional, 
 *	sobrecargamos los constructores y usamos getMessage(). 
 */
public class PatataException extends Exception{

	private static final long serialVersionUID = 7395555968571658791L;
	
	public PatataException () {
		super();
	}
	
	public PatataException (String message) {
		super (message);
	}

}
