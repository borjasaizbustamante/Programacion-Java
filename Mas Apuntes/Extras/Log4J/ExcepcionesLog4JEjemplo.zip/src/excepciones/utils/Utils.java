package excepciones.utils;

import java.util.Scanner;

public class Utils {

	private static Scanner teclado = new Scanner(System.in);
	
	public static final int MAIN_MENU_MIN = 0;
	public static final int MAIN_MENU_MAX = 4;
	
	public static int opcionMenu() {
		int ret = 0;
		do {
			try {
				writeMainMenu();
				System.out.print("Elija una opcion: ");
				ret = scannerReadInt();
			} catch (Exception e) {
				ret = scannerReset();
			}
		} while ((ret < MAIN_MENU_MIN) && (ret > MAIN_MENU_MAX));
		return ret;
	}
	
	private static void writeMainMenu() {
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - SALIR ");
		System.out.println("---- 1 - Generar Excepcion no controlada");
		System.out.println("---- 2 - Generar Excepcion controlada (try - catch)");
		System.out.println("---- 3 - Generar Excepcion controlada (throws)");
		System.out.println("---- 4 - Generar Excepcion controlada propia");
		System.out.println("--------------");
	}
	
	private static int scannerReadInt() {
		int ret = 0;
		do {
			try {
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				ret = scannerReset();
			}
		} while (ret < 0);
		return ret;
	}
	
	private static int scannerReset() {
		teclado.nextLine();
		return -1;
	}
}
