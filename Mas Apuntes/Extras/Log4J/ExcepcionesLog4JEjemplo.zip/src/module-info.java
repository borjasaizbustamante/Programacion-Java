module excepcionesLog4JEjemplo {
	requires apache.logging.log4j;
}