package ejemplo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.ArrayList;

import ejemplo.menu.Menu;
import ejemplo.pojos.Alumno;
import ejemplo.utils.DBUtils;

/**
 * Esta clase de ejemplo consulta todos los alumnos de la tabla t_alumno
 */
public class DBAccessExampleForSelect {

	/**
	 * Retorna todas las filas de la tabla t_alumno. Si la consulta no devuelve
	 * nada, retorna NULL
	 * 
	 * @return todos los alumnos o null
	 */
	private ArrayList<Alumno> getAllAlumnos() {
		ArrayList<Alumno> ret = null;

		// SQL que queremos lanzar
		String sql = "select * from t_alumno";

		// La conexion con BBDD
		Connection connection = null;

		// Vamos a lanzar una sentencia SQL contra la BBDD
		// Result set va a contener todo lo que devuelve la BBDD
		Statement statement = null;
		ResultSet resultSet = null;

		try {
			// El Driver que vamos a usar
			Class.forName(DBUtils.DRIVER);

			// Abrimos la conexion con BBDD
			connection = DriverManager.getConnection(DBUtils.URL, DBUtils.USER, DBUtils.PASS);

			// Vamos a lanzar la sentencia...
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);

			// Recorremos resultSet, que tiene las filas de la tabla
			while (resultSet.next()) {

				// Hay al menos una fila en el cursos, inicializamos el ArrayList
				if (null == ret)
					ret = new ArrayList<Alumno>();

				// El Alumno
				Alumno alumno = new Alumno();

				// Sacamos las columnas del resultSet
				int id = resultSet.getInt("id");
				String nombre = resultSet.getString("nombre");
				String apellidos = resultSet.getString("apellidos");
				int edad = resultSet.getInt("edad");

				// Metemos los datos en Alumno
				alumno.setId(id);
				alumno.setNombre(nombre);
				alumno.setApellidos(apellidos);
				alumno.setEdad(edad);

				// Lo guardamos en la lista
				ret.add(alumno);
			}
		} catch (SQLException sqle) {
			System.out.println("Error con la BBDD - " + sqle.getMessage());
		} catch (Exception e) {
			System.out.println("Error generico - " + e.getMessage());
		} finally {
			// Cerramos al reves de como las abrimos
			try {
				if (resultSet != null)
					resultSet.close();
			} catch (Exception e) {
				// No hace falta
			}
			try {
				if (statement != null)
					statement.close();
			} catch (Exception e) {
				// No hace falta
			}
			try {
				if (connection != null)
					connection.close();
			} catch (Exception e) {
				// No hace falta
			}
		}
		return ret;
	}

	public static void main(String[] args) {
		DBAccessExampleForSelect dBAccessExample = new DBAccessExampleForSelect();
		ArrayList<Alumno> alumnos = dBAccessExample.getAllAlumnos();

		// Mostramos el resultado
		Menu menu = new Menu();
		if (null == alumnos) {
			menu.noHayAlumnos();
		} else {
			for (int i = 0; i < alumnos.size(); i++) {
				menu.mostrarAlumno(alumnos.get(i));
			}
		}
	}
}
