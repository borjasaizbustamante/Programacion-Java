package ejemplo.menu;

import ejemplo.pojos.Alumno;

// Para los menus de la aplicacion
public class Menu {

	public void mostrarAlumno (Alumno ejemplo) {
		System.out.println ("-------------------------------------");
		System.out.println ("Id - " + ejemplo.getId());
		System.out.println ("Nombre - " + ejemplo.getNombre());
		System.out.println ("Apellidos - " + ejemplo.getApellidos());
		System.out.println ("Edad - " + ejemplo.getEdad());
		System.out.println ("-------------------------------------");
	}
	
	public void noHayAlumnos () {
		System.out.println ("-------------------------------------");
		System.out.println ("No hay alumnos ");
		System.out.println ("-------------------------------------");
	}
}
