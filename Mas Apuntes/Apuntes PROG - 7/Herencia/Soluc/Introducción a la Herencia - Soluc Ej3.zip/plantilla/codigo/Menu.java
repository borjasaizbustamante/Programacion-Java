package plantilla.codigo;

import java.util.List;
import java.util.Scanner;

import plantilla.codigo.logica.GestorGatos;
import plantilla.codigo.logica.GestorPerros;
import plantilla.codigo.logica.GestorTortugas;
import plantilla.codigo.pojo.Gato;
import plantilla.codigo.pojo.Perro;
import plantilla.codigo.pojo.Tortuga;

/**
 * Clase de menus.
 */
public class Menu {

	private GestorPerros gestorPerros = null;
	private GestorGatos gestorGatos = null;
	private GestorTortugas gestorTortugas = null;
	
	private Scanner teclado = null;

	public static final int NUMERO_OPCIONES_MENU = 2;

	public Menu() {
		gestorPerros = new GestorPerros();
		gestorGatos = new GestorGatos();
		gestorTortugas = new GestorTortugas();
		
		teclado = new Scanner(System.in);
	}

	public void iniciar() {
		int opcion = 0;
		do {
			opcion = opcionMenuInicial();
			if (opcion != 0) {
				ejecutarOpcionMenuInicial(opcion);
			}
		} while (opcion != 0);
	}

	private int opcionMenuInicial() {
		int ret = 0;
		do {
			try {
				escribirMenuInicial();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > NUMERO_OPCIONES_MENU));
		return ret;
	}

	private void escribirMenuInicial() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - SALIR ");
		System.out.println("---- 1 - Mostrar mascotas ");
		System.out.println("---- 2 - Mostrar mascotas por tipo ");
		System.out.println("--------------");
	}

	private void ejecutarOpcionMenuInicial(int opcion) {
		System.out.println(" ");
		switch (opcion) {
		case 0:
			System.out.print("Adios!!!");
			break;
		case 1:
			mostrarMascotas();
			break;
		case 2:
			mostrarMascotasPorTipo();
			System.out.println(" Opcion 2 ");
			break;
		default:
			System.out.println("Esta opcion no deberia salir...");
		}
	}
	
	// --------- OPCION 1 - Mostrar todas las mascotas --//
	
	private void mostrarMascotas() {
		System.out.println("---------");
		List <Perro> perros = gestorPerros.obtenerTodos();
		mostrarPerros(perros);
		System.out.println("---------");
		List <Gato> gatos = gestorGatos.obtenerTodos();
		mostrarGatos(gatos);
		System.out.println("---------");
		List <Tortuga> tortugas = gestorTortugas.obtenerTodos();
		mostrarTortugas(tortugas);
	}

	private void mostrarPerros(List <Perro> perros) {
		for (Perro perro : perros) {
			mostrarPerro(perro);
		}
	}

	private void mostrarPerro(Perro perro) {
		System.out.println("Id: " + perro.getId());
		System.out.println("Nombre: " + perro.getNombre());
		System.out.println("Raza: " + perro.getRaza());
		System.out.println("Vacunado?: " + perro.isVacunado());
	}

	private void mostrarGatos(List <Gato> gatos) {
		for (Gato gato : gatos) {
			mostrarGato(gato);
		}
	}

	private void mostrarGato(Gato gato) {
		System.out.println("Id: " + gato.getId());
		System.out.println("Nombre: " + gato.getNombre());
		System.out.println("Raza: " + gato.getRaza());
		System.out.println("Color: " + gato.getColor());
	}

	private void mostrarTortugas(List <Tortuga> tortugas) {
		for (Tortuga tortuga : tortugas) {
			mostrarTortuga(tortuga);
		}
	}

	private void mostrarTortuga(Tortuga tortuga) {
		System.out.println("Id: " + tortuga.getId());
		System.out.println("Especie: " + tortuga.getEspecie());
		System.out.println("Agua Dulce?: " + tortuga.isAguaDulce());
	}
	
	// --------- OPCION 2 - Mostrar mascotas por tipo --//
	
	private void mostrarMascotasPorTipo() {
		int opcion = 0;
		do {
			opcion = opcionMenuPorTipo();
			if (opcion != 0) {
				ejecutarOpcionMenuPorTipo(opcion);
			}
		} while (opcion != 0);
	}
	
	private int opcionMenuPorTipo() {
		int ret = 0;
		do {
			try {
				escribirMenuPorTipo();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > 3));
		return ret;
	}

	private void escribirMenuPorTipo() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - Volver ");
		System.out.println("---- 1 - Mostrar perros ");
		System.out.println("---- 2 - Mostrar gatos ");
		System.out.println("---- 3 - Mostrar tortugas ");
		System.out.println("--------------");
	}
	
	private void ejecutarOpcionMenuPorTipo(int opcion) {
		switch (opcion) {
		case 1:
			System.out.println("---------");
			List <Perro> perros = gestorPerros.obtenerTodos();
			mostrarPerros(perros);
			break;
		case 2:
			List <Gato> gatos = gestorGatos.obtenerTodos();
			mostrarGatos(gatos);
			break;
		case 3:
			System.out.println("---------");
			List <Tortuga> tortugas = gestorTortugas.obtenerTodos();
			mostrarTortugas(tortugas);
			break;
		}
	}

}
