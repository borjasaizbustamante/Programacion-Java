package plantilla.codigo.logica;

import java.util.List;

public interface GestorInterfaz <T>{

	public List<T> obtenerTodos();
	
}
