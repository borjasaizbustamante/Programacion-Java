package plantilla;

import plantilla.codigo.Menu;

/**
 * Clase principal.
 */
public class ClaseMain {
	public static void main(String[] args) {
		(new Menu()).iniciar();
	}
}
