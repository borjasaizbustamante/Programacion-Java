package plantilla.codigo.pojo;

import java.util.Objects;

/**
 * Un Gato de la tabla t_tortuga
 */
public class Tortuga extends Animal{

	private String especie = null;
	private boolean aguaDulce = false;
	
	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public boolean isAguaDulce() {
		return aguaDulce;
	}

	public void setAguaDulce(boolean aguaDulce) {
		this.aguaDulce = aguaDulce;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(aguaDulce, especie);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tortuga other = (Tortuga) obj;
		return aguaDulce == other.aguaDulce && Objects.equals(especie, other.especie);
	}

	@Override
	public String toString() {
		return "Tortuga [especie=" + especie + ", aguaDulce=" + aguaDulce + "]";
	}

}
