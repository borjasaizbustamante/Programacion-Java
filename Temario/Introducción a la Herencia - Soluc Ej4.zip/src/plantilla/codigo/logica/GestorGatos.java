package plantilla.codigo.logica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import plantilla.codigo.pojo.Gato;
import plantilla.codigo.utils.DBUtils;

/**
 * Clase de acceso a la tabla t_gatos
 */
public class GestorGatos implements GestorInterfaz <Gato>{

	/**
	 * Retorna todos los Gatos de t_gatos o null si no hay ninguno
	 * 
	 * @return los gatos o null
	 * @throws SQLException 
	 * @throws Exception
	 */
	public List<Gato> obtenerTodos() throws SQLException, Exception {
		List<Gato> ret = null;
		String sql = "select * from t_gatos";

		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;

		try {
			Class.forName(DBUtils.DRIVER);
			connection = DriverManager.getConnection(DBUtils.URL, DBUtils.USER, DBUtils.PASS);

			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);

			while (resultSet.next()) {

				if (null == ret)
					ret = new ArrayList<Gato>();

				Gato gato = new Gato();
				gato.setId(resultSet.getInt("id"));
				gato.setNombre(resultSet.getString("nombre"));
				gato.setRaza(resultSet.getString("raza"));
				gato.setColor(resultSet.getString("color"));

				ret.add(gato);
			}
		} catch (SQLException sqle) {
			throw sqle; 
		} catch (Exception e) {
			throw e; 
		} finally {
			try {
				if (resultSet != null)
					resultSet.close();
			} catch (Exception e) {
				// No hace falta
			}
			try {
				if (statement != null)
					statement.close();
			} catch (Exception e) {
				// No hace falta
			}
			try {
				if (connection != null)
					connection.close();
			} catch (Exception e) {
				// No hace falta
			}
		}
		return ret;
	}
}
