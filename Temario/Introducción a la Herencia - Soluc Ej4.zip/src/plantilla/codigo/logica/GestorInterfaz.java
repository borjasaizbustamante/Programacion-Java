package plantilla.codigo.logica;

import java.sql.SQLException;
import java.util.List;

public interface GestorInterfaz <T>{

	public List<T> obtenerTodos() throws SQLException, Exception;
	
}
