package plantilla.codigo.logica;

/**
 * Clase de acceso a la tabla GestorTablaUno
 */
public class GestorTablaUno {


}
