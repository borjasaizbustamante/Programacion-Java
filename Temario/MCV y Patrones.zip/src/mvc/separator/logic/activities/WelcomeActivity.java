package mvc.separator.logic.activities;

import mvc.separator.logic.session.SessionManager;
import mvc.separator.view.panels.CinemaPanel;

/**
 * The activities for the WelcomePanel
 */
public class WelcomeActivity extends Activity {

	/**
	 * Shows the Cinema Panel and then hides the others. It does nothing if there is
	 * nothing to show.
	 */
	public void showCinemaPanel() {
		SessionManager.getInstance().moveToPanelAndShow(CinemaPanel.class.getName());
	}
}
