package mvc.separator.logic.activities;

public abstract class Activity {

}
