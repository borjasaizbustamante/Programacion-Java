package mvc.separator.logic.activities;

import mvc.separator.view.panels.CinemaPanel;
import mvc.separator.view.panels.FilmPanel;
import mvc.separator.view.panels.WelcomePanel;

public class ActivityFactory {

	private static ActivityFactory instance = null;
	
	public static String WELLCOME_PANEL_DEFAULT_NAME = WelcomePanel.class.getName();
	private static String CINEMA_PANEL_DEFAULT_NAME = CinemaPanel.class.getName();
	private static String FILM_PANEL_DEFAULT_NAME = FilmPanel.class.getName();
	
	/**
	 * Returns the only instance of ActivityFactory. It it does not exist, it creates
	 * one and returns it.
	 * 
	 * @return ActivityFactory
	 */
	public static ActivityFactory getInstance() {
		return instance = null == instance ? new ActivityFactory() : instance;
	}
	
	/**
	 * Returns the activity specified by the activityName; or null if it does not exist
	 * 
	 * @param activityName
	 * @return Manager o null
	 */
	public Activity getActivity(String activityName) {
		if (activityName == null) {
			return null;
		}
		if (activityName.equalsIgnoreCase(WELLCOME_PANEL_DEFAULT_NAME)) {
			return new WelcomeActivity();
		} 
		if (activityName.equalsIgnoreCase(CINEMA_PANEL_DEFAULT_NAME)) {
			return new CinemaActivity();
		} 
		if (activityName.equalsIgnoreCase(FILM_PANEL_DEFAULT_NAME)) {
			return new FilmActivity();
		} 
		return null;
	}
}
