package mvc.separator.logic.activities;

/**
 * The activities for the CinemaPanel
 */
public class FilmActivity extends Activity {

	public void getFilmProfile() {
		
	}

}
