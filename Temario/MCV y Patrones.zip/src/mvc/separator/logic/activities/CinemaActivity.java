package mvc.separator.logic.activities;

import java.util.List;

import mvc.separator.database.entities.Cinema;
import mvc.separator.database.entities.Film;
import mvc.separator.database.managers.CinemaManager;
import mvc.separator.database.managers.FilmManager;
import mvc.separator.database.managers.ManagerFactory;
import mvc.separator.logic.session.SessionManager;
import mvc.separator.view.panels.FilmPanel;

/**
 * The activities for the CinemaPanel
 */
public class CinemaActivity extends Activity {

	/**
	 * Return all Cinemas on database; or null if there is no cinemas 
	 * 
	 * @return List of Cinemas or null
	 */
	public List<Cinema> getAllCinemas() {
		return ((CinemaManager) ManagerFactory.getInstance().getManager(CinemaManager.class.getName())).getAllCinemas();
	}

	/**
	 * Return all Films from a given Cinema name; or null if there is no films 
	 * 
	 * @param cinema
	 * @return List of Cinemas or null
	 */
	public List<Film> getFilmsByCinema(String cinema) {
		return ((FilmManager) ManagerFactory.getInstance().getManager(FilmManager.class.getName())).getFilmsByCinema(cinema);
	}

	/**
	 * Shows the Film Panel and then hides the others. It does nothing if there is
	 * nothing to show.
	 */
	public void showFilmPanel() {
		SessionManager.getInstance().moveToPanelAndShow(FilmPanel.class.getName());
	}
}
