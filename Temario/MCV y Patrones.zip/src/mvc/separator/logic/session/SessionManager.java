package mvc.separator.logic.session;

import java.util.ArrayList;
import java.util.List;

import mvc.separator.database.entities.User;
import mvc.separator.view.panels.MyPanel;

/**
 * Class defined to store info between frames. It stores the user's 'session'
 * info. It must be cleared manually when needed.
 */
public class SessionManager {

	private static SessionManager instance = null;

	// The User logged in the application
	private User user = null;

	// All the available panels for the frame
	private List<MyPanel> panelList = null;

	// The currently showing panel
	private MyPanel currentPanel = null;

	/**
	 * Returns the only instance of SessionManager. It it does not exist, it creates
	 * one and returns it.
	 * 
	 * @return SessionManager
	 */
	public static SessionManager getInstance() {
		return instance = null == instance ? new SessionManager() : instance;
	}

	/**
	 * Return true if there is a logged user in Session; false otherwise
	 * 
	 * @return true or false
	 */
	public boolean isUserLogged() {
		return null == user ? false : true;
	}

	/**
	 * Log the user in session
	 * 
	 * @param User
	 */
	public void logUser(User user) {
		this.user = user;
	}

	/**
	 * Returns the logged user, or null if there is noone
	 * 
	 * @return User or null
	 */
	public User getLoggedUser() {
		return user;
	}

	/**
	 * Adds a new panel to the panel list, if the list is not null. If null, it
	 * instantiates the list, adds the panel and set the current panel to this one
	 * 
	 * @param newPanel
	 */
	public void addPanel(MyPanel newPanel) {
		panelList = null == panelList ? new ArrayList<MyPanel>() : panelList;
		panelList.add(newPanel);
		currentPanel = newPanel;
	}

	/**
	 * Set the current panel to the one whose name is given, shows it and then hides
	 * the others. It does nothing if the list is null, empty or the name provided
	 * is not in the panel list. Returns the new current panel or null.
	 * 
	 * @param panelName
	 * @return The current panel or null
	 */
	public MyPanel moveToPanelAndShow(String panelName) {
		MyPanel ret = moveToPanel(panelName);
		showCurrentPanel();
		return ret;
	}
	
	/**
	 * Set the current panel to the one whose name is given. It does nothing if the
	 * list is null, empty or the name provided is not in the panel list. Returns
	 * the new current panel or null.
	 * 
	 * @param panelName
	 * @return The current panel or null
	 */
	public MyPanel moveToPanel(String panelName) {
		MyPanel ret = null;
		if (null != panelList)
			for (MyPanel myPanel : panelList) {
				if (myPanel.getPanelName().equals(panelName)) {
					ret = currentPanel = myPanel;
				}
			}
		return ret;
	}

	/**
	 * Shows the current panel and hides the others. If the panel list is null or
	 * empty, it does nothing.
	 * 
	 * @param panel
	 */
	public void showCurrentPanel() {
		showPanel(currentPanel);
	}

	/**
	 * Shows the given panel and hides the others. If the panel list is null or
	 * empty, it does nothing. This method updates the current panel.
	 * 
	 * @param panel
	 */
	public void showPanel(MyPanel panel) {
		if ((null != panelList) && (null != panel) && (panelList.indexOf(panel) != -1)) {
			panelList.forEach((e) -> {
				e.setVisible(false);
			});
			panel.setVisible(true);
			currentPanel = panel;
		}
	}

	public List<MyPanel> getPanelList() {
		return panelList;
	}

	public void setPanelList(List<MyPanel> panelList) {
		this.panelList = panelList;
	}

	public MyPanel getCurrentPanel() {
		return currentPanel;
	}

	public void setCurrentPanel(MyPanel currentPanel) {
		this.currentPanel = currentPanel;
	}
}
