package mvc.separator;

import java.awt.EventQueue;

import mvc.separator.view.MyFrame;

public class Reto3 {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new MyFrame();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
