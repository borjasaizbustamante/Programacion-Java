package mvc.separator.view;

import java.awt.Toolkit;

import javax.swing.JFrame;

import mvc.separator.logic.session.SessionManager;
import mvc.separator.view.panels.CinemaPanel;
import mvc.separator.view.panels.FilmPanel;
import mvc.separator.view.panels.WelcomePanel;
import mvc.separator.view.utils.Utils;

public class MyFrame {

	private JFrame frame = null;
	
	public MyFrame() {
		frame = new JFrame();
		frame.setTitle("Cinemas");
		frame.setIconImage(
				Toolkit.getDefaultToolkit().getImage(MyFrame.class.getResource(Utils.IMGS_PATH + "Fallout.jpg")));
		frame.setVisible(true);
		frame.setBounds(300, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		initialize();
	}

	/**
	 * Generates the JFrame components
	 */
	private void initialize() {

		SessionManager session = SessionManager.getInstance();

		// Generates the panels and add them to the frame
		WelcomePanel welcomePanel = new WelcomePanel();
		CinemaPanel cinemaPanel = new CinemaPanel();
		FilmPanel filmPanel = new FilmPanel();
		
		frame.add(welcomePanel);
		frame.add(cinemaPanel);
		frame.add(filmPanel);
		
		// Save the panels in session and show the first one
		session.addPanel(welcomePanel);
		session.addPanel(cinemaPanel);
		session.addPanel(filmPanel);
		session.moveToPanelAndShow(WelcomePanel.DEFAULT_NAME);
	}

}
