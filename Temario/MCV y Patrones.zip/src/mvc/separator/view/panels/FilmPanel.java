package mvc.separator.view.panels;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import mvc.separator.logic.activities.ActivityFactory;
import mvc.separator.logic.activities.FilmActivity;

/**
 * The Film Panel
 */
public class FilmPanel extends MyPanel {

	private static final long serialVersionUID = -2988124359857692387L;

	public static String DEFAULT_NAME = FilmPanel.class.getName();

	private FilmActivity activity = null;
	
	/**
	 * Creates a new instance of CinemaPanel. The panel name is set up to the
	 * default one
	 * 
	 * @param panelName
	 */
	public FilmPanel() {
		this(DEFAULT_NAME);
	}

	/**
	 * Creates a new instance of CinemaPanel. The panel name must be provided; or
	 * else it will set up to a default one
	 * 
	 * @param panelName
	 */
	public FilmPanel(String panelName) {
		super(panelName == null ? DEFAULT_NAME : panelName);
		
		activity = (FilmActivity) ActivityFactory.getInstance().getActivity(DEFAULT_NAME);
		
		this.setBounds(0, 0, 800, 600);
		this.setLayout(null);
		//this.setBackground(Color.RED);
		
		JPanel subPanel = new JPanel(new GridLayout(0, 1));
		subPanel.setBackground(Color.LIGHT_GRAY);
		
		JScrollPane scrollPaneCinema = new JScrollPane(subPanel);
		scrollPaneCinema.setBounds(0, 0, 780, 580);
		
		activity.getFilmProfile();
		
		this.add(scrollPaneCinema);
	}
}
