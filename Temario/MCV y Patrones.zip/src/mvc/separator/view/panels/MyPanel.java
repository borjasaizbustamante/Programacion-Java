package mvc.separator.view.panels;

import javax.swing.JPanel;

public abstract class MyPanel extends JPanel{

	private static final long serialVersionUID = -1678054120848392652L;

	private String panelName = null;
	
	protected MyPanel (String panelName) {
		super();
		this.panelName = panelName;
	}
	
	public String getPanelName() {
		return panelName;
	}
}
