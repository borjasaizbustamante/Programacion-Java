package mvc.separator.view.panels;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import mvc.separator.logic.activities.ActivityFactory;
import mvc.separator.logic.activities.WelcomeActivity;

/**
 * The Welcome Panel
 */
public class WelcomePanel extends MyPanel {

	private static final long serialVersionUID = -2988124359857692387L;

	public static String DEFAULT_NAME = WelcomePanel.class.getName();
	
	private WelcomeActivity activity = null;
	
	/**
	 * Creates a new instance of WellcomePanel. The panel name is set up to the default one
	 * 
	 * @param panelName
	 */
	public WelcomePanel() {
		this(DEFAULT_NAME);
	}
	
	/**
	 * Creates a new instance of WelcomePanel. The panel name must be provided; or
	 * else it will set up to a default one
	 * 
	 * @param panelName
	 */
	public WelcomePanel(String panelName) {
		super(panelName == null ? DEFAULT_NAME : panelName);

		activity = (WelcomeActivity) ActivityFactory.getInstance().getActivity(DEFAULT_NAME);
		
		this.setBounds(0, 0, 800, 600);
		this.setLayout(null);
		
		JButton jButton = new JButton("Acept");
		jButton.setBounds(0, 0, 800, 600);
		jButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				activity.showCinemaPanel();
			}
		});
		this.add(jButton);
	}
}
