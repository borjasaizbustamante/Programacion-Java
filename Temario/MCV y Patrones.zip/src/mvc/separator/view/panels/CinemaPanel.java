package mvc.separator.view.panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import mvc.separator.database.entities.Cinema;
import mvc.separator.database.entities.Film;
import mvc.separator.logic.activities.ActivityFactory;
import mvc.separator.logic.activities.CinemaActivity;

/**
 * The Cinema Panel - Due not needing to refresh the available Cinemas, they are
 * loading only once when the panel is instantiated.
 */
public class CinemaPanel extends MyPanel {

	private static final long serialVersionUID = -2988124359857692387L;

	public static String DEFAULT_NAME = CinemaPanel.class.getName();

	private CinemaActivity cinemaActivity = null;

	/**
	 * Creates a new instance of CinemaPanel. The panel name is set up to the
	 * default one
	 * 
	 * @param panelName
	 */
	public CinemaPanel() {
		this(DEFAULT_NAME);
	}

	/**
	 * Creates a new instance of CinemaPanel. The panel name must be provided; or
	 * else it will set up to a default one
	 * 
	 * @param panelName
	 */
	public CinemaPanel(String panelName) {
		super(panelName == null ? DEFAULT_NAME : panelName);

		this.setBounds(0, 0, 800, 600);
		this.setLayout(null);

		cinemaActivity = (CinemaActivity) ActivityFactory.getInstance().getActivity(DEFAULT_NAME);

		// Right Panel (cinemas)
		JPanel cinemaSubPanel = new JPanel(new GridLayout(0, 1));
		cinemaSubPanel.setBackground(Color.LIGHT_GRAY);

		JScrollPane scrollPaneCinema = new JScrollPane(cinemaSubPanel);
		scrollPaneCinema.setBounds(400, 0, 380, 560);
		this.add(scrollPaneCinema);

		// Left Panel (films per cinema)
		JPanel filmsSubPanel = new JPanel(new GridLayout(0, 1));
		filmsSubPanel.setBackground(Color.WHITE);

		JScrollPane scrollPaneFilms = new JScrollPane(filmsSubPanel);
		scrollPaneFilms.setBounds(10, 0, 380, 560);
		this.add(scrollPaneFilms);

		// Get all Cinemas
		List<Cinema> cinemas = cinemaActivity.getAllCinemas();
		for (Cinema cinema : cinemas) {
			JPanel cinemaPanel = new JPanel();
			cinemaPanel.setPreferredSize(new Dimension(360, 280));
			cinemaPanel.setBackground(Color.WHITE);
			cinemaPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
			cinemaPanel.add(new JLabel(cinema.getName()));
			cinemaPanel.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseReleased(MouseEvent e) {
					JPanel clickedPanel = (JPanel) e.getSource();
					JLabel label = (JLabel) clickedPanel.getComponent(0);

					List<Film> films = cinemaActivity.getFilmsByCinema(label.getText());

					filmsSubPanel.removeAll();
					for (Film film : films) {
						JPanel filmPanel = new JPanel();
						filmPanel.setPreferredSize(new Dimension(360, 280));
						filmPanel.setBackground(Color.WHITE);
						filmPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
						filmPanel.add(new JLabel(film.getName()));
						filmPanel.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseReleased(MouseEvent e) {
								cinemaActivity.showFilmPanel();
							}
						});
						filmsSubPanel.add(filmPanel);
					}
					filmsSubPanel.revalidate();
				}
			});
			cinemaSubPanel.add(cinemaPanel);
		}
		cinemaSubPanel.revalidate();
	}

}
