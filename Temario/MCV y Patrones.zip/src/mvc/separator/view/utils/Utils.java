package mvc.separator.view.utils;

/**
 * Utility class for views
 */
public class Utils {

	public static final String IMGS_PATH = "/mvc/separator/view/imgs/";
	
}
