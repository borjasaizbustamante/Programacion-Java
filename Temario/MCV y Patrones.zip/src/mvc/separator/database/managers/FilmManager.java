package mvc.separator.database.managers;

import java.util.ArrayList;
import java.util.List;

import mvc.separator.database.entities.Film;

public class FilmManager extends Manager {

	public List<Film> getFilmsByCinema(String name) {
		List<Film> ret = null;

		int x = 0;
		if (name.equals("Cine 0")) {
			x = 3;
		} else if (name.equals("Cine 1")) {
			x = 2;
		} else if (name.equals("Cine 2")) {
			x = 5;
		} else if (name.equals("Cine 3")) {
			x = 1;
		}

		ret = new ArrayList<Film>();

		for (int i = 0; i < x; i++) {
			Film film = new Film();
			film.setName("Film " + i);
			ret.add(film);
		}

		return ret;
	}

}
