package mvc.separator.database.managers;

import java.util.ArrayList;
import java.util.List;

import mvc.separator.database.entities.Cinema;

public class CinemaManager extends Manager{

	public List<Cinema> getAllCinemas() {
		List<Cinema> ret = null;
		
		ret = new ArrayList<Cinema>();
		
		for (int i = 0; i < 4; i++) {
			Cinema cinema = new Cinema();
			cinema.setName("Cine " + i);
			ret.add(cinema);
		}
		
		return ret;
	}

}
