package mvc.separator.database.managers;

public class SessionManager extends Manager{

}
