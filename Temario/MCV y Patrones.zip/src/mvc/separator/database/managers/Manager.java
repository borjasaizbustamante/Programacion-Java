package mvc.separator.database.managers;

public abstract class Manager {

}
