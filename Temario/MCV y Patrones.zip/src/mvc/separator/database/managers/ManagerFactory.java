package mvc.separator.database.managers;

public class ManagerFactory {

	private static ManagerFactory instance = null;
	
	public static String USER_MANAGER_DEFAULT_NAME = UserManager.class.getName();
	public static String CINEMA_MANAGER_DEFAULT_NAME = CinemaManager.class.getName();
	public static String FILM_MANAGER_DEFAULT_NAME = FilmManager.class.getName();
	
	/**
	 * Returns the only instance of ManagerFactory. It it does not exist, it creates
	 * one and returns it.
	 * 
	 * @return ActivityFactory
	 */
	public static ManagerFactory getInstance() {
		return instance = null == instance ? new ManagerFactory() : instance;
	}
	
	/**
	 * Returns the manager specified by the managerName; or null if it does not exist
	 * 
	 * @param managerName
	 * @return Manager o null
	 */
	public Manager getManager (String managerName) {
		if (managerName == null) {
			return null;
		}
		if (managerName.equalsIgnoreCase(USER_MANAGER_DEFAULT_NAME)) {
			return new UserManager();
		} 
		if (managerName.equalsIgnoreCase(CINEMA_MANAGER_DEFAULT_NAME)) {
			return new CinemaManager();
		} 
		if (managerName.equalsIgnoreCase(FILM_MANAGER_DEFAULT_NAME)) {
			return new FilmManager();
		} 
		return null;
	}
}
