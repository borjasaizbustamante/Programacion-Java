package mvc.separator.database.managers;

public class UserManager extends Manager{

}
