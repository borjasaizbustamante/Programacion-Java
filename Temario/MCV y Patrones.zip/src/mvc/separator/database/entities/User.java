package mvc.separator.database.entities;

/**
 * Defines a database User
 */
public class User {

}
