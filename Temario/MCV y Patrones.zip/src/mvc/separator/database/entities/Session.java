package mvc.separator.database.entities;

public class Session {

}
