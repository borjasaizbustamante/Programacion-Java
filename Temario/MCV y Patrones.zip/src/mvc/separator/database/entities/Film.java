package mvc.separator.database.entities;

import java.util.List;

/**
 * Defines a database Film
 */
public class Film {

	private String name = null;
	
	private List <Session> sesiones = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Session> getSesiones() {
		return sesiones;
	}

	public void setSesiones(List<Session> sesiones) {
		this.sesiones = sesiones;
	}
}
