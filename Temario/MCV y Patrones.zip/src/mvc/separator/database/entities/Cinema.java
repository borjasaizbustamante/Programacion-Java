package mvc.separator.database.entities;

/**
 * Defines a database Cinema
 */
public class Cinema {

	private String name = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
