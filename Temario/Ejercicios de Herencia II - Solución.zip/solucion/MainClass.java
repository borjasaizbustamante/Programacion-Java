package solucion;

import solucion.code.Menu;

public class MainClass {
	public static void main(String[] args) {
		(new Menu()).initialize();
	}
}
