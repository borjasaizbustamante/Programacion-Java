package solucion.code.file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import solucion.code.file.pojo.Teacher;

public class FileManagerTeacher extends FileManagerAbstract <Teacher>{

	@Override
	public List<Teacher> readAll() throws ClassNotFoundException, FileNotFoundException, IOException {
		return (List<Teacher>) readFile (FILE_PATH, FILE_NAME_TEACHER);
	}

	@Override
	public void writeAll(List<Teacher> teachers) throws IOException {
		writeToFile(teachers, FILE_PATH, FILE_NAME_TEACHER);
	}

	@Override
	public void appendAll(List<Teacher> teachers) throws IOException {
		appendFile(teachers, FILE_PATH, FILE_NAME_TEACHER);
	}
}
