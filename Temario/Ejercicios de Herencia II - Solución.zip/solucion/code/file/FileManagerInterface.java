package solucion.code.file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public interface FileManagerInterface<T> {

	/**
	 * Returns all T in the file, or null if there is no Ts in the file
	 * 
	 * @return a List of T or null
	 * @throws ClassNotFoundException If no definition for a class with the
	 *                                specified name could be found.
	 * @throws FileNotFoundException  If the file does not exist
	 * @throws IOException            If an I/O operation fails
	 */
	public List<T> readAll() throws ClassNotFoundException, FileNotFoundException, IOException;

	/**
	 * Write all Ts in the file. The file will be overwritten.
	 * 
	 * @param the List of Ts
	 * @throws IOException If an I/O operation fails
	 */
	public void writeAll(List<T> t) throws IOException;

	/**
	 * Write all Ts in the file. The file will be appended.
	 * 
	 * @param the List of Ts
	 * @throws IOException If an I/O operation fails
	 */
	public void appendAll(List<T> t) throws IOException;

}
