package solucion.code.file.pojo;

import java.util.Objects;

public class Teacher extends Person {

	private static final long serialVersionUID = -3773205077241166218L;

	private boolean tutor = false;

	public boolean isTutor() {
		return tutor;
	}

	public void setTutor(boolean tutor) {
		this.tutor = tutor;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(tutor);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Teacher other = (Teacher) obj;
		return tutor == other.tutor;
	}

	@Override
	public String toString() {
		return "Teacher [tutor=" + tutor + "] - " + super.toString();
	}

}