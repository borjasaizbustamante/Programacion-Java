package solucion.code.file;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public abstract class FileManagerAbstract<T> implements FileManagerInterface<T> {

	protected static final String FILE_NAME_STUDENT = "student.dat";
	protected static final String FILE_NAME_TEACHER = "teacher.dat";

	protected static final String FILE_PATH = "c://Trastero//";

	/**
	 * Reads the file and returns a list of objects of T type, or null if the file
	 * is empty
	 * 
	 * @param path
	 * @param fileName
	 * @return List of T or null
	 * @throws ClassNotFoundException If no definition for a class with the
	 *                                specified name could be found.
	 * @throws FileNotFoundException  If the file does not exist
	 * @throws IOException            If an I/O operation fails
	 */
	@SuppressWarnings("unchecked")
	protected List<T> readFile(String path, String fileName)
			throws FileNotFoundException, IOException, ClassNotFoundException {
		FileInputStream fileInputStream = null;
		ObjectInputStream objectInputStream = null;
		List<T> result = null;

		try {
			fileInputStream = new FileInputStream(path + fileName);
			objectInputStream = new ObjectInputStream(fileInputStream);

			try {
				for (;;) {
					result = (List<T>) objectInputStream.readObject();
				}
			} catch (EOFException e) {
				// End of stream
			}
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException - At file " + path + fileName);
			throw e;
		} catch (IOException e) {
			System.out.println("IOException - At file " + path + fileName);
			throw e;
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException");
			throw e;
		} finally {
			close(objectInputStream, fileInputStream);
		}
		return result;
	}

	/**
	 * Closes the streams
	 * 
	 * @param objectInputStream
	 * @param fileInputStream
	 */
	private void close(ObjectInputStream objectInputStream, FileInputStream fileInputStream) {
		try {
			if (null != objectInputStream)
				objectInputStream.close();
		} catch (IOException e1) {
		}
		try {
			if (null != fileInputStream)
				fileInputStream.close();
		} catch (IOException e) {
		}
	}

	/**
	 * Writes a list of objects of T type in the given file. The file will be
	 * overwritten
	 * 
	 * @param list
	 * @param path
	 * @param fileName
	 * @throws IOException If an I/O operation fails
	 */
	protected void writeToFile(List<T> list, String path, String fileName) throws IOException {
		FileOutputStream fileOutputStream = null;
		ObjectOutputStream objectOutputStream = null;

		try {
			fileOutputStream = new FileOutputStream(path + fileName, false);
			objectOutputStream = new ObjectOutputStream(fileOutputStream);

			objectOutputStream.writeObject(list);
			objectOutputStream.flush();

		} catch (IOException e) {
			System.out.println("IOException - At file " + path + fileName);
			throw e;
		} finally {
			close(objectOutputStream, fileOutputStream);
		}
	}

	/**
	 * Writes a list of objects of T type in the given file. The file will be
	 * appended
	 * 
	 * @param list
	 * @param path
	 * @param fileName
	 * @throws IOException If an I/O operation fails
	 */
	protected void appendFile(List<T> list, String path, String fileName) throws IOException {
		FileOutputStream fileOutputStream = null;
		ObjectOutputStream objectOutputStream = null;

		try {
			fileOutputStream = new FileOutputStream(path + fileName, true);
			objectOutputStream = new ObjectOutputStream(fileOutputStream);

			objectOutputStream.writeObject(list);
			objectOutputStream.flush();

		} catch (IOException e) {
			System.out.println("IOException - At file " + path + fileName);
			throw e;
		} finally {
			close(objectOutputStream, fileOutputStream);
		}
	}

	/**
	 * Closes the streams
	 * 
	 * @param objectOutputStream
	 * @param fileInputStream
	 */
	private void close(ObjectOutputStream objectOutputStream, FileOutputStream fileOutputStream) {
		try {
			if (null != objectOutputStream)
				objectOutputStream.close();
		} catch (IOException e1) {
		}
		try {
			if (null != fileOutputStream)
				fileOutputStream.close();
		} catch (IOException e) {
		}
	}
}
