package solucion.code.file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import solucion.code.file.pojo.Student;

public class FileManagerStudent extends FileManagerAbstract <Student>{

	@Override
	public List<Student> readAll() throws ClassNotFoundException, FileNotFoundException, IOException {
		return (List<Student>) readFile (FILE_PATH, FILE_NAME_STUDENT);
	}

	@Override
	public void writeAll(List<Student> students) throws IOException {
		writeToFile(students, FILE_PATH, FILE_NAME_STUDENT);
	}

	@Override
	public void appendAll(List<Student> students) throws IOException {
		appendFile(students, FILE_PATH, FILE_NAME_STUDENT);
	}
}
