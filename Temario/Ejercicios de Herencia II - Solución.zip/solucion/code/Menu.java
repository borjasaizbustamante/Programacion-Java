package solucion.code;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import solucion.code.file.FileManagerStudent;
import solucion.code.file.FileManagerTeacher;
import solucion.code.file.pojo.Student;
import solucion.code.file.pojo.Teacher;

public class Menu {

	private FileManagerTeacher fileManagerTeacher = null;
	private FileManagerStudent fileManagerStudent = null;

	private Scanner scanner = null;

	public static final int MENU_OPTIONS = 4;

	public Menu() {
		fileManagerTeacher = new FileManagerTeacher();
		fileManagerStudent = new FileManagerStudent();

		scanner = new Scanner(System.in);
	}

	public void initialize() {
		int option = 0;
		do {
			option = initialMenuOptions();
			if (option != 0) {
				manageInitialMenuOptions(option);
			}
		} while (option != 0);
	}

	private int initialMenuOptions() {
		int ret = 0;
		do {
			try {
				printMenu();
				System.out.print("Pick an option: ");
				ret = scanner.nextInt();
				scanner.nextLine();
			} catch (Exception e) {
				scanner.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > MENU_OPTIONS));
		return ret;
	}

	private void printMenu() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - Exit ");
		System.out.println("---- 1 - New Teachers ");
		System.out.println("---- 2 - Show Teachers ");
		System.out.println("---- 3 - New Students ");
		System.out.println("---- 4 - Show Students ");
		System.out.println("--------------");
	}

	private void manageInitialMenuOptions(int option) {
		System.out.println(" ");
		switch (option) {
		case 0:
			System.out.print("Bye!!!");
			break;
		case 1:
			System.out.println("Generating new teachers to the file...");
			addNewTeachers();
			break;
		case 2:
			showTeachers();
			break;
		case 3:
			System.out.println("Generating new students to the file...");
			addNewStudents();
			break;
		case 4:
			showStudents();
			break;
		default:
			System.out.println("Unmanaged option...");
		}
	}

	private void showTeachers() {
		try {
			showTeachers(fileManagerTeacher.readAll());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void showTeachers(List<Teacher> teachers) {
		System.out.println(" ");
		if (null != teachers)
			for (Teacher teacher : teachers)
				System.out.println(teacher.toString());
		else
			System.out.println("There are no teachers to show...");
	}

	private void addNewTeachers() {
		try {
			Teacher teacherOne = new Teacher();
			teacherOne.setId(generateRandomInt());
			teacherOne.setName(generateRandomText());
			teacherOne.setFirstName(generateRandomText());
			teacherOne.setLastName(generateRandomText());
			teacherOne.setTutor(generateRandomBoolean());

			Teacher teacherTwo = new Teacher();
			teacherTwo.setId(generateRandomInt());
			teacherTwo.setName(generateRandomText());
			teacherTwo.setFirstName(generateRandomText());
			teacherTwo.setLastName(generateRandomText());
			teacherTwo.setTutor(generateRandomBoolean());
			
			List <Teacher> teachers = new ArrayList <Teacher> ();
			teachers.add(teacherOne);
			teachers.add(teacherTwo);
			
			fileManagerTeacher.writeAll(teachers);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void showStudents() {
		try {
			showStudents(fileManagerStudent.readAll());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void showStudents(List<Student> students) {
		System.out.println(" ");
		if (null != students)
			for (Student student : students)
				System.out.println(student.toString());
		else
			System.out.println("There are no students to show...");
	}

	private void addNewStudents() {
		try {
			Student studentOne = new Student();
			studentOne.setId(generateRandomInt());
			studentOne.setName(generateRandomText());
			studentOne.setFirstName(generateRandomText());
			studentOne.setLastName(generateRandomText());

			Student studentTwo = new Student();
			studentTwo.setId(generateRandomInt());
			studentTwo.setName(generateRandomText());
			studentTwo.setFirstName(generateRandomText());
			studentTwo.setLastName(generateRandomText());
			
			List <Student> students = new ArrayList <Student> ();
			students.add(studentOne);
			students.add(studentTwo);
			
			fileManagerStudent.writeAll(students);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String generateRandomText() {
		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();

		return random.ints(leftLimit, rightLimit + 1).limit(targetStringLength)
				.collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
	}

	private boolean generateRandomBoolean() {
		return (new Random()).nextBoolean();
	}
	
	private int generateRandomInt () {
		return (new Random()).nextInt(1000);
	}
}
