package concesionario.bbdd.pojo;

import java.sql.Date;
import java.util.Objects;

public class Coche {

	private int id = 0;
	private String modelo = null;
	private String marca = null;
	private String color = null;
	private Date fechaMatriculacion = null;

	// lado 1 de la relacion 1-n
	private Duenio duenio = null;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Date getFechaMatriculacion() {
		return fechaMatriculacion;
	}

	public void setFechaMatriculacion(Date fechaMatriculacion) {
		this.fechaMatriculacion = fechaMatriculacion;
	}

	public Duenio getDuenio() {
		return duenio;
	}

	public void setDuenio(Duenio duenio) {
		this.duenio = duenio;
	}

	@Override
	public int hashCode() {
		return Objects.hash(color, duenio, fechaMatriculacion, id, marca, modelo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coche other = (Coche) obj;
		return Objects.equals(color, other.color) && Objects.equals(duenio, other.duenio)
				&& Objects.equals(fechaMatriculacion, other.fechaMatriculacion) && id == other.id
				&& Objects.equals(marca, other.marca) && Objects.equals(modelo, other.modelo);
	}

	@Override
	public String toString() {
		return "Coche [id=" + id + ", modelo=" + modelo + ", marca=" + marca + ", color=" + color
				+ ", fechaMatriculacion=" + fechaMatriculacion + ", duenio=" + duenio + "]";
	}

}
