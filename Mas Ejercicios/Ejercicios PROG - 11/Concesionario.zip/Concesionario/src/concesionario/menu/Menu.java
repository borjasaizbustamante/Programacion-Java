package concesionario.menu;

import java.util.ArrayList;
import java.util.Scanner;

import concesionario.bbdd.gestor.GestorDuenios;
import concesionario.bbdd.pojo.Duenio;

public class Menu {

	private Scanner teclado = null;

	public Menu() {
		teclado = new Scanner(System.in);

	}

	// Bucle principal del programa.
	public void iniciar() {
		int opcion = 0;
		do {
			opcion = opcionMenuInicial();
			if (opcion != 0) {
				ejecutarOpcionMenuInicial(opcion);
			}
		} while (opcion != 0);
	}

	// Opciones del menu
	private int opcionMenuInicial() {
		int ret = 0;
		do {
			try {
				escribirMenuInicial();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > 3));
		return ret;
	}

	// Escribe el menu inicial
	private void escribirMenuInicial() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - SALIR ");
		System.out.println("---- 1 - Listar todos los dueños ");
		System.out.println("---- 2 - Listar todos los cocher ");
		System.out.println("---- 3 - Listar coches de dueño ");
		System.out.println("--------------");
	}

	// Ejecuta la opcion de menu elegida
	private void ejecutarOpcionMenuInicial(int opcion) {
		switch (opcion) {
		case 0:
			System.out.print("Adios!!!");
			break;
		case 1: listarTodosLosDuenios();
			break;
		case 2:
			break;
		case 3:
			break;
		}
	}

	private void listarTodosLosDuenios() {
		GestorDuenios gestorDuenios = new GestorDuenios ();
		ArrayList <Duenio> duenios = gestorDuenios.getAll();
		if (null != duenios) {
			for (Duenio duenio : duenios) {
				System.out.println (duenio.toString());
			}
		} else {
			System.out.println ("No hay Dueños...");
		}
	}
	
}
