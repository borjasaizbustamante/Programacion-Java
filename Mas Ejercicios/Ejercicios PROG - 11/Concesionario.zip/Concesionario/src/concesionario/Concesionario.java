package concesionario;

import concesionario.menu.Menu;

public class Concesionario {

	public static void main(String[] args) {
		new Menu().iniciar();
	}

}
