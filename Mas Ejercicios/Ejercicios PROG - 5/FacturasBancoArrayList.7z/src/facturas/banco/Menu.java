package facturas.banco;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {

	private Scanner teclado = null;

	private ArrayList <Factura> facturas = null;
	
	private static final int MAX_OPCIONES_MENU = 5;

	public Menu() {
		teclado = new Scanner(System.in);
		facturas = new ArrayList <Factura> ();
	}

	private void pintarMenu() {
		System.out.println(" ");
		System.out.println("- Menu Inicial -");
		System.out.println("----------------");
		System.out.println("1. Aniadir Factura");
		System.out.println("2. Mostrar todas facturas");
		System.out.println("3. Buscar factura");
		System.out.println("4. Eliminar factura");
		System.out.println("0. Salir");
		System.out.println(" ");
	}

	private int escribirMenu() {
		int ret = 0;
		do {
			try {
				pintarMenu();
				System.out.print("Escoge una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				System.out.println("Error!!! Opcion incorrecta");
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > MAX_OPCIONES_MENU));
		return ret;
	}

	public void mostrarMenu() {

		int opcionMenu = 0;

		do {

			opcionMenu = escribirMenu();

			switch (opcionMenu) {
			case 0:
				System.out.println("Adios !!!");
				break;
			case 1:
				facturas.add(pedirFactura());
				break;
			case 2:
				mostrarFacturas();
				break;
			case 3:
				buscarFactura();
				break;
			case 4:
				eliminarFactura();
				break;

			default:
				System.out.println("Esta opcion no deberia salir");
			}

		} while (opcionMenu != 0);
		teclado.close();
	}

	private Factura pedirFactura() {
		Factura ret = null;

		System.out.print("Dame un numero de factura: ");
		int numFactura = teclado.nextInt();
		teclado.nextLine();

		System.out.print("Dame una fecha: ");
		String fecha = teclado.nextLine();

		System.out.print("Dame un nombre: ");
		String nombre = teclado.nextLine();

		System.out.print("Dame un importe: ");
		long importe = teclado.nextLong();

		ret = new Factura();
		ret.setNumFactura(numFactura);
		ret.setFecha(fecha);
		ret.setNombre(nombre);
		ret.setImporte(importe);
		return ret;
	}

	private void mostrarFacturas() {
		System.out.println("Mostramos el arrayList");
		for (Factura factura : facturas) {
			System.out.println(factura.toString());
		}
		System.out.println("Terminado");
	}

	private void buscarFactura() {
		int numeroFactura = pedirNumeroFactura();
		for (Factura factura : facturas) {
			if (factura.getNumFactura() == numeroFactura) {
				System.out.println("Factura encontrada = " + factura.toString());
				break;
			}
		}
	}

	private int pedirNumeroFactura() {
		int ret = 0;
		System.out.print("Dame un numero de factura: ");
		ret = teclado.nextInt();
		teclado.nextLine();
		return ret;
	}

	private void eliminarFactura() {
		int numeroFactura = pedirNumeroFactura();
		int i = 0;
		for (Factura factura : facturas) {
			if (factura.getNumFactura() == numeroFactura) {
				facturas.remove(i);
				break;
			}
			i++;
		}
	}
}
