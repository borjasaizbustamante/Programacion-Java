package prueba;

import prueba.poo.Menu;

public class POO {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.mostrarMenu();
	}
}
