package prueba.poo;

import java.util.Scanner;

/**
 * MODIFICA el programa para que incluya las opciones:
 * 
 * 1 - Buscar alumno por nombre
 * 2 - Eliminar alumno por nombre
 * 3 - Modificar alumno por nombre
 * 
 * Dedicado a Giselle, que quiere trabajar...
 */
public class Menu {

	private Scanner teclado = null;
	
	private static final int MAX_OPCIONES_MENU = 3;
	
	private Alumno [] alumnos = null;
	
	public Menu() {
		teclado = new Scanner(System.in);
		alumnos = new Alumno [10];
	}
	
	private void pintarMenu() {
		System.out.println(" ");
		System.out.println("- Menu Inicial -");
		System.out.println("----------------");
		System.out.println("1. Aniadir Alumno");
		System.out.println("2. Mostrar todo");
		System.out.println("0. Salir");
		System.out.println(" ");
	}

	private int escribirMenu() {
		int ret = 0;
		do {
			try {
				pintarMenu();
				System.out.print("Escoge una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				System.out.println("Error!!! Opcion incorrecta");
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > MAX_OPCIONES_MENU));
		return ret;
	}

	public void mostrarMenu() {

		int opcionMenu = 0;

		do {

			opcionMenu = escribirMenu();

			switch (opcionMenu) {
			case 0:
				System.out.println("Adios !!!");
				break;
			case 1:
				Alumno alumno = leerAlumno();
				aniadirAlumno(alumno);
				
				//System.out.println("--> " + alumno.toString());
				
				break;
			case 2:
				mostrarTodo ();
				break;
			default:
				System.out.println("Esta opcion no deberia salir");
			}

		} while (opcionMenu != 0);
		teclado.close();
	}

	private Alumno leerAlumno() {
		Alumno ret = null;
		
		System.out.print("Dame un nombre: ");
		String nombre = teclado.nextLine();
		
		System.out.print("Dame un apellido: ");
		String apellido = teclado.nextLine();
		
		System.out.print("Dame la edad: ");
		int edad = teclado.nextInt();
		
		ret = new Alumno();
		ret.setNombre(nombre);
		ret.setApellido(apellido);
		ret.setEdad(edad);
		
		return ret;
	}
	
	private void aniadirAlumno(Alumno alumno) {
		for (int i = 0; i < alumnos.length; i++ ) {
			if (null == alumnos [i]) {
				alumnos [i] = alumno;
				break;
			}
		}
	}

	private void mostrarTodo() {
		for (int i = 0; i < alumnos.length; i++ ) {
			if (null != alumnos [i]) {
				System.out.println("--> " + alumnos[i].toString());
			}
		}
	}
}
