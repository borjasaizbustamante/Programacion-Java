package tiendaAnimales.menu;

import java.util.Scanner;

import tiendaAnimales.animales.Gato;
import tiendaAnimales.animales.Perro;
import tiendaAnimales.animales.Tortuga;

/**
 * Por norma general, la mejor manera de hacer estos ejercicios es la siguiente:
 * 
 * 1) Las clases Gato, Perro, Tortuga con sus getters & setters 2) Clase Menu.
 * Constructor. Pon codigo para tener datos de prueba en los array 3) Codigo
 * para el menu principal, que no falle, etc. 4) Mostrar todos los arrays. 5)
 * Mostrar lo-que-sea. 6) Ahora que ya muestras los arrays, lo siguiente mas
 * facil es borrar 7) Ahora, insertar 8) Por ultimo, modificar... que es una
 * mezcla de insertar y borrar !!!
 * 
 * Nota: He escrito esto deprisa, puede que haya errores por ahi...
 */
public class Menu {

	private Perro[] perros = null;
	private Gato[] gatos = null;
	private Tortuga[] tortugas = null;

	private Scanner teclado = null;

	public Menu() {
		teclado = new Scanner(System.in);

		perros = new Perro[20];
		gatos = new Gato[20];
		tortugas = new Tortuga[20];

		// Precargamos los arrays
		Perro perro = new Perro();
		perro.setId(1);
		perro.setNombre("Puppy");
		perro.setRaza("Labrador");
		perro.setVacunado(true);
		perros[0] = perro;

		Gato gato = new Gato();
		gato.setId(2);
		gato.setNombre("Calcetines");
		gato.setRaza("Persa");
		gato.setColor("Verde");
		gatos[0] = gato;

		Tortuga tortuga = new Tortuga();
		tortuga.setId(3);
		tortuga.setEspecie("Galapago");
		tortuga.setAguaDulce(false);
		tortugas[0] = tortuga;
	}

	// Bucle principal del programa.
	public void iniciar() {
		int opcion = 0;
		do {
			opcion = opcionMenuInicial();
			if (opcion != 0) {
				ejecutarOpcionMenuInicial(opcion);
			}
		} while (opcion != 0);
	}

	// Opciones del menu
	private int opcionMenuInicial() {
		int ret = 0;
		do {
			try {
				escribirMenuInicial();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > 7));
		return ret;
	}

	// Escribe el menu inicial
	private void escribirMenuInicial() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - SALIR ");
		System.out.println("---- 1 - Aniadir mascota ");
		System.out.println("---- 2 - Mostrar mascotas ");
		System.out.println("---- 3 - Mostrar mascotas por tipo ");
		System.out.println("---- 4 - Mostrar mascotas por Id ");
		System.out.println("---- 5 - Mostrar mascotas por nombre ");
		System.out.println("---- 6 - Modificar mascota ");
		System.out.println("---- 7 - Borrar mascota ");
		System.out.println("--------------");
	}

	// Ejecuta la opcion de menu elegida
	private void ejecutarOpcionMenuInicial(int opcion) {
		switch (opcion) {
		case 0:
			System.out.print("Adios!!!");
			break;
		case 1:
			nuevaMascota();
			break;
		case 2:
			mostrarMascotas();
			break;
		case 3:
			mostrarMascotasPorTipo();
			break;
		case 4:
			mostrarMascotasPorId();
			break;
		case 5:
			mostrarMascotasPorNombre();
			break;
		case 6:
			modificarMascotaPorNombre();
			break;
		case 7:
			borrarMascotaPorNombre();
			break;
		}
	}

	// --------- OPCION 1 - Añadir mascota --//

	private void nuevaMascota() {
		int opcion = 0;
		opcion = opcionMenuNuevaMascota();
		ejecutarNuevaMascota(opcion);
	}

	private int opcionMenuNuevaMascota() {
		int ret = 0;
		do {
			try {
				escribirMenuNuevaMascota();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > 3));
		return ret;
	}

	// Escribe el menu por tipo
	private void escribirMenuNuevaMascota() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - Volver ");
		System.out.println("---- 1 - Nuevo perro ");
		System.out.println("---- 2 - Nuevo gato ");
		System.out.println("---- 3 - Nuevo tortuga ");
		System.out.println("--------------");
	}

	private void ejecutarNuevaMascota(int opcion) {
		switch (opcion) {
		case 1:
			System.out.println("---------");
			nuevoPerro();
			break;
		case 2:
			System.out.println("---------");
			nuevoGato();
			break;
		case 3:
			System.out.println("---------");
			nuevaTortuga();
			break;
		}
	}

	private void nuevoPerro() {
		try {

			System.out.println("Nuevo Perro: ");
			System.out.print("Id: ");
			int id = teclado.nextInt();
			if (idYaExiste(id)) {
				System.out.println("Ya existe una mascota con la id: " + id);
			} else {
				Perro perro = nuevoPerro(id);
				insertarNuevoPerro(perro);
			}
		} catch (Exception e) {
			System.out.println("Datos incorrectos... ");
		}
	}

	private Perro nuevoPerro(int id) {
		Perro ret = new Perro();
		ret.setId(id);
		System.out.print("Nombre: ");
		String nombre = teclado.nextLine();
		ret.setNombre(nombre);
		System.out.print("Raza: ");
		String raza = teclado.nextLine();
		ret.setRaza(raza);
		System.out.print("Vacunado? [S/N]: ");
		String vacunado = teclado.nextLine().trim().charAt(0) + "";
		ret.setVacunado(vacunado.equalsIgnoreCase("S") ? true : false);
		return ret;
	}

	private void insertarNuevoPerro(Perro perro) {
		for (int i = 0; i < perros.length; i++) {
			if (null == perros[i]) {
				perros[i] = perro;
				break;
			}
		}
	}

	private void nuevoGato() {
		try {
			System.out.println("Nuevo Gato: ");
			System.out.print("Id: ");
			int id = teclado.nextInt();
			if (idYaExiste(id)) {
				System.out.println("Ya existe una mascota con la id: " + id);
			} else {
				Gato gato = nuevoGato(id);
				insertarNuevoGato(gato);
			}
		} catch (Exception e) {
			System.out.println("Datos incorrectos... ");
		}
	}

	private Gato nuevoGato(int id) {
		Gato ret = new Gato();
		ret.setId(id);
		System.out.print("Nombre: ");
		String nombre = teclado.nextLine();
		ret.setNombre(nombre);
		System.out.print("Raza: ");
		String raza = teclado.nextLine();
		ret.setRaza(raza);
		System.out.print("Color: ");
		String color = teclado.nextLine();
		ret.setRaza(color);
		return ret;
	}

	private void insertarNuevoGato(Gato gato) {
		for (int i = 0; i < gatos.length; i++) {
			if (null == gatos[i]) {
				gatos[i] = gato;
				break;
			}
		}
	}

	private void nuevaTortuga() {
		try {
			System.out.println("Nueva Tortuga: ");
			System.out.print("Id: ");
			int id = teclado.nextInt();
			if (idYaExiste(id)) {
				System.out.println("Ya existe una mascota con la id: " + id);
			} else {
				Tortuga tortuga = nuevaTortuga(id);
				insertarNuevaTortuga(tortuga);
			}
		} catch (Exception e) {
			System.out.println("Datos incorrectos... ");
		}
	}

	private Tortuga nuevaTortuga(int id) {
		Tortuga ret = new Tortuga();
		ret.setId(id);
		System.out.print("Especie: ");
		String especie = teclado.nextLine();
		ret.setEspecie(especie);
		System.out.print("Agua dulce? [S/N]: ");
		String vacunado = teclado.nextLine().trim().charAt(0) + "";
		ret.setAguaDulce(vacunado.equalsIgnoreCase("S") ? true : false);
		return ret;
	}

	private void insertarNuevaTortuga(Tortuga tortuga) {
		for (int i = 0; i < tortugas.length; i++) {
			if (null == tortugas[i]) {
				tortugas[i] = tortuga;
				break;
			}
		}
	}

	private boolean idYaExiste(int id) {
		boolean ret = true;
		Perro perro = buscarPerroPorId(id);
		if (null == perro) {
			Gato gato = buscarGatoPorId(id);
			if (null == gato) {
				Tortuga tortuga = buscarTortugaPorId(id);
				if (null == tortuga) {
					ret = false;
				}
			}
		}
		return ret;
	}

	// --------- OPCION 2 - Mostrar mascotas --//

	private void mostrarMascotas() {
		System.out.println("---------");
		mostrarPerros();
		System.out.println("---------");
		mostrarGatos();
		System.out.println("---------");
		mostrarTortugas();
	}

	private void mostrarPerros() {
		for (int i = 0; i < perros.length; i++) {
			if (null != perros[i]) {
				System.out.println("---");
				System.out.println("Perro num " + i);
				mostrarPerro(perros[i]);
			}
		}
	}

	private void mostrarPerro(Perro perro) {
		System.out.println("Id: " + perro.getId());
		System.out.println("Nombre: " + perro.getNombre());
		System.out.println("Raza: " + perro.getRaza());
		System.out.println("Vacunado?: " + perro.isVacunado());
	}

	private void mostrarGatos() {
		for (int i = 0; i < gatos.length; i++) {
			if (null != gatos[i]) {
				System.out.println("---");
				System.out.println("Gato num " + i);
				mostrarGato(gatos[i]);
			}
		}
	}

	private void mostrarGato(Gato gato) {
		System.out.println("Id: " + gato.getId());
		System.out.println("Nombre: " + gato.getNombre());
		System.out.println("Raza: " + gato.getRaza());
		System.out.println("Color: " + gato.getColor());
	}

	private void mostrarTortugas() {
		for (int i = 0; i < tortugas.length; i++) {
			if (null != tortugas[i]) {
				System.out.println("---");
				System.out.println("Tortuga num " + i);
				mostrarTortuga(tortugas[i]);
			}
		}
	}

	private void mostrarTortuga(Tortuga tortuga) {
		System.out.println("Id: " + tortuga.getId());
		System.out.println("Especie: " + tortuga.getEspecie());
		System.out.println("Agua Dulce?: " + tortuga.isAguaDulce());
	}

	// --------- OPCION 3 - Mostrar mascotas por tipo --//

	private void mostrarMascotasPorTipo() {
		int opcion = 0;
		do {
			opcion = opcionMenuPorTipo();
			if (opcion != 0) {
				ejecutarOpcionMenuPorTipo(opcion);
			}
		} while (opcion != 0);
	}

	// Opciones del menu por tipo
	private int opcionMenuPorTipo() {
		int ret = 0;
		do {
			try {
				escribirMenuPorTipo();
				System.out.print("Elija una opcion: ");
				ret = teclado.nextInt();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) && (ret > 3));
		return ret;
	}

	// Escribe el menu por tipo
	private void escribirMenuPorTipo() {
		System.out.println(" ");
		System.out.println("---- MENU ----");
		System.out.println("---- 0 - Volver ");
		System.out.println("---- 1 - Mostrar perros ");
		System.out.println("---- 2 - Mostrar gatos ");
		System.out.println("---- 3 - Mostrar tortugas ");
		System.out.println("--------------");
	}

	// Ejecuta la opcion de menu elegida
	private void ejecutarOpcionMenuPorTipo(int opcion) {
		switch (opcion) {
		case 1:
			System.out.println("---------");
			mostrarPerros();
			break;
		case 2:
			System.out.println("---------");
			mostrarGatos();
			break;
		case 3:
			System.out.println("---------");
			mostrarTortugas();
			break;
		}
	}

	// --------- OPCION 4 - Mostrar mascotas por id --//

	private void mostrarMascotasPorId() {
		int opcion = 0;
		opcion = obtenerId();
		ejecutarBuscarPorId(opcion);
	}

	private int obtenerId() {
		int ret = -1;
		do {
			try {
				System.out.print("Introduce la Id: ");
				ret = teclado.nextInt();
			} catch (Exception e) {
				teclado.nextLine();
				ret = -1;
			}
		} while (ret < 0);
		return ret;
	}

	private void ejecutarBuscarPorId(int id) {
		Perro perro = buscarPerroPorId(id);
		if (null == perro) {
			Gato gato = buscarGatoPorId(id);
			if (null == gato) {
				Tortuga tortuga = buscarTortugaPorId(id);
				if (null == tortuga) {
					System.out.println("No hay mascotas con id " + id);
				} else {
					mostrarTortuga(tortuga);
				}
			} else {
				mostrarGato(gato);
			}
		} else {
			mostrarPerro(perro);
		}
	}

	private Perro buscarPerroPorId(int id) {
		Perro ret = null;
		for (int i = 0; i < perros.length; i++) {
			if ((null != perros[i]) && (perros[i].getId() == id)) {
				ret = perros[i];
			}
		}
		return ret;
	}

	private Gato buscarGatoPorId(int id) {
		Gato ret = null;
		for (int i = 0; i < gatos.length; i++) {
			if ((null != gatos[i]) && (gatos[i].getId() == id)) {
				ret = gatos[i];
			}
		}
		return ret;
	}

	private Tortuga buscarTortugaPorId(int id) {
		Tortuga ret = null;
		for (int i = 0; i < tortugas.length; i++) {
			if ((null != tortugas[i]) && (tortugas[i].getId() == id)) {
				ret = tortugas[i];
			}
		}
		return ret;
	}

	// --------- OPCION 5 - Mostrar mascotas por nombre --//

	private void mostrarMascotasPorNombre() {
		String nombre = null;
		nombre = obtenerNombre();
		ejecutarBuscarPorNombre(nombre);
	}

	private String obtenerNombre() {
		String ret = null;
		System.out.print("Introduce el nombre: ");
		ret = teclado.nextLine().trim();
		return ret;
	}

	private void ejecutarBuscarPorNombre(String nombre) {
		Perro perro = buscarPerroPorNombre(nombre);
		if (null == perro) {
			Gato gato = buscarGatoPorNombre(nombre);
			if (null == gato) {
				System.out.println("No hay mascotas con id " + nombre);
			} else {
				mostrarGato(gato);
			}
		} else {
			mostrarPerro(perro);
		}
	}

	private Perro buscarPerroPorNombre(String nombre) {
		Perro ret = null;
		for (int i = 0; i < perros.length; i++) {
			if ((null != perros[i]) && (null != perros[i].getNombre())
					&& (perros[i].getNombre().equalsIgnoreCase(nombre))) {
				ret = perros[i];
			}
		}
		return ret;
	}

	private Gato buscarGatoPorNombre(String nombre) {
		Gato ret = null;
		for (int i = 0; i < gatos.length; i++) {
			if ((null != gatos[i]) && (null != gatos[i].getNombre())
					&& (gatos[i].getNombre().equalsIgnoreCase(nombre))) {
				ret = gatos[i];
			}
		}
		return ret;
	}

	// --------- OPCION 6 - Modificar mascota --//

	private void modificarMascotaPorNombre() {
		String nombre = null;
		nombre = obtenerNombre();
		String tipo = ejecutarBuscarMascotaAModificar(nombre);
		if (null == tipo) {
			System.out.println("No hay mascotas con el nombre " + nombre);
		} else {
			if (tipo.equalsIgnoreCase("perro")) {
				modificarPerro(nombre);
			} else if (tipo.equalsIgnoreCase("gato")) {
				modificarGato(nombre);
			}
		}
	}

	private String ejecutarBuscarMascotaAModificar(String nombre) {
		String ret = null;
		Perro perro = buscarPerroPorNombre(nombre);
		if (null == perro) {
			Gato gato = buscarGatoPorNombre(nombre);
			if (null == gato) {
				ret = null;
			} else {
				ret = "gato";
			}
		} else {
			ret = "perro";
		}
		return ret;
	}

	private void modificarPerro(String nombre) {
		System.out.println("Perro a modificar: ");
		System.out.print("Id: ");
		int id = -1;
		do {
			try {
				id = teclado.nextInt();
				if (idYaExiste(id)) {
					System.out.println("Ya existe una mascota con esa id: " + id);
				} else {
					ejecutarBorrarPorNombre(nombre);
					Perro perro = nuevoPerro(id);
					insertarNuevoPerro(perro);
				}
			} catch (Exception e) {
				System.out.println("Id erronea");
				id = -1;
			}
		} while (id == -1);
	}

	private void modificarGato(String nombre) {
		System.out.println("Gato a modificar: ");
		System.out.print("Id: ");
		int id = -1;
		do {
			try {
				id = Integer.parseInt(teclado.nextLine());
				if (idYaExiste(id)) {
					System.out.println("Ya existe una mascota con esa id: " + id);
				} else {
					ejecutarBorrarPorNombre(nombre);
					Gato gato = nuevoGato(id);
					insertarNuevoGato(gato);
				}
			} catch (Exception e) {
				System.out.println("Id erronea");
				id = -1;
			}
		} while (id == -1);
	}

	// --------- OPCION 7 - Borrar mascotas --//

	private void borrarMascotaPorNombre() {
		String nombre = null;
		nombre = obtenerNombre();
		ejecutarBorrarPorNombre(nombre);
	}

	private void ejecutarBorrarPorNombre(String nombre) {
		Perro perro = buscarPerroPorNombre(nombre);
		if (null == perro) {
			Gato gato = buscarGatoPorNombre(nombre);
			if (null == gato) {
				System.out.println("No hay mascotas con id " + nombre);
			} else {
				borrarGato(gato);
			}
		} else {
			borrarPerro(perro);
		}
	}

	private void borrarGato(Gato gato) {
		for (int i = 0; i < gatos.length; i++) {
			if ((null != gatos[i]) && (gatos[i].getId() == gato.getId())) {
				gatos[i] = null;
			}
		}
	}

	private void borrarPerro(Perro perro) {
		for (int i = 0; i < perros.length; i++) {
			if ((null != perros[i]) && (perros[i].getId() == perro.getId())) {
				perros[i] = null;
			}
		}
	}
}
