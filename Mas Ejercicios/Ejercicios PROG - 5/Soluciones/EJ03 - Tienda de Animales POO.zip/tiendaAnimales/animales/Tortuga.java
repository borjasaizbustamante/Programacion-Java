package tiendaAnimales.animales;

import java.util.Objects;

public class Tortuga {

	private int id = 0;
	private String especie = null;
	private boolean aguaDulce = false;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public boolean isAguaDulce() {
		return aguaDulce;
	}

	public void setAguaDulce(boolean aguaDulce) {
		this.aguaDulce = aguaDulce;
	}

	@Override
	public int hashCode() {
		return Objects.hash(aguaDulce, especie, id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tortuga other = (Tortuga) obj;
		return aguaDulce == other.aguaDulce && Objects.equals(especie, other.especie) && id == other.id;
	}

	@Override
	public String toString() {
		return "Tortuga [id=" + id + ", especie=" + especie + ", aguaDulce=" + aguaDulce + "]";
	}
}
