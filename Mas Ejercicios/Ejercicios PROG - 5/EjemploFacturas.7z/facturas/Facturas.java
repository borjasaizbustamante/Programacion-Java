package facturas;

import facturas.banco.Menu;

public class Facturas {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.mostrarMenu();
	}

}
