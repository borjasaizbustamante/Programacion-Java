package facturas.banco;

import java.util.Objects;

/**
 * Describe una Factura
 */
public class Factura {

	private int numFactura = 0;
	private String fecha = null;
	private String nombre = null;
	private long importe = 0;

	public int getNumFactura() {
		return numFactura;
	}

	public void setNumFactura(int numFactura) {
		this.numFactura = numFactura;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public long getImporte() {
		return importe;
	}

	public void setImporte(long importe) {
		this.importe = importe;
	}

	@Override
	public int hashCode() {
		return Objects.hash(fecha, importe, nombre, numFactura);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Factura other = (Factura) obj;
		return Objects.equals(fecha, other.fecha) && importe == other.importe && Objects.equals(nombre, other.nombre)
				&& numFactura == other.numFactura;
	}

	@Override
	public String toString() {
		return "Factura [numFactura=" + numFactura + ", fecha=" + fecha + ", nombre=" + nombre + ", importe=" + importe
				+ "]";
	}
}
