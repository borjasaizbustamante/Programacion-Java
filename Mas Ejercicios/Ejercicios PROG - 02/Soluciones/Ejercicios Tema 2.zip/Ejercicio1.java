package condicionales;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Declaro la variable que gestiona la entrada de datos
		Scanner teclado = new Scanner(System.in);
		// Solicito el dato
		System.out.println("Introduce el sueldo");
		// Almaceno la información en una variable
		double sueldo = teclado.nextDouble();
		//Estructura condicional
		if (sueldo > 3000) {
			System.out.println("Debe abonar impuestos");
		}

	}

}
