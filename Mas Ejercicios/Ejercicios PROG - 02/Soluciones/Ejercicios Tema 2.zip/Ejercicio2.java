package condicionales;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		// Declarar variable entrada de datos
		Scanner entradaDatos = new Scanner(System.in);
		// Recoger dato
		System.out.println("introducir edad");
		int edad = entradaDatos.nextInt();
		//Estructura condicional
		
		if( edad < 0) {
			System.out.println("Error, la edad introducida no es correcta");
		}else if(edad > 17 ) {
			System.out.println("Mayor de edad");
		}else {
			System.out.println("Menor de edad");
		}
	}

}
