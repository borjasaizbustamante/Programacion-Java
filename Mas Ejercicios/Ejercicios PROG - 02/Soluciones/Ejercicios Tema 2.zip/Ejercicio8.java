package condicionales;

import java.util.Scanner;

public class Ejercicio8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opcion = 0;
		Scanner sc = new Scanner(System.in);
		do {

			System.out.println("***************");
			System.out.println("Calculadora");
			System.out.println("***************");

			System.out.println("Introduce el primer operando: ");
			double operandoUno = sc.nextDouble();
			System.out.println("Introduce el segundo operando");
			double operandoDos = sc.nextDouble();
			System.out.println("Introduce la opción deseada: ");
			System.out.println("1.- Sumar");
			System.out.println("2.- Restar");
			System.out.println("3.- Multiplicar");
			System.out.println("4.- Dividir");
			System.out.println("5.- Salir");
			opcion = sc.nextInt();
			switch (opcion) {
			case 1:
				System.out.println(
						"La suma entre " + operandoUno + " y " + operandoDos + " es: " + (operandoUno + operandoDos));
				break;
			case 2:
				System.out.println(
						"La resta entre " + operandoUno + " y " + operandoDos + " es: " + (operandoUno - operandoDos));
				break;
			case 3:
				System.out.println("La multiplicacion entre " + operandoUno + " y " + operandoDos + " es: "
						+ (operandoUno * operandoDos));
				break;
			case 4:
				if (operandoDos == 0) {
					System.out.println("No se puede dividir por 0");
				} else {
					System.out.println("La division entre " + operandoUno + " y " + operandoDos + " es: "
							+ (operandoUno / operandoDos));
				}
				break;
			case 5:
				System.out.println("Gracais por utilizar mi calculadora");
				break;
			}

		} while (opcion != 5);
	}
}
