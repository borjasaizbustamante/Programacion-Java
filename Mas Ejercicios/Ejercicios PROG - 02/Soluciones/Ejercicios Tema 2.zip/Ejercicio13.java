package condicionales;

import java.util.Scanner;

public class Ejercicio13 {

	public static void main(String[] args) {
		int numeroCuenta = 0;
		double saldoActual, sumaSaldos = 0;
		Scanner teclado = new Scanner(System.in);
		do {
			System.out.println("Bienvenido al banco");
			System.out.println("Por favor, introduzca su número de cuenta");
			numeroCuenta = teclado.nextInt();
			if (numeroCuenta > 0) {
				System.out.println("Introduce el saldo");
				saldoActual = teclado.nextDouble();
				if (saldoActual > 0) {
					System.out.println("Acreedor");
					sumaSaldos = sumaSaldos + saldoActual;
				} else if (saldoActual < 0) {
					System.out.println("Deudor");
				} else {
					System.out.println("Nulo");
				}
			} else {
				System.out.println("La suma de los saldos de los acreedores es: " + sumaSaldos);
				System.out.println("Hasta la proxima");
			}
		} while (numeroCuenta > 0);

		teclado.close();
	}

}
