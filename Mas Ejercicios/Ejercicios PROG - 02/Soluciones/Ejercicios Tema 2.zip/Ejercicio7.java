package condicionales;

import java.util.Scanner;

public class Ejercicio7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el numero de preguntas");
		int numPreguntas = sc.nextInt();
		System.out.println("Introduce el numero de respuestas correctas");
		int numRespuestas = sc.nextInt();
		System.out.println(numPreguntas + ", " + numRespuestas);
		double porcentaje = ((double)numRespuestas / (double)numPreguntas) * 100;
		System.out.println(porcentaje);
		if (porcentaje >= 90) {
			System.out.println("nivel maximo");
		} else if (porcentaje >= 75 && porcentaje < 90) {
			System.out.println("nivel medio");
		} else if (porcentaje >= 50 && porcentaje < 75) {
			System.out.println("nivel regular");
		} else {
			System.out.println("fuera de nivel");
		}

	}

}
