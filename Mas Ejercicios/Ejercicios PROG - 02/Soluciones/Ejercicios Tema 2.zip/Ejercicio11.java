package condicionales;

import java.util.Scanner;

public class Ejercicio11 {

	public static void main(String[] args) {
		/*
		 * Desarrollar un programa que permita cargar n números enteros y luego nos
		 * informe cuántos valores fueron pares y cuántos impares. Solicitar antes el
		 * número de enteros a tratar.
		 */
		Scanner teclado = new Scanner(System.in);
		System.out.println("¿Cuántos números vas a introducir?");
		int numerosAIntroducir = teclado.nextInt();
		int contador = 0;
		int pares = 0;
		int impares = 0;
		while (contador < numerosAIntroducir) {
			
			System.out.println("Introduce el " + (contador + 1) + "º numero");
			int numeroIntroducido = teclado.nextInt();
			if (numeroIntroducido % 2 == 0) {
				pares = pares + 1;
			}else {
				 impares = impares + 1;
			}
			contador++;
			
			}
			System.out.println("había " + pares + " numeros pares");
			System.out.println("había "+ (numerosAIntroducir - pares)+ " numeros impares");
	}

}
