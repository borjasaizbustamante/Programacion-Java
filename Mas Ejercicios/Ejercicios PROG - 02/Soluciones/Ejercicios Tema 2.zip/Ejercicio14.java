package condicionales;

import java.util.Scanner;

public class Ejercicio14 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int numeroAlumnos = 23;
		int contadorNotables = 0;
		for (int i = 0; i < numeroAlumnos; i++) {
			System.out.println("Introduce la nota del alumno " + (i + 1));
			double nota = teclado.nextDouble();
			if (nota >= 4) {
				contadorNotables++;
			}
		}

		System.out.println("Hay " + contadorNotables + " notas superiores o iguales a 7");
		System.out.println("Hay " + (numeroAlumnos - contadorNotables) + " notas inferiores a 7");

	}

}
