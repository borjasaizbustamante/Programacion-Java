package ejercicio5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import ejercicio5.pojo.Alumno5;

/**
 * Clase que gestiona los alumno
 */
public class GestorDeAlumnos5 {

	private static Scanner teclado = null;
	private List<Alumno5> alumnos = null;

	public GestorDeAlumnos5() {
		teclado = new Scanner(System.in);
		alumnos = new ArrayList<Alumno5>();
	}

	public void menu() {

		int opcionMenu = 0;
		String nombreAlumno = null;

		do {

			opcionMenu = escribirMenu();

			switch (opcionMenu) {
			case 0:
				System.out.println("Adios !!!");
				break;
			case 1:
				alumnos.add(pedirAlumno());
				break;
			case 2:
				visualizarTodosAlumons();
				break;
			case 3:
				nombreAlumno = pedirNombreAlumno();
				visualizarUnAlumno(nombreAlumno);
				break;
			case 4:
				nombreAlumno = pedirNombreAlumno();
				modificarUnAlumno(nombreAlumno);
				break;
			case 5:
				nombreAlumno = pedirNombreAlumno();
				borrarUnAlumno(nombreAlumno);
				break;
			case 6:
				nombreAlumno = pedirNombreAlumno();
				insertarNotaEnAlumno(nombreAlumno);
				break;
			case 7:
				nombreAlumno = pedirNombreAlumno();
				modificarNotaEnAlumno(nombreAlumno);
				break;
			case 8:
				nombreAlumno = pedirNombreAlumno();
				borrarNotaEnAlumno(nombreAlumno);
				break;
			case 9:
				notaMediaClase();
				break;
			case 10:
				notaMaximaYMinimaClase();
				break;
			default:
				System.out.println("Esta opcion no deberia salir");
			}

		} while (opcionMenu != 0);
		teclado.close();
	}

	private void pintarMenu() {
		System.out.println(" ");
		System.out.println("- Menu Inicial -");
		System.out.println("----------------");
		System.out.println("1. Aniadir alumno");
		System.out.println("2. Mostrar todos alumnos");
		System.out.println("3. Mostrar alumno");
		System.out.println("4. Modificar alumno");
		System.out.println("5. Borrar alumno");
		System.out.println("6. Insertar nota en alumno");
		System.out.println("7. Modificar nota en alumno");
		System.out.println("8. Borrar nota en alumno");
		System.out.println("9. Nota media de la clase");
		System.out.println("10. Nota maxima y minima");
		System.out.println("0. Salir");
		System.out.println(" ");
	}

	private int escribirMenu() {
		int ret = 0;
		do {
			try {
				pintarMenu();
				System.out.print("Escoge una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				System.out.println("Error!!! Opcion incorrecta");
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > 10));
		return ret;
	}

	private Alumno5 pedirAlumno() {
		Alumno5 ret = new Alumno5();

		System.out.print("Dame un nombre: ");
		ret.setNombre(teclado.nextLine());

		System.out.print("Dame un apellido: ");
		ret.setApellido(teclado.nextLine());

		System.out.print("Dame un apellido2: ");
		ret.setApellido2(teclado.nextLine());

		System.out.print("Dame una fecha nacimiento: ");
		ret.setFechaNacimiento(teclado.nextLine());

		System.out.print("Dame un curso: ");
		ret.setCurso(teclado.nextLine());

		System.out.print("Dame una clase: ");
		ret.setClase(teclado.nextLine());

		return ret;
	}

	private void visualizarTodosAlumons() {
		if ((null != alumnos) && (alumnos.size() == 0)) {
			System.out.println("No hay alumnos que mostrar");
		} else {
			for (Alumno5 alumno : alumnos) {
				System.out.println("Alumno = " + alumno.toString());
			}
		}
	}

	private String pedirNombreAlumno() {
		String ret = null;
		System.out.print("Dame un nombre: ");
		ret = teclado.nextLine();
		return ret;
	}

	private int pedirNotaAlumno() {
		int ret = 0;
		do {
			try {
				System.out.print("Dame una nota: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				System.out.println("Error!!! Nota incorrecta");
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > 10));
		return ret;
	}

	private Alumno5 buscarAlumno(String nombre) {
		Alumno5 ret = null;
		for (Alumno5 alumno : alumnos) {
			if (alumno.getNombre().equals(nombre)) {
				ret = alumno;
				break;
			}
		}
		return ret;
	}
	
	private void visualizarUnAlumno(String nombre) {
		Alumno5 alumno = buscarAlumno(nombre);
		if (null != alumno) {
			System.out.println("Alumno encontrado!");
			System.out.println("Datos del alumno: " + alumno.toString());
		} else {
			System.out.println("Alumno no encontrado!");
		}
	}

	private void modificarUnAlumno(String nombre) {
		Alumno5 alumno = buscarAlumno(nombre);
		if (null != alumno) {
			System.out.println("Alumno encontrado!");
			alumnos.remove(alumno);
			alumno = pedirAlumno();
			alumnos.add(alumno);
			System.out.println("Alumno modificado!");
		} else {
			System.out.println("Alumno no encontrado!");
		}
	}

	private void borrarUnAlumno(String nombre) {
		Alumno5 alumno = buscarAlumno(nombre);
		if (null != alumno) {
			System.out.println("Alumno encontrado!");
			alumnos.remove(alumno);
			System.out.println("Alumno eliminado!");
		} else {
			System.out.println("Alumno no encontrado!");
		}
	}

	private void insertarNotaEnAlumno(String nombre) {
		Alumno5 alumno = buscarAlumno(nombre);
		if (null != alumno) {
			System.out.println("Alumno encontrado!");
			alumno.setNota(pedirNotaAlumno());
			System.out.print("Nota del alumno insertada!");
		} else {
			System.out.println("Alumno no encontrado!");
		}
	}

	private void modificarNotaEnAlumno(String nombre) {
		Alumno5 alumno = buscarAlumno(nombre);
		if (null != alumno) {
			System.out.println("Alumno encontrado!");
			if (alumno.getNota() == 0) {
				System.out.println("Debes insertar una nota primero!");
			} else {
				alumno.setNota(pedirNotaAlumno());
				System.out.print("Nota del alumno modificada!");
			}
		} else {
			System.out.println("Alumno no encontrado!");
		}
	}

	private void borrarNotaEnAlumno(String nombre) {
		Alumno5 alumno = buscarAlumno(nombre);
		if (null != alumno) {
			System.out.println("Alumno encontrado!");
			alumno.setNota(0);
			System.out.print("Nota del alumno borrada!");
		} else {
			System.out.println("Alumno no encontrado!");
		}
	}

	private void notaMediaClase() {
		int sumatorio = 0;
		int numAlumnos = 0;

		for (Alumno5 alumno : alumnos) {
			sumatorio += alumno.getNota();
			numAlumnos++;
		}

		if (numAlumnos > 0) {
			System.out.println("Nota media = " + sumatorio / numAlumnos);
		} else {
			System.out.println("No hay alumnos en la clase");
		}
	}

	private void notaMaximaYMinimaClase() {
		int notaMasBaja = 0;
		int notaMasAlta = 0;

		for (Alumno5 alumno : alumnos) {
			int notaAlumno = alumno.getNota();
			if (notaMasBaja > notaAlumno) {
				notaMasBaja = notaAlumno;
			}
			if (notaMasAlta < notaAlumno) {
				notaMasAlta = notaAlumno;
			}
		}

		System.out.println("Nota mas baja = " + notaMasBaja);
		System.out.println("Nota mas alta = " + notaMasAlta);
	}
}