package ejercicio5;

/**
 * Clase resposnable de ejecutar el proyecto
 */
public class Ejercicio5 {

	public static void main(String[] args) {
		GestorDeAlumnos5 gestorDeAlumnos5 = new GestorDeAlumnos5();
		gestorDeAlumnos5.menu();
	}
}
