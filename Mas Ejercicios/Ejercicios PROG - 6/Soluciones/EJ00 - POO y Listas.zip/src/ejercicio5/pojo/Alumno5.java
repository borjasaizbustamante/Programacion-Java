package ejercicio5.pojo;

import java.util.Objects;

/**
 * Esta clase define un alumno con todos sus datos
 */
public class Alumno5 {

	private String nombre = null;
	private String apellido = null;
	private String apellido2 = null;
	private String fechaNacimiento = null;
	private String curso = null;
	private String clase = null;

	private int nota = 0;

	/**
	 * Constructor base
	 */
	public Alumno5() {

	}

	public Alumno5(String nombre, String apellido, String apellido2, String fechaNacimiento, String curso, String clase,
			int nota) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.apellido2 = apellido2;
		this.fechaNacimiento = fechaNacimiento;
		this.curso = curso;
		this.clase = clase;
		this.nota = nota;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	@Override
	public int hashCode() {
		return Objects.hash(apellido, apellido2, clase, curso, fechaNacimiento, nombre, nota);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Alumno5 other = (Alumno5) obj;
		return Objects.equals(apellido, other.apellido) && Objects.equals(apellido2, other.apellido2)
				&& Objects.equals(clase, other.clase) && Objects.equals(curso, other.curso)
				&& Objects.equals(fechaNacimiento, other.fechaNacimiento) && Objects.equals(nombre, other.nombre)
				&& Objects.equals(nota, other.nota);
	}

	@Override
	public String toString() {
		return "[nombre=" + nombre + ", apellido=" + apellido + ", apellido2=" + apellido2
				+ ", fechaNacimiento=" + fechaNacimiento + ", curso=" + curso + ", clase=" + clase + ", nota=" + nota
				+ "]";
	}

}
