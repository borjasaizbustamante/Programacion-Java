package tiendaAnimales.animales;

import java.util.Objects;

public class Perro {

	private int id = 0;
	private String nombre = null;
	private String raza = null;
	private boolean vacunado = false;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, nombre, raza, vacunado);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Perro other = (Perro) obj;
		return id == other.id && Objects.equals(nombre, other.nombre) && Objects.equals(raza, other.raza)
				&& vacunado == other.vacunado;
	}

	@Override
	public String toString() {
		return "Perro [id=" + id + ", nombre=" + nombre + ", raza=" + raza + ", vacunado=" + vacunado + "]";
	}
}
