package tiendaAnimales;

import tiendaAnimales.menu.Menu;

public class TiendaMascotas {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.iniciar();
	}
}
