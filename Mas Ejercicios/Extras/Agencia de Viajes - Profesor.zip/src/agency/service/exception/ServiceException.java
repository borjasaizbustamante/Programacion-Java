package agency.service.exception;

/**
 * Una clase abstracta en Java es una clase que no se puede instanciar
 * directamente y que sirve como base para otras clases. Esta pensada
 * principalmente para que otras clases puedan heredar de ella. <br>
 * </br>
 * ServiceException existe para que todas las excepciones del Controlador
 * hereden de ella y tenerlas asi ordenadas
 */
public abstract class ServiceException extends Exception {

	private static final long serialVersionUID = -3493897658885242563L;

	public ServiceException(String message) {
		super(message);
	}
}
