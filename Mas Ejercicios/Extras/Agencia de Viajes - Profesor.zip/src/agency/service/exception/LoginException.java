package agency.service.exception;

/**
 * Excepcion que se genera cuando el user y pass no coinciden en un Login
 */
public class LoginException extends ServiceException {

	private static final long serialVersionUID = -3493897658885242563L;

	public LoginException(String message) {
		super(message);
	}
	
}
