package agency.service.utils;

/**
 * Clase que gestiona los mensages de texto genericos del controlador
 */
public class ServiceTexts {

	public static final String LOGIN_ERROR_TEXT = "The Agency %s with pass %s does not exist in our data base";
	
}
