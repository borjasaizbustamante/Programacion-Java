package agency.service.controller;

import java.util.List;

import agency.database.DatabaseFactory;
import agency.database.entity.Event;
import agency.database.entity.Travel;
import agency.database.manager.EventManager;
import agency.database.manager.TravelManager;

/**
 * Controller para la gestion del Main Panel
 */
public class MainPanelController extends ControllerAbstract {

	public List<Travel> refreshTravelTable() {
		return getAllTravels();
	}

	private List<Travel> getAllTravels() {
		TravelManager travelManager = (TravelManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.TRAVEL_MANAGER.value);
		return travelManager.getAll ();
	}

	public List<Event> refreshEventTable(Travel travel) {
		return getAllEvents(travel);
	}

	private List<Event> getAllEvents(Travel travel) {
		EventManager eventManager = (EventManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.EVENT_MANAGER.value);
		return eventManager.getAllEvents (travel);
	}

	public Travel getSelectedTravel(Long id) {
		TravelManager travelManager = (TravelManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.TRAVEL_MANAGER.value);
		return travelManager.getTravelById (id);
	}
}
