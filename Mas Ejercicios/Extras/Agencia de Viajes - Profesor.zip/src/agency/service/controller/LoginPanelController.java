package agency.service.controller;

import agency.database.DatabaseFactory;
import agency.database.entity.Agency;
import agency.database.manager.AgencyManager;
import agency.service.exception.LoginException;
import agency.service.utils.ServiceTexts;

/**
 * Controller para la gestion del Login Panel
 */
public class LoginPanelController extends ControllerAbstract {


	/**
	 * Throws LoginException if the pair user & pass does not exist in database
	 * 
	 * @param agency
	 * @param pass
	 * @throws LoginException
	 */
	public void validate(String agency, String pass) throws LoginException {
		if (null == getAgency(agency, pass))
			throw new LoginException(String.format(ServiceTexts.LOGIN_ERROR_TEXT, agency, pass));
	}

	/**
	 * Returns the Agency given an agency name and pass from DDBB; or null it it
	 * does not exist
	 * 
	 * @param agency
	 * @param pass
	 * @return The Agency or null
	 */
	private Agency getAgency(String agency, String pass) {
		AgencyManager agencyManager = (AgencyManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.AGENCY_MANAGER.value);
		return agencyManager.getAgency(agency, pass);
	}

}
