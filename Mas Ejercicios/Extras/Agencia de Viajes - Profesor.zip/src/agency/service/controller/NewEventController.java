package agency.service.controller;

/**
 * Controller para la gestion del New Event Panel
 */
public class NewEventController extends ControllerAbstract{

}
