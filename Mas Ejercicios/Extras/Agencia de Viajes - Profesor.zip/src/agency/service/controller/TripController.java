package agency.service.controller;

/**
 * Controller para la gestion del Trip Panel
 */
public class TripController extends ControllerAbstract{

}
