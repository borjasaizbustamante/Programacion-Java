package agency.service.controller;

/**
 * Controller para la gestion del New Flight Panel
 */
public class NewFlightController extends ControllerAbstract{

}
