package agency.service.controller;

import agency.database.DatabaseFactory;
import agency.database.entity.Travel;
import agency.database.manager.TravelManager;

/**
 * Controller para la gestion del New Travel Panel
 */
public class NewTravelController extends ControllerAbstract{

	public void addNewTravel(Travel travel) {
		TravelManager travelManager = (TravelManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.TRAVEL_MANAGER.value);
		travelManager.insert(travel);
	}

}
