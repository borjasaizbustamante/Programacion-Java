package agency.service.controller;

import java.util.List;

import agency.database.DatabaseFactory;
import agency.database.entity.enums.TravelType;
import agency.database.manager.TravelTypeManager;

/**
 * Controller para la gestion del TravelType
 */
public class TravelTypeController extends ControllerAbstract{

	public List<TravelType> getAll(){
		TravelTypeManager travelManager = (TravelTypeManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.TRAVEL_TYPE_MANAGER.value);
		return travelManager.getAll ();
	}
}
