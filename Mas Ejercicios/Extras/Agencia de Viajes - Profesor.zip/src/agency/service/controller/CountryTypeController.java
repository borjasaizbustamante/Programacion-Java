package agency.service.controller;

import java.util.List;

import agency.database.DatabaseFactory;
import agency.database.entity.enums.Country;
import agency.database.manager.CountryTypeManager;

/**
 * Controller para la gestion de los TypeController
 */
public class CountryTypeController extends ControllerAbstract{

	public List<Country> getAll(){
		CountryTypeManager travelManager = (CountryTypeManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.COUNTRY_TYPE_MANAGER.value);
		return travelManager.getAll ();
	}
}
