package agency.service.controller;

/**
 * Una clase abstracta en Java es una clase que no se puede instanciar
 * directamente y que sirve como base para otras clases. Esta pensada
 * principalmente para que otras clases puedan heredar de ella. <br>
 * </br>
 * ControllerAbstract existe para que todos los Controller hereden de ella. En este
 * caso, se utiliza unicamente para que ControllerFactory sea capaz de almacenar
 * en un Map cualquier tipo de Controller.
 */
public class ControllerAbstract {

}
