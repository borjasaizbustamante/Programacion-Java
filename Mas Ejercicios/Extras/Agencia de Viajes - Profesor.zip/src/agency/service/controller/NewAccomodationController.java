package agency.service.controller;

/**
 * Controller para la gestion del New Accomodation Panel
 */
public class NewAccomodationController extends ControllerAbstract{

}
