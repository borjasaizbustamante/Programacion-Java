package agency.service.controller;

/**
 * Controller para la gestion del New Activity Panel
 */
public class NewActivityController extends ControllerAbstract{

}
