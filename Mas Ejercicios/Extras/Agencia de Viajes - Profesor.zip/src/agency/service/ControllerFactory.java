package agency.service;

import java.util.HashMap;
import java.util.Map;

import agency.service.controller.ControllerAbstract;
import agency.service.controller.CountryTypeController;
import agency.service.controller.LoginPanelController;
import agency.service.controller.MainPanelController;
import agency.service.controller.NewAccomodationController;
import agency.service.controller.NewActivityController;
import agency.service.controller.NewEventController;
import agency.service.controller.NewFlightController;
import agency.service.controller.NewTravelController;
import agency.service.controller.TravelTypeController;
import agency.service.controller.TripController;

/**
 * Hay distintos tipos de Patrones Factoria. Este es uno de ellos. Se les llaam
 * Factorias porque funcionan como fabricas de objetos. Si quieres un objeto, se
 * lo pides a ellos. <br>
 * </br>
 * ControllerFactory en concreto tiene un Singleton y adicionalmente, devuelve (no
 * crea) un objeto del tipo que le piden, en este caso, un Controller
 */
public class ControllerFactory {

	private static ControllerFactory instance = null;

	private Map<String, ControllerAbstract> controllers = null;

	// Inner class for the key values in the panels HashMap
	public static enum controllerOptions {
		LOGIN_PANEL_CONTROLLER("loginController"), MAIN_PANEL_CONTROLLER("mainPanelController"),
		NEW_ACCOMODATION_PANEL_CONTROLLER("accommodationPanelController"),
		NEW_ACTIVITY_PANEL_CONTROLLER("activityPanelController"), NEW_EVENT_PANEL_CONTROLLER("eventPanelController"),
		NEW_FLIGHT_PANEL_CONTROLLER("flightPanelController"), NEW_TRAVEL_PANEL_CONTROLLER("travelPanelController"),
		NEW_TRIP_PANEL_CONTROLLER("tripPanelController"), TRAVEL_TYPE_CONTROLLER("travelTypeCotroller"),
		COUNTRY_TYPE_CONTROLLER("countryTypeCotroller");

		public final String value;

		private controllerOptions(String value) {
			this.value = value;
		}
	}

	public ControllerFactory() {
		controllers = new HashMap<String, ControllerAbstract>();
		controllers.put(controllerOptions.LOGIN_PANEL_CONTROLLER.value, new LoginPanelController());
		controllers.put(controllerOptions.MAIN_PANEL_CONTROLLER.value, new MainPanelController());
		controllers.put(controllerOptions.NEW_ACCOMODATION_PANEL_CONTROLLER.value, new NewAccomodationController());
		controllers.put(controllerOptions.NEW_ACTIVITY_PANEL_CONTROLLER.value, new NewActivityController());
		controllers.put(controllerOptions.NEW_EVENT_PANEL_CONTROLLER.value, new NewEventController());
		controllers.put(controllerOptions.NEW_FLIGHT_PANEL_CONTROLLER.value, new NewFlightController());
		controllers.put(controllerOptions.NEW_TRAVEL_PANEL_CONTROLLER.value, new NewTravelController());
		controllers.put(controllerOptions.NEW_TRIP_PANEL_CONTROLLER.value, new TripController());
		controllers.put(controllerOptions.TRAVEL_TYPE_CONTROLLER.value, new TravelTypeController());
		controllers.put(controllerOptions.COUNTRY_TYPE_CONTROLLER.value, new CountryTypeController());
	}

	public static ControllerFactory getInstance() {
		return instance = instance == null ? new ControllerFactory() : instance;
	}

	public ControllerAbstract getController(String panelOption) {
		return controllers.get(panelOption);
	}

}
