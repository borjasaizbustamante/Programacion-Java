package agency.service.file;

/**
 * Clase encargada de gestionar el acceso a ficheros
 */
public class FileManager {

}
