package agency.view.panel.tableModel;

import javax.swing.table.DefaultTableModel;

/**
 * Table Model de la Tabla de Viajes
 */
public class TravelsTableModel extends DefaultTableModel {

	private static final long serialVersionUID = -2296367021602365817L;
	
	private DefaultTableModel model = null;
	
	public TravelsTableModel () {
		String[] columnNames = {"id", "Viajes", "Tipo", "Días", "Fecha Inicio", "Fecha Fin", "País"};
		model = new DefaultTableModel(columnNames, 0);
	}

	public DefaultTableModel getModel() {
		return model;
	}
	
}
