package agency.view.panel.tableModel;

import javax.swing.table.DefaultTableModel;

/**
 * Table Model de la Tabla de Eventos
 */
public class EventsTableModel extends DefaultTableModel {

	private static final long serialVersionUID = -7051830587831879069L;
	
	private DefaultTableModel model = null;
	
	public EventsTableModel () {
		String[] columnNames = {"id", "Nombre", "Tipo", "Fecha", "Precio"};
		model = new DefaultTableModel(columnNames, 0);
	}

	public DefaultTableModel getModel() {
		return model;
	}
	
}
