package agency.view.panel.combo;

import java.util.List;

import javax.swing.JComboBox;

import agency.database.entity.enums.TravelType;
import agency.service.ControllerFactory;
import agency.service.controller.TravelTypeController;

/**
 * Combo de TravelType
 */
public class TravelTypeCombo {

	private static TravelTypeCombo instance = null;
	
	private JComboBox<TravelType> comboTravelType = null;
	
	public TravelTypeCombo() {
		comboTravelType = new JComboBox<TravelType>();
		
		TravelTypeController travelTypeController = (TravelTypeController) ControllerFactory.getInstance()
				.getController(ControllerFactory.controllerOptions.TRAVEL_TYPE_CONTROLLER.value);
		
		List<TravelType> travelTypes = travelTypeController.getAll();
		comboTravelType.addItem(null);
		for (TravelType travelType : travelTypes) {
			comboTravelType.addItem(travelType);
		}
	}
	
	public static TravelTypeCombo getInstance() {
		return instance = instance == null ? new TravelTypeCombo() : instance;
	}

	public JComboBox<TravelType> getComboTravelType() {
		return comboTravelType;
	}

}
