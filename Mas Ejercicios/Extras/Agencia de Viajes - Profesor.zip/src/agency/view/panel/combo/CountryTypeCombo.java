package agency.view.panel.combo;

import java.util.List;

import javax.swing.JComboBox;

import agency.database.entity.enums.Country;
import agency.service.ControllerFactory;
import agency.service.controller.CountryTypeController;

/**
 * Combo de CountryType
 */
public class CountryTypeCombo {

	private static CountryTypeCombo instance = null;
	
	private JComboBox<Country> comboCountry = null;
	
	public CountryTypeCombo() {
		comboCountry = new JComboBox<Country>();
		
		CountryTypeController countryTypeController = (CountryTypeController) ControllerFactory.getInstance()
				.getController(ControllerFactory.controllerOptions.COUNTRY_TYPE_CONTROLLER.value);
		
		List<Country> countries = countryTypeController.getAll();
		comboCountry.addItem(null);
		for (Country countryType : countries) {
			comboCountry.addItem(countryType);
		}
	}
	
	public static CountryTypeCombo getInstance() {
		return instance = instance == null ? new CountryTypeCombo() : instance;
	}

	public JComboBox<Country> getComboCountry() {
		return comboCountry;
	}

}
