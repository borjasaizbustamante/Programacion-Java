package agency.view.panel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import agency.database.entity.Travel;
import agency.database.entity.enums.Country;
import agency.database.entity.enums.TravelType;
import agency.service.ControllerFactory;
import agency.service.controller.NewTravelController;
import agency.view.PanelFactory;
import agency.view.frame.Frame;
import agency.view.panel.combo.CountryTypeCombo;
import agency.view.panel.combo.TravelTypeCombo;
import agency.view.utils.Utils;
import net.sourceforge.jdatepicker.impl.JDatePanelImpl;
import net.sourceforge.jdatepicker.impl.JDatePickerImpl;

/**
 * Panel de Nuevo Viaje
 */
public class NewTravelPanel extends PanelAbstract {

	private static final long serialVersionUID = -7065023694672117515L;

	private JTextField nameText = null;
	private JComboBox<TravelType> comboTravelType = null;
	private JDatePickerImpl initDatePicker = null;
	private JDatePickerImpl endDatePicker = null;
	private JComboBox<Country> comboCountry = null;
	private JTextField descriptionText = null;
	private JTextField servicesText = null;

	private Travel travel = null;

	public NewTravelPanel() {
		initialize();
	}

	private void initialize() {
		setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);
		setLayout(null);

		travel = new Travel();

		JLabel nameLabel = new JLabel("Name:");
		nameText = new JTextField();
		add(nameLabel);
		nameLabel.setBounds(250, 50, 100, 20);
		add(nameText);
		nameText.setBounds(350, 50, 100, 20);

		JLabel travelTypeLabel = new JLabel("Travel type:");
		comboTravelType = TravelTypeCombo.getInstance().getComboTravelType();
		comboTravelType.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				TravelType travelType = (TravelType) comboTravelType.getSelectedItem();
				if (travelType != null) {
					travel.setTravelType(travelType);
				}
			}
		});
		add(travelTypeLabel);
		travelTypeLabel.setBounds(250, 100, 100, 20);
		add(comboTravelType);
		comboTravelType.setBounds(350, 100, 100, 20);

		JLabel initDateLabel = new JLabel("Init Date:");
		initDatePicker = new JDatePickerImpl(new JDatePanelImpl(null));
		initDatePicker.addActionListener(_ -> {
			GregorianCalendar calendar = (GregorianCalendar) initDatePicker.getModel().getValue();
			Date selectedDate = (Date) calendar.getTime();
			travel.setInitDate(Utils.utilDateToSQLDate(selectedDate));
		});
		add(initDateLabel);
		initDateLabel.setBounds(250, 150, 100, 30);
		add(initDatePicker);
		initDatePicker.setBounds(350, 150, 100, 30);

		JLabel endDateLabel = new JLabel("End Date:");
		endDatePicker = new JDatePickerImpl(new JDatePanelImpl(null));
		endDatePicker.addActionListener(_ -> {
			GregorianCalendar calendar = (GregorianCalendar) endDatePicker.getModel().getValue();
			Date selectedDate = (Date) calendar.getTime();
			travel.setEndDate(Utils.utilDateToSQLDate(selectedDate));
		});
		add(endDateLabel);
		endDateLabel.setBounds(250, 200, 100, 30);
		add(endDatePicker);
		endDatePicker.setBounds(350, 200, 100, 30);

		JLabel countryLabel = new JLabel("Country:");
		comboCountry = CountryTypeCombo.getInstance().getComboCountry();
		comboCountry.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Country country = (Country) comboCountry.getSelectedItem();
				if (country != null) {
					travel.setCountry(country);
				}
			}
		});
		add(countryLabel);
		countryLabel.setBounds(250, 250, 100, 20);
		add(comboCountry);
		comboCountry.setBounds(350, 250, 100, 20);

		JLabel descriptionLabel = new JLabel("Description:");
		descriptionText = new JTextField();
		add(descriptionLabel);
		descriptionLabel.setBounds(250, 300, 100, 20);
		add(descriptionText);
		descriptionText.setBounds(350, 300, 100, 20);

		JLabel servicesLabel = new JLabel("Services:");
		servicesText = new JTextField();
		add(servicesLabel);
		servicesLabel.setBounds(250, 350, 100, 20);
		add(servicesText);
		servicesText.setBounds(350, 350, 100, 20);

		JButton newButton = new JButton("New");
		newButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					travel.setName(nameText.getText());
					travel.setDescription(descriptionText.getText());
					travel.setServices(servicesText.getText());

					if (!ifEmptyFields()) {

						NewTravelController travelController = (NewTravelController) ControllerFactory.getInstance()
								.getController(ControllerFactory.controllerOptions.NEW_TRAVEL_PANEL_CONTROLLER.value);

						travelController.addNewTravel(travel);

						nameText.setText("");
						descriptionText.setText("");
						servicesText.setText("");

						travel = new Travel();

						PanelFactory.getInstance().hideAll();
						PanelFactory.getInstance().show(PanelFactory.panelOptions.MAIN_PANEL.value);
					} else {
						JOptionPane.showMessageDialog(new JFrame(), "Fields cannot be empty!", "Error",
								JOptionPane.ERROR_MESSAGE);
					}

				} catch (Exception le) {
					JOptionPane.showMessageDialog(new JFrame(), le.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}

		});
		add(newButton);
		newButton.setBounds(250, 400, 100, 20);

		JButton backButton = new JButton("Volver");
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PanelFactory.getInstance().hideAll();
				PanelFactory.getInstance().show(PanelFactory.panelOptions.MAIN_PANEL.value);
			}
		});
		add(backButton);
		backButton.setBounds(350, 400, 100, 20);
	}

	private boolean ifEmptyFields() {
		return null == travel.getName() || null == travel.getDescription() || null == travel.getServices()
				|| null == travel.getTravelType() || null == travel.getInitDate() || null == travel.getEndDate()
				|| null == travel.getCountry();
	}
}
