package agency.view.panel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import agency.view.PanelFactory;
import agency.view.frame.Frame;
import agency.view.panel.component.WellcomeImagePanel;

/**
 * Panel de Bienvenida
 */
public class WellcomePanel extends PanelAbstract {

	private static final long serialVersionUID = -3033810822365121027L;

	public WellcomePanel() {
		initialize();
	}

	private void initialize() {
		setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);
		setLayout(null);
		
		WellcomeImagePanel imagePanel = new WellcomeImagePanel(WellcomeImagePanel.imgOptions.WELLCOME_BACKGROUND.value);
		imagePanel.setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);
		imagePanel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PanelFactory.getInstance().hideAll();
				PanelFactory.getInstance().show(PanelFactory.panelOptions.LOGIN_PANEL.value);
			}
		});
		add(imagePanel);
	}
}
