package agency.view.panel;

/**
 * Panel de Nuevo Viaje
 */
public class TripPanel extends PanelAbstract{

	private static final long serialVersionUID = -3033810822365121027L;

}
