package agency.view.panel;

/**
 * Panel de Nuevo Evento
 */
public class NewEventPanel extends PanelAbstract{

	private static final long serialVersionUID = -9058581121759426409L;

}
