package agency.view.panel;

import java.awt.Color;

import agency.view.frame.Frame;
import agency.view.panel.component.AgencyAndPassPanel;
import agency.view.panel.component.WellcomeImagePanel;

/**
 * Panel de Login
 */
public class LoginPanel extends PanelAbstract {

	private static final long serialVersionUID = -3033810822365121027L;

	public LoginPanel() {
		initialize();
	}

	private void initialize() {
		setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);
		setLayout(null);

		WellcomeImagePanel imagePanel = new WellcomeImagePanel(WellcomeImagePanel.imgOptions.WELLCOME_BACKGROUND_GREY.value);
		imagePanel.setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);

		AgencyAndPassPanel agencyAndPassPanel = new AgencyAndPassPanel();
		agencyAndPassPanel.setBounds(0, Frame.paneHeight/3, Frame.paneWidth, Frame.paneHeight/3);
		agencyAndPassPanel.setBackground(Color.LIGHT_GRAY);
		
//		layeredPane.add(imagePanel, 0);
		add(agencyAndPassPanel);
	}
}
