package agency.view.panel;

/**
 * Panel de Nueva Acomodacion
 */
public class NewAccommodationPanel extends PanelAbstract {

	private static final long serialVersionUID = 8683930365140692821L;

}
