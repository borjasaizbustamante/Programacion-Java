package agency.view.panel;

/**
 * Panel de Nuevo Vuelo
 */
public class NewFlightPanel extends PanelAbstract{

	private static final long serialVersionUID = 1696553065206938683L;

}
