package agency.view.panel;

import java.awt.Color;

import agency.view.frame.Frame;
import agency.view.panel.component.WellcomeImagePanel;
import agency.view.panel.component.TableEventsPanel;
import agency.view.panel.component.TableTravelsPanel;

/**
 * Panel principal
 */
public class MainPanel extends PanelAbstract {

	private static final long serialVersionUID = 9009813945039660395L;

	private TableTravelsPanel tableTravelsPanel = null;
	private TableEventsPanel tableEventsPanel = null;
	
	public MainPanel() {
		initialize();
	}

	private void initialize() {
		setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);
		setLayout(null);
		
		WellcomeImagePanel imagePanel = new WellcomeImagePanel(WellcomeImagePanel.imgOptions.WELLCOME_BACKGROUND_GREY.value);
		imagePanel.setBounds(0, 0, Frame.paneWidth, Frame.paneHeight);
		
		tableEventsPanel = new TableEventsPanel(Frame.paneWidth, Frame.paneHeight/2 - 1);
		tableEventsPanel.setBounds(0, Frame.paneHeight/2 - 1, Frame.paneWidth, Frame.paneHeight/2 - 1);
		tableEventsPanel.setBackground(Color.LIGHT_GRAY);
		
		tableTravelsPanel = new TableTravelsPanel(tableEventsPanel, Frame.paneWidth, Frame.paneHeight/2 - 1);
		tableTravelsPanel.setBounds(0, 0, Frame.paneWidth, Frame.paneHeight/2 - 1);
		tableTravelsPanel.setBackground(Color.LIGHT_GRAY);
		
		add(tableTravelsPanel);
		add(tableEventsPanel);
	}
	
	public void clearTables() {
		tableTravelsPanel.clearTable();
		tableEventsPanel.clearTable();
	}
	
	public void refreshTables() {
		tableTravelsPanel.refreshTravelTable();
		tableEventsPanel.refreshEventsTable();
	}
}
