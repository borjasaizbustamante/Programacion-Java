package agency.view.panel;

import javax.swing.JPanel;

/**
 * Una clase abstracta en Java es una clase que no se puede instanciar
 * directamente y que sirve como base para otras clases. Esta pensada
 * principalmente para que otras clases puedan heredar de ella. <br>
 * </br>
 * PanelAbstract existe para que todos los Panels hereden de ella. En este
 * caso, se utiliza unicamente para que PanelFactory sea capaz de almacenar
 * en un Map cualquier tipo de Panel.
 */
public abstract class PanelAbstract extends JPanel {

	private static final long serialVersionUID = 4579037110257820574L;

}
