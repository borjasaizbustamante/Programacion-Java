package agency.view.panel.component;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 * Sub-Panel de Imagen del Panel de Bienvenida
 */
public class WellcomeImagePanel extends JPanel {

	private static final long serialVersionUID = 6047902983623304932L;

	private static final String IMGS_FILE = "/agency/view/imgs/";

	private BufferedImage image;

	// Inner class for the configuration options in the properties file
	public static enum imgOptions {
		WELLCOME_BACKGROUND("wellcome_background.jpeg"), WELLCOME_BACKGROUND_GREY("wellcome_background_grey.jpg");

		public final String value;

		private imgOptions(String value) {
			this.value = value;
		}
	}

	public WellcomeImagePanel(String resourcePath) {
		try {
			image = ImageIO.read(getClass().getResourceAsStream(IMGS_FILE + resourcePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		if (image != null) {
			graphics.drawImage(image, 0, 0, getWidth(), getHeight(), this);
		}
	}
}
