package agency.view.panel.component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import agency.database.entity.Travel;
import agency.service.ControllerFactory;
import agency.service.controller.MainPanelController;
import agency.view.PanelFactory;
import agency.view.panel.tableModel.TravelsTableModel;
import agency.view.utils.Utils;

/**
 * Sub-Panel del la Tabla de Viajes
 */
public class TableTravelsPanel extends JPanel {

	private static final long serialVersionUID = 5564792861138747544L;

	public DefaultTableModel travelsTableModel = null;
	private JTable travelsTable = null;

	public TableTravelsPanel(TableEventsPanel tableEventsPanel, int paneWidth, int paneHeight) {
		initialize(tableEventsPanel, paneWidth, paneHeight);
	}

	private void initialize(TableEventsPanel tableEventsPanel, int paneWidth, int paneHeight) {
		setLayout(null);

		travelsTableModel = new TravelsTableModel().getModel();
		travelsTable = new JTable(travelsTableModel);
		JScrollPane travelsScrollPane = new JScrollPane(travelsTable);
		travelsTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = travelsTable.rowAtPoint(e.getPoint());
				if (row >= 0) {
					Long travelID = (Long) travelsTable.getValueAt(row, 0);
					Travel travel = getSelectedTravel(travelID);
					tableEventsPanel.refreshEventsTable(travel);
				}
			}
		});

		add(travelsScrollPane);
		travelsScrollPane.setBounds(0, 0, paneWidth, (paneHeight / 3) * 2);

		JButton newButton = new JButton("Nuevo");
		newButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clearTable();
				PanelFactory.getInstance().hideAll();
				PanelFactory.getInstance().show(PanelFactory.panelOptions.NEW_TRAVEL_PANEL.value);
			}
		});
		add(newButton);
		newButton.setBounds(0, (paneHeight / 3) * 2 + 1, 100, 50);

		JButton deleteButton = new JButton("Borrar");
		deleteButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		add(deleteButton);
		deleteButton.setBounds(paneWidth / 2 - 50, (paneHeight / 3) * 2 + 1, 100, 50);

		JButton backButton = new JButton("Volver");
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clearTable();
				PanelFactory.getInstance().hideAll();
				PanelFactory.getInstance().show(PanelFactory.panelOptions.NEW_WELLCOME_PANEL.value);
			}
		});
		add(backButton);
		backButton.setBounds(paneWidth - 100, (paneHeight / 3) * 2 + 1, 100, 50);
	}

	public void refreshTravelTable() {
		MainPanelController mainPanelController = (MainPanelController) ControllerFactory.getInstance()
				.getController(ControllerFactory.controllerOptions.MAIN_PANEL_CONTROLLER.value);

		List<Travel> travels = mainPanelController.refreshTravelTable();

		clearTable();
		for (Travel travel : travels) {
			addRow(travel);
		}
	}

	private void addRow(Travel travel) {
		travelsTableModel.addRow(new Object[] { travel.getId(), travel.getName(), travel.getTravelType().getText(),
				Utils.daysPassed(travel.getInitDate(), travel.getEndDate()), Utils.dateToString(travel.getInitDate()),
				Utils.dateToString(travel.getEndDate()), travel.getCountry().getText() });

		TableColumnModel columnModel = travelsTable.getColumnModel();
		TableColumn columnToHide = columnModel.getColumn(0);
		columnToHide.setMinWidth(0);
		columnToHide.setMaxWidth(0);
		columnToHide.setPreferredWidth(0);
		columnToHide.setResizable(false);
	}

	private Travel getSelectedTravel(Long id) {
		MainPanelController mainPanelController = (MainPanelController) ControllerFactory.getInstance()
				.getController(ControllerFactory.controllerOptions.MAIN_PANEL_CONTROLLER.value);

		return mainPanelController.getSelectedTravel(id);
	}

	public void clearTable() {
		travelsTableModel.setRowCount(0);
	}
}
