package agency.view.panel.component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import agency.service.ControllerFactory;
import agency.service.controller.LoginPanelController;
import agency.service.exception.LoginException;
import agency.view.PanelFactory;

/**
 * Sub-Panel del Login y Password
 */
public class AgencyAndPassPanel extends JPanel {

	private static final long serialVersionUID = -3110903335563772231L;

	public AgencyAndPassPanel() {
		initialize();
	}

	private void initialize() {
		setLayout(null);
		
		JLabel agencyLabel = new JLabel("Agency:");
		JTextField agencyText = new JTextField();

		JLabel passLabel = new JLabel("Password:");
		JPasswordField passText = new JPasswordField();

		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String agency = agencyText.getText();
					String password = new String(passText.getPassword());

					LoginPanelController loginPanelController = (LoginPanelController) ControllerFactory.getInstance()
							.getController(ControllerFactory.controllerOptions.LOGIN_PANEL_CONTROLLER.value);
					loginPanelController.validate(agency, password);
					
					agencyText.setText("");
					passText.setText("");
					
					PanelFactory.getInstance().hideAll();
					PanelFactory.getInstance().show(PanelFactory.panelOptions.MAIN_PANEL.value);
					
				} catch (LoginException le) {
					JOptionPane.showMessageDialog(new JFrame(), le.getMessage(), 
	                        "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		add(agencyLabel);
		agencyLabel.setBounds(250, 50, 100, 20);
		
		add(agencyText);
		agencyText.setBounds(350, 50, 100, 20);
		
		add(passLabel);
		passLabel.setBounds(250, 130, 100, 20);
		
		add(passText);
		passText.setBounds(350, 130, 100, 20);
		
		add(loginButton);
		loginButton.setBounds(550, 50, 200, 100);
	}
}
