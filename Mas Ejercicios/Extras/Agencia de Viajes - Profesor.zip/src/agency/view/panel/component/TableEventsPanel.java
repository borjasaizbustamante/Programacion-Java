package agency.view.panel.component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import agency.database.entity.Accomodation;
import agency.database.entity.Activity;
import agency.database.entity.Event;
import agency.database.entity.Flight;
import agency.database.entity.Travel;
import agency.service.ControllerFactory;
import agency.service.controller.MainPanelController;
import agency.view.PanelFactory;
import agency.view.panel.tableModel.EventsTableModel;
import agency.view.utils.Utils;

/**
 * Sub-Panel del la Tabla de Eventos
 */
public class TableEventsPanel extends JPanel {

	private static final long serialVersionUID = 5564792861138747544L;

	public DefaultTableModel eventsTableModel = null;

	public TableEventsPanel(int paneWidth, int paneHeight) {
		initialize(paneWidth, paneHeight);
	}

	private void initialize(int paneWidth, int paneHeight) {
		setLayout(null);

		eventsTableModel = new EventsTableModel().getModel();
		JTable eventsTable = new JTable(eventsTableModel);
		JScrollPane eventsScrollPane = new JScrollPane(eventsTable);
		add(eventsScrollPane);
		eventsScrollPane.setBounds(0, 0, paneWidth, (paneHeight / 3) * 2);
		JButton newButton = new JButton("Nuevo");
		newButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clearTable();
				PanelFactory.getInstance().hideAll();
				PanelFactory.getInstance().show(PanelFactory.panelOptions.NEW_TRAVEL_PANEL.value);
			}
		});
		add(newButton);
		newButton.setBounds(0, (paneHeight / 3) * 2 + 1, 100, 50);

		JButton deleteButton = new JButton("Borrar");
		deleteButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});
		add(deleteButton);
		deleteButton.setBounds(paneWidth / 2 - 50, (paneHeight / 3) * 2 + 1, 100, 50);

		JButton backButton = new JButton("Volver");
		backButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clearTable();
				PanelFactory.getInstance().hideAll();
				PanelFactory.getInstance().show(PanelFactory.panelOptions.NEW_WELLCOME_PANEL.value);
			}
		});
		add(backButton);
		backButton.setBounds(paneWidth - 100, (paneHeight / 3) * 2 + 1, 100, 50);
	}

	public void refreshEventsTable() {
		clearTable();
	}
	
	public void refreshEventsTable(Travel selectedTravel) {
		MainPanelController mainPanelController = (MainPanelController) ControllerFactory.getInstance()
				.getController(ControllerFactory.controllerOptions.MAIN_PANEL_CONTROLLER.value);

		List<Event> events = mainPanelController.refreshEventTable(selectedTravel);

		clearTable();
		for (Event event : events) {
			addRow(event);
		}
	}

	private void addRow(Event event) {
		if (event instanceof Accomodation)
			addRow((Accomodation) event);
		else if (event instanceof Flight)
			addRow((Flight) event);
		if (event instanceof Activity)
			addRow((Activity) event);
	}

	private void addRow(Flight flight) {
		eventsTableModel.addRow(new Object[] { flight.getId(), flight.getName(), "Vuelo",
				Utils.dateToString(flight.getOneWayTrip().getDate()), flight.getOneWayTrip().getPrice() });
	}

	private void addRow(Accomodation accomodation) {
		eventsTableModel.addRow(new Object[] { accomodation.getId(), accomodation.getName(), "Alojam",
				Utils.dateToString(accomodation.getInitDate()), accomodation.getPrice() });
	}
	
	private void addRow(Activity activity) {
		eventsTableModel.addRow(new Object[] { activity.getId(), activity.getName(), "Activ",
				Utils.dateToString(activity.getDate()), activity.getPrice() });
	}
	
	public void clearTable() {
		eventsTableModel.setRowCount(0);
	}

}
