package agency.view.panel;

/**
 * Panel de Nueva Actividad
 */
public class NewActivityPanel extends PanelAbstract {

	private static final long serialVersionUID = -631491149202918245L;

}
