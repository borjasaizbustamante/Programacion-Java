package agency.view.utils;

import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 * Utilidades de la Interfaz
 */
public class Utils {

	public static String dateToString(Date sqlDate) {
		return new SimpleDateFormat("dd/MM/yy").format(new java.util.Date(sqlDate.getTime()));
	}

	public static long daysPassed(Date startDate, Date endDate) {
		return ((new java.util.Date(endDate.getTime())).getTime() - (new java.util.Date(startDate.getTime())).getTime())
				/ (24 * 60 * 60 * 1000);
	}
	
	public static java.util.Date sqlDateToUtilDate (java.sql.Date sqlDate) {
		return new java.util.Date(sqlDate.getTime());
	}
	
	public static java.sql.Date utilDateToSQLDate (java.util.Date utilDate) {
		return new java.sql.Date(utilDate.getTime());
	}
}
