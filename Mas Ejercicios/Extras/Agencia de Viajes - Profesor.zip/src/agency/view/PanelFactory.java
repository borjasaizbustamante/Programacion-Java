package agency.view;

import java.util.HashMap;
import java.util.Map;

import agency.view.panel.LoginPanel;
import agency.view.panel.MainPanel;
import agency.view.panel.NewAccommodationPanel;
import agency.view.panel.NewActivityPanel;
import agency.view.panel.NewEventPanel;
import agency.view.panel.NewFlightPanel;
import agency.view.panel.NewTravelPanel;
import agency.view.panel.PanelAbstract;
import agency.view.panel.WellcomePanel;

/**
 * Hay distintos tipos de Patrones Factoria. Este es uno de ellos. Se les llaam
 * Factorias porque funcionan como fabricas de objetos. Si quieres un objeto, se
 * lo pides a ellos. <br>
 * </br>
 * PanelFactory en concreto tiene un Singleton y adicionalmente, devuelve (no
 * crea) un objeto del tipo que le piden, en este caso, un Panel
 */
public class PanelFactory {

	private static PanelFactory instance = null;

	private Map<String, PanelAbstract> panels = null;

	// Inner class for the key values in the panels HashMap
	public static enum panelOptions {
		LOGIN_PANEL("loginPanel"), MAIN_PANEL("mainPanel"), NEW_ACCOMODATION_PANEL("accommodationPanel"),
		NEW_ACTIVITY_PANEL("activityPanel"), NEW_EVENT_PANEL("eventPanel"), NEW_FLIGHT_PANEL("flightPanel"),
		NEW_TRAVEL_PANEL("travelPanel"), NEW_WELLCOME_PANEL("wellcomePanel");

		public final String value;

		private panelOptions(String value) {
			this.value = value;
		}
	}

	public PanelFactory() {
		panels = new HashMap<String, PanelAbstract>();
		panels.put(panelOptions.LOGIN_PANEL.value, new LoginPanel());
		panels.put(panelOptions.MAIN_PANEL.value, new MainPanel());
		panels.put(panelOptions.NEW_ACCOMODATION_PANEL.value, new NewAccommodationPanel());
		panels.put(panelOptions.NEW_ACTIVITY_PANEL.value, new NewActivityPanel());
		panels.put(panelOptions.NEW_EVENT_PANEL.value, new NewEventPanel());
		panels.put(panelOptions.NEW_FLIGHT_PANEL.value, new NewFlightPanel());
		panels.put(panelOptions.NEW_TRAVEL_PANEL.value, new NewTravelPanel());
		panels.put(panelOptions.NEW_WELLCOME_PANEL.value, new WellcomePanel());
	}

	public static PanelFactory getInstance() {
		return instance = instance == null ? new PanelFactory() : instance;
	}

	public PanelAbstract getPanel(String panelOption) {
		return panels.get(panelOption);
	}

	public void hideAll() {
		panels.forEach((_, value) -> value.setVisible(false));
	}

	public void showAll() {
		panels.forEach((_, value) -> value.setVisible(true));
	}

	public void show(String panelOption) {
		switch (panelOption) {
		case "mainPanel":
			showMainPanel();
			break;
		default:
			panels.get(panelOption).setVisible(true);
		}
	}

	public void hide(String panelOption) {
		panels.get(panelOption).setVisible(false);
	}

	private void showMainPanel() {
		MainPanel mainPanel = (MainPanel) panels.get(panelOptions.MAIN_PANEL.value);
		mainPanel.clearTables();
		mainPanel.refreshTables();
		mainPanel.setVisible(true);
	}

}
