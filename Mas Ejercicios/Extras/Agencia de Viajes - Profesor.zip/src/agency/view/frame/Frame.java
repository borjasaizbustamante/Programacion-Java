package agency.view.frame;

import javax.swing.JFrame;

import agency.view.PanelFactory;
import agency.view.panel.LoginPanel;
import agency.view.panel.MainPanel;
import agency.view.panel.NewAccommodationPanel;
import agency.view.panel.NewActivityPanel;
import agency.view.panel.NewEventPanel;
import agency.view.panel.NewFlightPanel;
import agency.view.panel.NewTravelPanel;
import agency.view.panel.PanelAbstract;
import agency.view.panel.WellcomePanel;

/**
 * Ventana principal del programa
 */
public class Frame {

	private JFrame frame;

	private static final int COOR_X = 300;
	private static final int COOR_Y = 100;
	private static final int WIDTH = 1024;
	private static final int HEIGHT = 768;
	public static int paneWidth = 0;
	public static int paneHeight = 0;

	public Frame() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(COOR_X, COOR_Y, WIDTH, HEIGHT);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);

		paneWidth = frame.getContentPane().getWidth();
		paneHeight = frame.getContentPane().getHeight();

		addPanelsToFrame(frame);

		PanelFactory.getInstance().hideAll();
		PanelFactory.getInstance().show(PanelFactory.panelOptions.NEW_WELLCOME_PANEL.value);
	}

	private void addPanelsToFrame(JFrame frame) {

		addPanelToFrame(frame,
				(MainPanel) PanelFactory.getInstance().getPanel(PanelFactory.panelOptions.MAIN_PANEL.value));
		addPanelToFrame(frame, (NewAccommodationPanel) PanelFactory.getInstance()
				.getPanel(PanelFactory.panelOptions.NEW_ACCOMODATION_PANEL.value));
		addPanelToFrame(frame, (NewActivityPanel) PanelFactory.getInstance()
				.getPanel(PanelFactory.panelOptions.NEW_ACTIVITY_PANEL.value));
		addPanelToFrame(frame,
				(NewEventPanel) PanelFactory.getInstance().getPanel(PanelFactory.panelOptions.NEW_EVENT_PANEL.value));
		addPanelToFrame(frame,
				(NewFlightPanel) PanelFactory.getInstance().getPanel(PanelFactory.panelOptions.NEW_FLIGHT_PANEL.value));
		addPanelToFrame(frame,
				(NewTravelPanel) PanelFactory.getInstance().getPanel(PanelFactory.panelOptions.NEW_TRAVEL_PANEL.value));
		addPanelToFrame(frame, (WellcomePanel) PanelFactory.getInstance()
				.getPanel(PanelFactory.panelOptions.NEW_WELLCOME_PANEL.value));
		addPanelToFrame(frame,
				(LoginPanel) PanelFactory.getInstance().getPanel(PanelFactory.panelOptions.LOGIN_PANEL.value));

	}

	private void addPanelToFrame(JFrame frame, PanelAbstract panel) {
		frame.getContentPane().add(panel);
		frame.revalidate();
		frame.repaint();
	}

}
