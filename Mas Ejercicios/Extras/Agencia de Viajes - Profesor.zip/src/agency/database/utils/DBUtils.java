package agency.database.utils;

/**
 * Configuraciones de Base de Datos
 */
public class DBUtils {

	private static DBUtils instance = null;

	private String url = null;
	private String driver = null;
	private String user = null;
	private String pass = null;

	/**
	 * Returns the sole instance of ServerConfig
	 * 
	 * @return The sole ServerConfig instance
	 * @throws RuntimeException
	 */
	public static DBUtils getInstance() throws RuntimeException {
		return instance = instance == null ? new DBUtils() : instance;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
}
