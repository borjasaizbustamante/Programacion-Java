package agency.database.config;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * The database configuration class. Properties are found at
 * config//config.properties configuration file.
 * 
 * This class follows the Singleton Design Pattern.
 */
public class DataBaseConfig {

	private static DataBaseConfig instance = null;

	private static final String CONFIG_FILE = "/agency/config.properties";

	private Properties properties = null;

	// Inner class for the configuration options in the properties file
	public static enum configOptions {
		DDBB_URL("db.url"), DDBB_DRIVER("db.driver"), DDBB_USER("db.user"), DDBB_PASS("db.pass");

		public final String value;

		private configOptions(String value) {
			this.value = value;
		}
	}

	/**
	 * Returns the sole instance of ServerConfig
	 * 
	 * @return The sole ServerConfig instance
	 * @throws RuntimeException
	 */
	public static DataBaseConfig getInstance() throws RuntimeException {
		return instance = instance == null ? new DataBaseConfig() : instance;
	}

	private DataBaseConfig() throws RuntimeException {
		loadConfigFile();
	}

	/**
	 * Loads the configuration file
	 * 
	 * @throws RuntimeException
	 */
	private void loadConfigFile() throws RuntimeException {
		
		InputStream inputStream = null;
		try {
			inputStream = getClass().getResourceAsStream(CONFIG_FILE);
			properties = new Properties();
			properties.load(inputStream);
		} catch (FileNotFoundException e) {
			throw new RuntimeException("config.properties not found at config file path " + CONFIG_FILE);
		} catch (Exception e) {
			throw new RuntimeException("config.properties at config file path " + CONFIG_FILE + " is invalid");
		} finally {
			try {
				if (null != inputStream)
					inputStream.close();
			} catch (IOException e) {
				//
			}
		}
	}

	/**
	 * Returns the property specified in the configuration file
	 * 
	 * @param property
	 * @return the property value
	 * @throws RuntimeException
	 */
	public String getProperty(String property) throws RuntimeException {
		String value = properties.getProperty(property);
		if (value == null)
			throw new RuntimeException("The property " + property + " is not specified in the config.properties file.");
		return value;
	}

	/**
	 * Returns the numeric property specified in the configuration file
	 * 
	 * @param property
	 * @return the property value
	 * @throws RuntimeException
	 */
	public int getNumericProperty(String property) throws RuntimeException {
		int ret = 0;
		String value = properties.getProperty(property);
		if (value == null)
			throw new RuntimeException("The property " + property + " is not specified in the config.properties file.");
		try {
			ret = Integer.parseInt(value);
		} catch (NumberFormatException nfe) {
			throw new RuntimeException(
					"The property " + property + " is not a numeric value in the config.properties file.");
		}
		return ret;
	}
}
