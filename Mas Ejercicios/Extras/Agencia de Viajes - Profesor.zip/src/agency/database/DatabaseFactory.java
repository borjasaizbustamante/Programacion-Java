package agency.database;

import java.util.HashMap;
import java.util.Map;

import agency.database.manager.AccomodationManager;
import agency.database.manager.ActivityManager;
import agency.database.manager.AgencyManager;
import agency.database.manager.CountryTypeManager;
import agency.database.manager.EventManager;
import agency.database.manager.FlightManager;
import agency.database.manager.ManagerAbstract;
import agency.database.manager.TravelManager;
import agency.database.manager.TravelTypeManager;
import agency.database.manager.TripManager;

/**
 * Hay distintos tipos de Patrones Factoria. Este es uno de ellos. Se les llaam
 * Factorias porque funcionan como fabricas de objetos. Si quieres un objeto, se
 * lo pides a ellos. <br>
 * </br>
 * DatabaseFactory en concreto tiene un Singleton y adicionalmente, devuelve (no
 * crea) un objeto del tipo que le piden, en este caso, un Manager
 */
public class DatabaseFactory {

	private static DatabaseFactory instance = null;

	private Map<String, ManagerAbstract> managers = null;

	// Inner class for the key values in the panels HashMap
	public static enum panelOptions {
		ACCOMODATION_MANAGER("accomodationManager"), ACTIVITY_MANAGER("activityManager"),
		AGENCY_MANAGER("agencyManager"), EVENT_MANAGER("eventManager"), FLIGHT_MANAGER("flightManager"),
		TRAVEL_MANAGER("travelManager"), TRIP_MANAGER("tripManager"), TRAVEL_TYPE_MANAGER("travelTypeManager"),
		COUNTRY_TYPE_MANAGER("countryTypeManager");

		public final String value;

		private panelOptions(String value) {
			this.value = value;
		}
	}

	public DatabaseFactory() {
		managers = new HashMap<String, ManagerAbstract>();
		managers.put(panelOptions.ACCOMODATION_MANAGER.value, new AccomodationManager());
		managers.put(panelOptions.ACTIVITY_MANAGER.value, new ActivityManager());
		managers.put(panelOptions.AGENCY_MANAGER.value, new AgencyManager());
		managers.put(panelOptions.EVENT_MANAGER.value, new EventManager());
		managers.put(panelOptions.FLIGHT_MANAGER.value, new FlightManager());
		managers.put(panelOptions.TRAVEL_MANAGER.value, new TravelManager());
		managers.put(panelOptions.TRIP_MANAGER.value, new TripManager());
		managers.put(panelOptions.TRAVEL_TYPE_MANAGER.value, new TravelTypeManager());
		managers.put(panelOptions.COUNTRY_TYPE_MANAGER.value, new CountryTypeManager());
	}

	public static DatabaseFactory getInstance() {
		return instance = instance == null ? new DatabaseFactory() : instance;
	}

	public ManagerAbstract getManager(String panelOption) {
		return managers.get(panelOption);
	}
}
