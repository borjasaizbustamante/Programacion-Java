package agency.database.entity;

/**
 * Una clase abstracta en Java es una clase que no se puede instanciar
 * directamente y que sirve como base para otras clases. Esta pensada
 * principalmente para que otras clases puedan heredar de ella. <br>
 * </br>
 * EntityAbstract existe para que todos los Entity hereden de ella.
 */
public abstract class EntityAbstract {

}
