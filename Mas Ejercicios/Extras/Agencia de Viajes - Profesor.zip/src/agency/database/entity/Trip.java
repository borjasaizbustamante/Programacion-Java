package agency.database.entity;

import java.sql.Date;
import java.util.Objects;

/**
 * Esta entidad (POJO) describe la tabla Travel
 */
public class Trip extends Event{

	private long id = 0;
	private Date date = null;
	private String flightCode = null;
	private String airline = null;
	private long price = 0;
	private Date time = null;
	private Date duration = null;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Date getDuration() {
		return duration;
	}

	public void setDuration(Date duration) {
		this.duration = duration;
	}

	@Override
	public int hashCode() {
		return Objects.hash(airline, date, duration, flightCode, id, price, time);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trip other = (Trip) obj;
		return Objects.equals(airline, other.airline) && Objects.equals(date, other.date)
				&& Objects.equals(duration, other.duration) && Objects.equals(flightCode, other.flightCode)
				&& id == other.id && price == other.price && Objects.equals(time, other.time);
	}

	@Override
	public String toString() {
		return "Trip [id=" + id + ", date=" + date + ", flightCode=" + flightCode + ", airline=" + airline + ", price="
				+ price + ", time=" + time + ", duration=" + duration + "]";
	}

}
