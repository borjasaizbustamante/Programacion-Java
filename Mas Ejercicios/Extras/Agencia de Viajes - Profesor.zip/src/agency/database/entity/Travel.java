package agency.database.entity;

import java.sql.Date;
import java.util.List;
import java.util.Objects;

import agency.database.entity.enums.Country;
import agency.database.entity.enums.TravelType;

/**
 * Esta entidad (POJO) describe la tabla Travel
 */
public class Travel extends EntityAbstract {

	private long id = 0;
	private String name = null;
	private TravelType travelType = null;
	private Date initDate = null;
	private Date endDate = null;
	private Country country = null;
	private String description = null;
	private String services = null;

	// N - 1 with Agency
	private Agency agency = null;

	// 1 - N with Event
	private List<Event> events = null;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TravelType getTravelType() {
		return travelType;
	}

	public void setTravelType(TravelType travelType) {
		this.travelType = travelType;
	}

	public Date getInitDate() {
		return initDate;
	}

	public void setInitDate(Date initDate) {
		this.initDate = initDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}

	public Agency getAgency() {
		return agency;
	}

	public void setAgency(Agency agency) {
		this.agency = agency;
	}

	public List<Event> getEvents() {
		return events;
	}

	public void setEvents(List<Event> events) {
		this.events = events;
	}

	@Override
	public int hashCode() {
		return Objects.hash(agency, country, description, endDate, events, id, initDate, name, services, travelType);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Travel other = (Travel) obj;
		return Objects.equals(agency, other.agency) && Objects.equals(country, other.country)
				&& Objects.equals(description, other.description) && Objects.equals(endDate, other.endDate)
				&& Objects.equals(events, other.events) && id == other.id && Objects.equals(initDate, other.initDate)
				&& Objects.equals(name, other.name) && Objects.equals(services, other.services)
				&& Objects.equals(travelType, other.travelType);
	}

	@Override
	public String toString() {
		return "Travel [id=" + id + ", name=" + name + ", travelType=" + travelType + ", initDate=" + initDate
				+ ", endDate=" + endDate + ", country=" + country + ", description=" + description + ", services="
				+ services + ", agency=" + agency + ", events=" + events + "]";
	}

}
