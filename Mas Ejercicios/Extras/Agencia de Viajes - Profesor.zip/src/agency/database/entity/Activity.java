package agency.database.entity;

import java.sql.Date;
import java.util.Objects;

/**
 * Esta entidad (POJO) describe la tabla Activity
 */
public class Activity extends Event {

	private String description = null;
	private Date date = null;
	private long price = 0;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(date, description, price);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Activity other = (Activity) obj;
		return Objects.equals(date, other.date) && Objects.equals(description, other.description)
				&& price == other.price;
	}

	@Override
	public String toString() {
		return "Activity [description=" + description + ", date=" + date + ", price=" + price + "]";
	}

}
