package agency.database.entity;

import java.util.Objects;

/**
 * Esta entidad (POJO) describe la tabla Event
 */
public abstract class Event extends EntityAbstract {

	private long id = 0;
	private String name = null;

	// N - 1 with Travel
	private Travel travel = null;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Travel getTravel() {
		return travel;
	}

	public void setTravel(Travel travel) {
		this.travel = travel;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, travel);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Event other = (Event) obj;
		return id == other.id && Objects.equals(name, other.name) && Objects.equals(travel, other.travel);
	}

	@Override
	public String toString() {
		return "Event [id=" + id + ", name=" + name + ", travel=" + travel + "]";
	}

}
