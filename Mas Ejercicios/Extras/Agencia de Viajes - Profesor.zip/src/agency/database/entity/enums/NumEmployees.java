package agency.database.entity.enums;

/**
 * Enumerado de tipo NumEmployees
 */
public class NumEmployees extends EnumerationAbstract{

}
