package agency.database.entity.enums;

/**
 * Enumerado de tipo RoomType
 */
public class RoomType extends EnumerationAbstract{

}
