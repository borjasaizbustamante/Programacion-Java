package agency.database.entity.enums;

import java.util.Objects;

/**
 * Una clase abstracta en Java es una clase que no se puede instanciar
 * directamente y que sirve como base para otras clases. Esta pensada
 * principalmente para que otras clases puedan heredar de ella. <br>
 * </br>
 * EnumerationAbstract existe para que todos los Enumeration hereden de ella.
 */
public abstract class EnumerationAbstract {

	private long id = 0;
	private String text = null;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, text);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EnumerationAbstract other = (EnumerationAbstract) obj;
		return id == other.id && Objects.equals(text, other.text);
	}

	@Override
	public String toString() {
		return "Enum [id=" + id + ", text=" + text + "]";
	}

}
