package agency.database.entity.enums;

/**
 * Enumerado de tipo EventType
 */
public class EventType extends EnumerationAbstract {

}
