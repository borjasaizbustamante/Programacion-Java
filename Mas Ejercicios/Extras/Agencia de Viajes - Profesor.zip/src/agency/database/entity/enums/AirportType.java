package agency.database.entity.enums;

/**
 * Enumerado de tipo AirportType
 */
public class AirportType extends EnumerationAbstract{

}
