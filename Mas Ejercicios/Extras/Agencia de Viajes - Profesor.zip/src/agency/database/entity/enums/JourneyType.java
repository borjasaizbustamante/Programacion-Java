package agency.database.entity.enums;

/**
 * Enumerado de tipo JourneyType
 */
public class JourneyType extends EnumerationAbstract {

}
