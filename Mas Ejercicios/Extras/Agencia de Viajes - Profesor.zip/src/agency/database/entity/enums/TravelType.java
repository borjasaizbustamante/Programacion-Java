package agency.database.entity.enums;

/**
 * Enumerado de tipo RoomType
 */
public class TravelType extends EnumerationAbstract {

	/**
	 * Returns a string representation of the object for the combo box
	 */
	@Override
	public String toString() {
		return getText();
	}

}
