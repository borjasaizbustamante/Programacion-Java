package agency.database.entity;

import java.util.Objects;

import agency.database.entity.enums.AirportType;
import agency.database.entity.enums.JourneyType;

/**
 * Esta entidad (POJO) describe la tabla Flight
 */
public class Flight extends Event {

	private JourneyType journeyType = null;
	private AirportType oneWayAirport = null;
	private AirportType roundTripAirport = null;

	private Trip oneWayTrip = null;
	private Trip roundTrip = null;

	public JourneyType getJourneyType() {
		return journeyType;
	}

	public void setJourneyType(JourneyType journeyType) {
		this.journeyType = journeyType;
	}

	public AirportType getOneWayAirport() {
		return oneWayAirport;
	}

	public void setOneWayAirport(AirportType oneWayAirport) {
		this.oneWayAirport = oneWayAirport;
	}

	public AirportType getRoundTripAirport() {
		return roundTripAirport;
	}

	public void setRoundTripAirport(AirportType roundTripAirport) {
		this.roundTripAirport = roundTripAirport;
	}

	public Trip getOneWayTrip() {
		return oneWayTrip;
	}

	public void setOneWayTrip(Trip oneWayTrip) {
		this.oneWayTrip = oneWayTrip;
	}

	public Trip getRoundTrip() {
		return roundTrip;
	}

	public void setRoundTrip(Trip roundTrip) {
		this.roundTrip = roundTrip;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(journeyType, oneWayAirport, oneWayTrip, roundTrip, roundTripAirport);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		return Objects.equals(journeyType, other.journeyType) && Objects.equals(oneWayAirport, other.oneWayAirport)
				&& Objects.equals(oneWayTrip, other.oneWayTrip) && Objects.equals(roundTrip, other.roundTrip)
				&& Objects.equals(roundTripAirport, other.roundTripAirport);
	}

	@Override
	public String toString() {
		return "Flight [journeyType=" + journeyType + ", oneWayAirport=" + oneWayAirport + ", roundTripAirport="
				+ roundTripAirport + ", oneWayTrip=" + oneWayTrip + ", roundTrip=" + roundTrip + "]";
	}

}
