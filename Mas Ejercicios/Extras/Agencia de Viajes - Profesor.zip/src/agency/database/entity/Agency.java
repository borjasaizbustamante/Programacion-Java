package agency.database.entity;

import java.util.List;
import java.util.Objects;

import agency.database.entity.enums.NumEmployees;

/**
 * Esta entidad (POJO) describe la tabla Agency
 */
public class Agency extends EntityAbstract {

	private long id = 0;
	private String name = null;
	private String pass = null;
	private String color = null;
	private NumEmployees numEmployees = null;
	private String logo = null;

	// 1 - N with Travel
	private List<Travel> travels = null;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public NumEmployees getNumEmployees() {
		return numEmployees;
	}

	public void setNumEmployees(NumEmployees numEmployees) {
		this.numEmployees = numEmployees;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public List<Travel> getTravels() {
		return travels;
	}

	public void setTravels(List<Travel> travels) {
		this.travels = travels;
	}

	@Override
	public int hashCode() {
		return Objects.hash(color, id, logo, name, numEmployees, pass, travels);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agency other = (Agency) obj;
		return Objects.equals(color, other.color) && id == other.id && Objects.equals(logo, other.logo)
				&& Objects.equals(name, other.name) && Objects.equals(numEmployees, other.numEmployees)
				&& Objects.equals(pass, other.pass) && Objects.equals(travels, other.travels);
	}

	@Override
	public String toString() {
		return "Agency [id=" + id + ", name=" + name + ", pass=" + pass + ", color=" + color + ", numEmployees="
				+ numEmployees + ", logo=" + logo + ", travels=" + travels + "]";
	}
}
