package agency.database.entity;

import java.sql.Date;
import java.util.Objects;

import agency.database.entity.enums.RoomType;

/**
 * Esta entidad (POJO) describe la tabla Accomodation
 */
public class Accomodation extends Event {

	private RoomType roomType = null;
	private String city = null;
	private Date initDate = null;
	private Date endDate = null;
	private long price = 0;

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getInitDate() {
		return initDate;
	}

	public void setInitDate(Date initDate) {
		this.initDate = initDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(city, endDate, initDate, price, roomType);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Accomodation other = (Accomodation) obj;
		return Objects.equals(city, other.city) && Objects.equals(endDate, other.endDate)
				&& Objects.equals(initDate, other.initDate) && price == other.price
				&& Objects.equals(roomType, other.roomType);
	}

	@Override
	public String toString() {
		return "Accomodation [roomType=" + roomType + ", city=" + city + ", initDate=" + initDate + ", endDate="
				+ endDate + ", price=" + price + "]";
	}

}
