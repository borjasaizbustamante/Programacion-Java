package agency.database.manager;

import java.util.List;

/**
 * Un Interfaz es un tipo de referencia que define un contrato que las clases
 * que lo implementan deben cumplir. Especifica un conjunto de metodos, y las
 * clases estan obligadas a implementarlos.
 * <br></br>
 * Los Interfaces se definen ANTES de programar ninguna clase. El objetivo
 * principal es que, cuando alguien tiene que añadir un nuevo Manager, sepa que
 * metodos tiene que implementar.
 * <br></br>
 * ManagerInterface obliga a todos los Managers de acceso a Base de Datos a
 * implementar los metodos basicos getAll(), getByID(), insert(), delete() y
 * update().
 * 
 * @param <T>
 */
public interface ManagerInterface<T> {

	public List<T> getAll();

	public T getByID(long id);

	public void insert(T t);

	public void delete(T t);

	public void update(T t);

}
