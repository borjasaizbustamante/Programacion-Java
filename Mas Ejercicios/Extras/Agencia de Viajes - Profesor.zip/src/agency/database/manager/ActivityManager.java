package agency.database.manager;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import agency.database.entity.Activity;
import agency.database.entity.Event;
import agency.database.entity.Travel;

/**
 * Manager para la tabla Activity. Implementa el interfaz ManagerInterface
 */
public class ActivityManager extends ManagerAbstract implements ManagerInterface<Activity>{

	public List<Event> getAllActivities(Travel travel) {
		List<Event> ret = new ArrayList<>();

		if (travel.getId() == 0) {
			Activity activity = new Activity();

			activity.setId(0);
			activity.setName("Trip 1");
			activity.setDescription("Description");
			activity.setDate(new Date(new java.util.Date().getTime()));
			activity.setPrice(100);

			ret.add(activity);
		} else {
			Activity activity = new Activity();

			activity.setId(0);
			activity.setName("Trip 11");
			activity.setDescription("Description");
			activity.setDate(new Date(new java.util.Date().getTime()));
			activity.setPrice(100);

			ret.add(activity);
		}
		return ret;
	}

	@Override
	public List<Activity> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Activity getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Activity t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Activity t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Activity t) {
		// TODO Auto-generated method stub
		
	}
}
