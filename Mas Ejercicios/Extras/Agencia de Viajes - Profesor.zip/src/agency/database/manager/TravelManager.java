package agency.database.manager;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import agency.database.entity.Travel;
import agency.database.entity.enums.Country;
import agency.database.entity.enums.TravelType;

/**
 * Manager para la tabla Travel. Implementa el interfaz ManagerInterface
 */
public class TravelManager extends ManagerAbstract implements ManagerInterface<Travel> {

	private List<Travel> list = null;
	
	public TravelManager () {
		list = new ArrayList <Travel> ();
		
		Country country = new Country();
		country.setId(0);
		country.setCode("ES");
		country.setText("Spain");
		
		TravelType travelType = new TravelType();
		travelType.setId(0);
		travelType.setText("Type 1");
		
		Travel travel = new Travel();
		travel.setId(0);
		travel.setName("Travel 1");
		travel.setTravelType (travelType);
		travel.setInitDate(new Date(new java.util.Date().getTime()));
		travel.setEndDate(new Date(new java.util.Date().getTime()));
		travel.setCountry (country);
		travel.setDescription("Description 1");
		travel.setServices("Services 1");
		
		list.add(travel);
		
		Travel travel2 = new Travel();
		travel2.setId(1);
		travel2.setName("Travel 2");
		travel2.setTravelType (travelType);
		travel2.setInitDate(new Date(new java.util.Date().getTime()));
		travel2.setEndDate(new Date(new java.util.Date().getTime()));
		travel2.setCountry (country);
		travel2.setDescription("Description 2");
		travel2.setServices("Services 2");
		
		list.add(travel2);
	}
	
	@Override
	public List<Travel> getAll() {
		return list;
	}

	public Travel getTravelById(Long id) {
		return list.get(id.intValue());
	}

	@Override
	public void insert (Travel travel) {
		travel.setId(list.size());
		list.add(travel);
	}

	@Override
	public Travel getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Travel t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Travel t) {
		// TODO Auto-generated method stub
		
	}
}
