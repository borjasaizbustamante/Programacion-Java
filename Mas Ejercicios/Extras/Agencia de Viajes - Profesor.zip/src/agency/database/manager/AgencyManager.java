package agency.database.manager;

import java.util.List;

import agency.database.entity.Agency;

/**
 * Manager para la tabla Agency. Implementa el interfaz ManagerInterface
 */
public class AgencyManager extends ManagerAbstract implements ManagerInterface<Agency> {

	public Agency getAgency(String name, String pass) {

//		return null;
		return new Agency();
	}

	@Override
	public List<Agency> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Agency getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Agency t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Agency t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Agency t) {
		// TODO Auto-generated method stub
		
	}

}
