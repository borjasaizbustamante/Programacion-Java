package agency.database.manager;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import agency.database.entity.Event;
import agency.database.entity.Flight;
import agency.database.entity.Travel;
import agency.database.entity.Trip;
import agency.database.entity.enums.AirportType;
import agency.database.entity.enums.JourneyType;

/**
 * Manager para la tabla Flight. Implementa el interfaz ManagerInterface
 */
public class FlightManager extends ManagerAbstract implements ManagerInterface<Event> {

	public List<Event> getAll(Travel travel) {

		List<Event> ret = new ArrayList<>();

		if (travel.getId() == 0) {
			JourneyType journeyType = new JourneyType();
			journeyType.setId(0);
			journeyType.setText("Type 1");

			AirportType airportType = new AirportType();
			airportType.setId(0);
			airportType.setText("AT 1");

			Trip trip = new Trip();
			trip.setId(0);
			trip.setName("Trip 1");
			trip.setDate(new Date(new java.util.Date().getTime()));
			trip.setFlightCode("CD");
			trip.setAirline("AL");
			trip.setPrice(100);
			trip.setTime(new Date(new java.util.Date().getTime()));
			trip.setDuration(new Date(new java.util.Date().getTime()));

			Flight flight = new Flight();
			flight.setId(0);
			flight.setName("Fly 1");
			flight.setJourneyType(journeyType);
			flight.setOneWayAirport(airportType);
			flight.setRoundTripAirport(airportType);
			flight.setOneWayTrip(trip);
			flight.setRoundTrip(trip);
			
			ret.add(flight);
		} else {
			JourneyType journeyType = new JourneyType();
			journeyType.setId(0);
			journeyType.setText("Type 11");

			AirportType airportType = new AirportType();
			airportType.setId(0);
			airportType.setText("AT 11");

			Trip trip = new Trip();
			trip.setId(0);
			trip.setName("Trip 11");
			trip.setDate(new Date(new java.util.Date().getTime()));
			trip.setFlightCode("CD");
			trip.setAirline("AL");
			trip.setPrice(100);
			trip.setTime(new Date(new java.util.Date().getTime()));
			trip.setDuration(new Date(new java.util.Date().getTime()));

			Flight flight = new Flight();
			flight.setId(0);
			flight.setName("Fly 11");
			flight.setJourneyType(journeyType);
			flight.setOneWayAirport(airportType);
			flight.setRoundTripAirport(airportType);
			flight.setOneWayTrip(trip);
			flight.setRoundTrip(trip);
			
			ret.add(flight);
		}
		return ret;
	}

	@Override
	public List<Event> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Event getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Event t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Event t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Event t) {
		// TODO Auto-generated method stub
		
	}

}
