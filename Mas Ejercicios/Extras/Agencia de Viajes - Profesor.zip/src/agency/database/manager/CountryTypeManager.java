package agency.database.manager;

import java.util.ArrayList;

import java.util.List;

import agency.database.entity.enums.Country;

/**
 * Manager para la tabla CountryType. Implementa el interfaz ManagerInterface
 */
public class CountryTypeManager extends ManagerAbstract implements ManagerInterface<Country> {

	public List<Country> getAll() {

		List<Country> ret = new ArrayList<Country>();

		Country country1 = new Country();
		country1.setId(0);
		country1.setCode("Code 1");
		country1.setText("Text 1");

		Country country2 = new Country();
		country2.setId(1);
		country2.setCode("Code 2");
		country2.setText("Text 2");

		Country country3 = new Country();
		country3.setId(2);
		country3.setCode("Code 3");
		country3.setText("Text 3");

		ret.add(country1);
		ret.add(country2);
		ret.add(country3);

		return ret;
	}

	@Override
	public Country getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Country t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Country t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Country t) {
		// TODO Auto-generated method stub
		
	}

}
