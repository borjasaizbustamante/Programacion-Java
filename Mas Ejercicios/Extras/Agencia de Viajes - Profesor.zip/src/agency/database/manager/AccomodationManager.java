package agency.database.manager;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import agency.database.entity.Accomodation;
import agency.database.entity.Event;
import agency.database.entity.Travel;
import agency.database.entity.enums.RoomType;

/**
 * Manager para la tabla Accomodation. Implementa el interfaz ManagerInterface
 */
public class AccomodationManager extends ManagerAbstract implements ManagerInterface<Accomodation>{

	public List<Event> getAllAccomodations(Travel travel) {
		List<Event> ret = new ArrayList<>();

		if (travel.getId() == 0) {
			RoomType roomType = new RoomType();
			roomType.setId(0);
			roomType.setText("Type 1");

			Accomodation accomodation = new Accomodation();
			accomodation.setId(0);
			accomodation.setName("Acc 1");
			accomodation.setRoomType(roomType);
			accomodation.setCity("City 1");
			accomodation.setInitDate(new Date(new java.util.Date().getTime()));
			accomodation.setEndDate(new Date(new java.util.Date().getTime()));
			accomodation.setPrice(100);
			ret.add(accomodation);
		} else {
			RoomType roomType = new RoomType();
			roomType.setId(0);
			roomType.setText("Type 11");

			Accomodation accomodation = new Accomodation();
			accomodation.setId(0);
			accomodation.setName("Acc 11");
			accomodation.setRoomType(roomType);
			accomodation.setCity("City 11");
			accomodation.setInitDate(new Date(new java.util.Date().getTime()));
			accomodation.setEndDate(new Date(new java.util.Date().getTime()));
			accomodation.setPrice(100);
			ret.add(accomodation);
		}
		return ret;
	}

	@Override
	public List<Accomodation> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Accomodation getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Accomodation t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Accomodation t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Accomodation t) {
		// TODO Auto-generated method stub
		
	}

}
