package agency.database.manager;

import java.util.ArrayList;
import java.util.List;

import agency.database.DatabaseFactory;
import agency.database.entity.Event;
import agency.database.entity.Travel;

/**
 * Manager para la tabla Event. Implementa el interfaz ManagerInterface
 */
public class EventManager extends ManagerAbstract implements ManagerInterface<Event> {

	public List<Event> getAllEvents(Travel travel) {
		List<Event> ret = null;

		List<Event> flights = ((FlightManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.FLIGHT_MANAGER.value)).getAll(travel);
		if (flights != null) {
			ret = ret == null ? new ArrayList<Event>() : ret;
			ret.addAll(flights);
		}

		List<Event> accomodations = ((AccomodationManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.ACCOMODATION_MANAGER.value)).getAllAccomodations(travel);
		if (accomodations != null) {
			ret = ret == null ? new ArrayList<Event>() : ret;
			ret.addAll(accomodations);
		}

		List<Event> activities = ((ActivityManager) DatabaseFactory.getInstance()
				.getManager(DatabaseFactory.panelOptions.ACTIVITY_MANAGER.value)).getAllActivities(travel);
		if (activities != null) {
			ret = ret == null ? new ArrayList<Event>() : ret;
			ret.addAll(activities);
		}
		return ret;
	}

	@Override
	public List<Event> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Event getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Event t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Event t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Event t) {
		// TODO Auto-generated method stub
		
	}


}
