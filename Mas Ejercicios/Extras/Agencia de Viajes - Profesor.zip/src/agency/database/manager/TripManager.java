package agency.database.manager;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import agency.database.entity.Event;
import agency.database.entity.Flight;
import agency.database.entity.Trip;

/**
 * Manager para la tabla TripManager. Implementa el interfaz ManagerInterface
 */
public class TripManager extends ManagerAbstract implements ManagerInterface<Event> {

	public List<Event> getTrips(Flight flight) {
		List<Event> ret = new ArrayList<>();
		Trip trip = new Trip();
		trip.setId(0);
		trip.setName("Trip 1");
		trip.setDate(new Date(new java.util.Date().getTime()));
		trip.setFlightCode("CD");
		trip.setAirline("AL");
		trip.setPrice(100);
		trip.setTime(new Date(new java.util.Date().getTime()));
		trip.setDuration(new Date(new java.util.Date().getTime()));
		ret.add(trip);
		return ret;
	}

	@Override
	public List<Event> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Event getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Event t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Event t) {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(Event t) {
		// TODO Auto-generated method stub

	}

}
