package agency.database.manager;

/**
 * Una clase abstracta en Java es una clase que no se puede instanciar
 * directamente y que sirve como base para otras clases. Esta pensada
 * principalmente para que otras clases puedan heredar de ella. <br>
 * </br>
 * ManagerAbstract existe para que todos los Managers hereden de ella. En este
 * caso, se utiliza unicamente para que DataBaseFactory sea capaz de almacenar
 * en un Map cualquier tipo de Manager.
 */
public abstract class ManagerAbstract {

}
