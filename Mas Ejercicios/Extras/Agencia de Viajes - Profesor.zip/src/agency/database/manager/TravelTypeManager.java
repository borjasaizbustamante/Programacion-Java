package agency.database.manager;

import java.util.ArrayList;
import java.util.List;

import agency.database.entity.enums.TravelType;

/**
 * Manager para la tabla TypeManager. Implementa el interfaz ManagerInterface
 */
public class TravelTypeManager extends ManagerAbstract implements ManagerInterface<TravelType> {

	public List<TravelType> getAll() {
		
		List<TravelType> ret = new ArrayList<TravelType>();
		
		TravelType type1 = new TravelType();
		type1.setId(0);
		type1.setText("Type 1");
		
		TravelType type2 = new TravelType();
		type2.setId(1);
		type2.setText("Type 2");
		
		TravelType type3 = new TravelType();
		type3.setId(2);
		type3.setText("Type 3");
		
		ret.add(type1);
		ret.add(type2);
		ret.add(type3);
		
		return ret;
	}

	@Override
	public TravelType getByID(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(TravelType t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(TravelType t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(TravelType t) {
		// TODO Auto-generated method stub
		
	}

}
