package agency;

import agency.database.config.DataBaseConfig;
import agency.database.utils.DBUtils;
import agency.view.frame.Frame;

import java.awt.EventQueue;

/**
 * Clase principal de Agencia de Viajes
 */
public class AgencyMainLauncher {

	private AgencyMainLauncher() {
		DBUtils dBUtils = DBUtils.getInstance();
		dBUtils.setUrl(DataBaseConfig.getInstance().getProperty(DataBaseConfig.configOptions.DDBB_URL.value));
		dBUtils.setDriver(DataBaseConfig.getInstance().getProperty(DataBaseConfig.configOptions.DDBB_DRIVER.value));
		dBUtils.setUser(DataBaseConfig.getInstance().getProperty(DataBaseConfig.configOptions.DDBB_USER.value));
		dBUtils.setPass(DataBaseConfig.getInstance().getProperty(DataBaseConfig.configOptions.DDBB_PASS.value));
	}

	private void launch() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new Frame();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void main(String[] args) {
		try {
			new AgencyMainLauncher().launch();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println("Unexpected end of program");
		}
	}
}
