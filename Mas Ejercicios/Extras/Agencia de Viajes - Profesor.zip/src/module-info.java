@SuppressWarnings("all")
module Reto2_AgenciaDeViajes {
	requires java.sql;
	requires java.desktop;
	requires jdatepicker;
}