package plantilla.codigo.file;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import plantilla.codigo.database.pojo.AbstractPojo;

public abstract class MyGestorFicherosAbstract extends GestorFicherosAbstract {

	protected void escribir(List<AbstractPojo> pojos, String file, boolean append)
			throws FileNotFoundException, IOException {

		if (null != pojos && pojos.size() > 0) {

			escribir(pojos.get(0), file, false);

			List<AbstractPojo> pojos2 = pojos;
			pojos2.remove(0);

			for (AbstractPojo publicacion : pojos2) {
				escribir(publicacion, file, true);
			}
		}

	}

	protected void escribir(AbstractPojo pojo, String file, boolean append)
			throws FileNotFoundException, IOException {
		FileOutputStream fileOutputStream = null;
		ObjectOutputStream objectOutputStream = null;
		MyObjectOutputStream myObjectOutputStream = null;

		try {
			File myFile = new File(file);
			fileOutputStream = new FileOutputStream(myFile, append);
			if (fileIsEmpty(file)) {
				objectOutputStream = new ObjectOutputStream(fileOutputStream);
				objectOutputStream.writeObject(pojo);
				objectOutputStream.flush();
			} else {
				myObjectOutputStream = new MyObjectOutputStream(fileOutputStream);
				myObjectOutputStream.writeObject(pojo);
				myObjectOutputStream.flush();
			}

		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} finally {
			try {
				if (null != objectOutputStream)
					objectOutputStream.close();
			} catch (IOException e1) {
				throw e1;
			}
			try {
				if (null != myObjectOutputStream)
					myObjectOutputStream.close();
			} catch (IOException e1) {
				throw e1;
			}
			try {
				if (null != fileOutputStream)
					fileOutputStream.close();
			} catch (IOException e) {
				throw e;
			}
		}
	}

	protected List<AbstractPojo> leer(String file) throws FileNotFoundException, ClassNotFoundException, IOException {

		List<AbstractPojo> ret = null;
		FileInputStream fileInputStream = null;
		ObjectInputStream objectInputStream = null;

		try {

			fileInputStream = new FileInputStream(file);
			objectInputStream = new ObjectInputStream(fileInputStream);

			ret = new ArrayList<AbstractPojo>();
			try {
				for (;;) {
					ret.add((AbstractPojo) objectInputStream.readObject());
				}
			} catch (EOFException e) {

			}

		} catch (FileNotFoundException e) {
			throw e;
		} catch (IOException e) {
			throw e;
		} catch (ClassNotFoundException e) {
			throw e;
		} finally {
			try {
				if (null != objectInputStream)
					objectInputStream.close();
			} catch (IOException e1) {
				throw e1;
			}
			try {
				if (null != fileInputStream)
					fileInputStream.close();
			} catch (IOException e) {
				throw e;
			}
		}
		return ret;
	}

	protected void borrar (String file) {
		File myFile = new File(file);
		if (myFile.delete()) {
			System.out.println("Fichero " + myFile.getName() + " borrado");
		}
	}
}
