package plantilla.codigo.database.utils;

public class DBUtils {

	public static final String URL = "jdbc:mysql://localhost:3306/¿¿¿???";
	public static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String USER = "root";
	public static final String PASS = "";
	
}
