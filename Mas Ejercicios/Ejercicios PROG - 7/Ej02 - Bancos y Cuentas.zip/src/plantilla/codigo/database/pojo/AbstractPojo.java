package plantilla.codigo.database.pojo;

import java.io.Serializable;

public class AbstractPojo implements Serializable{

	private static final long serialVersionUID = -3499880184543486040L;

}
