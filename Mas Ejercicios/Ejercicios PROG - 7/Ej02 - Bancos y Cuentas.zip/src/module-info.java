/**
 * 
 */
/**
 * 
 */
module HerenciaFuncionalidad {
}