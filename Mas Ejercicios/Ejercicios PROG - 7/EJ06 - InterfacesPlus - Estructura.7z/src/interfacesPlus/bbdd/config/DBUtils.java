package interfacesPlus.bbdd.config;

/**
 * Data Base configuration properties
 */
public class DBUtils {

	public static final String url = null;
	public static final String driver = null;
	public static final String user = null;
	public static final String pass = null;
}
