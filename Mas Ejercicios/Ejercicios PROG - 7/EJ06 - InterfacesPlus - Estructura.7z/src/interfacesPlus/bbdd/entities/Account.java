package interfacesPlus.bbdd.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Account implements Serializable {

	private static final long serialVersionUID = 3872823845252646625L;

	private Integer id = null;
	private String login = null;
	private String pass = null;
	private Date creationDate = null;

	private User user = null;
	private List<Videogame> videogames = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Videogame> getVideogames() {
		return videogames;
	}

	public void setVideogames(List<Videogame> videogames) {
		this.videogames = videogames;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(creationDate, id, login, pass, user, videogames);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		return Objects.equals(creationDate, other.creationDate) && Objects.equals(id, other.id)
				&& Objects.equals(login, other.login) && Objects.equals(pass, other.pass)
				&& Objects.equals(user, other.user) && Objects.equals(videogames, other.videogames);
	}

	@Override
	public String toString() {
		return "Account [id=" + id + ", login=" + login + ", pass=" + pass + ", creationDate=" + creationDate
				+ ", user=" + user + ", videogames=" + videogames + "]";
	}

}
