package interfacesPlus.bbdd.entities;

import java.io.Serializable;
import java.util.Objects;

public class Moba extends Videogame implements Serializable {

	private static final long serialVersionUID = -3582102321815812655L;

	private Integer numPlayer = null;

	public Integer getNumPlayer() {
		return numPlayer;
	}

	public void setNumPlayer(Integer numPlayer) {
		this.numPlayer = numPlayer;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(numPlayer);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moba other = (Moba) obj;
		return Objects.equals(numPlayer, other.numPlayer);
	}

	@Override
	public String toString() {
		return super.toString() + "Moba [numPlayer=" + numPlayer + "]";
	}

}
