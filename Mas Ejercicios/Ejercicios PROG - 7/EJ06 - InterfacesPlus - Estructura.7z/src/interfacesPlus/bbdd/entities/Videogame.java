package interfacesPlus.bbdd.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

public abstract class Videogame implements Serializable {

	private static final long serialVersionUID = -4514291458326889747L;

	private Integer id = null;
	private String name = null;
	private Long price = null;
	private Date launchDate = null;
	private String designer = null;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public Date getLaunchDate() {
		return launchDate;
	}

	public void setLaunchDate(Date launchDate) {
		this.launchDate = launchDate;
	}

	public String getDesigner() {
		return designer;
	}

	public void setDesigner(String designer) {
		this.designer = designer;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(designer, id, launchDate, name, price);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Videogame other = (Videogame) obj;
		return Objects.equals(designer, other.designer) && Objects.equals(id, other.id)
				&& Objects.equals(launchDate, other.launchDate) && Objects.equals(name, other.name)
				&& Objects.equals(price, other.price);
	}

	@Override
	public String toString() {
		return "Videogame [id=" + id + ", name=" + name + ", price=" + price + ", launchDate=" + launchDate
				+ ", designer=" + designer + "]";
	}

}
