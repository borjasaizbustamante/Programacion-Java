package interfacesPlus.bbdd.entities;

import java.io.Serializable;
import java.util.Objects;

public class OpenWorld extends Videogame implements Serializable{

	private static final long serialVersionUID = 3486305610740171750L;
	
	private Integer numExpansions = null;

	public Integer getNumExpansions() {
		return numExpansions;
	}

	public void setNumExpansions(Integer numExpansions) {
		this.numExpansions = numExpansions;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(numExpansions);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		OpenWorld other = (OpenWorld) obj;
		return Objects.equals(numExpansions, other.numExpansions);
	}

	@Override
	public String toString() {
		return super.toString() + "OpenWorld [numExpansions=" + numExpansions + "]";
	}
	
}
