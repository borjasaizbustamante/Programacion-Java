package interfacesPlus.bbdd.entities;

import java.io.Serializable;

public class Shooter extends Videogame implements Serializable{

	private static final long serialVersionUID = -4076809017729018347L;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}

	@Override
	public String toString() {
		return super.toString() + "Shooter []";
	}

}
