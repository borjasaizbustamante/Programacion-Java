package interfacesPlus.bbdd.managers;

import java.util.List;

public interface ManagerInterface<T, K> {

	public List<T> findAll();

	public T findByID(K id);

	public T find(String descriptor);

	public void insert(T t);

	public void insert(List<T> t);
	
	public void update(T t);

	public void delete(T t);

	public void delete(List<T> t);

}
