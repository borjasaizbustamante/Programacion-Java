package interfacesPlus.bbdd.managers;

import java.util.List;

import interfacesPlus.bbdd.entities.Shooter;

public class ShooterManager implements ManagerInterface <Shooter, Integer>{

	@Override
	public List<Shooter> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shooter findByID(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shooter find(String descriptor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Shooter t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(List<Shooter> t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Shooter t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Shooter t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(List<Shooter> t) {
		// TODO Auto-generated method stub
		
	};

}
