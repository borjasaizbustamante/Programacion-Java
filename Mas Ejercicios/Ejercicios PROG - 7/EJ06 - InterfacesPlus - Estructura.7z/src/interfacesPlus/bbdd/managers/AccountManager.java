package interfacesPlus.bbdd.managers;

import java.util.List;

import interfacesPlus.bbdd.entities.Account;

public class AccountManager implements ManagerInterface <Account, Integer>{

	@Override
	public List<Account> findAll() {
		return null;
	}

	@Override
	public Account findByID(Integer id) {
		return null;
	}

	@Override
	public Account find(String descriptor) {
		return null;
	}

	@Override
	public void insert(Account t) {
	}

	@Override
	public void insert(List<Account> t) {
	}

	@Override
	public void update(Account t) {
	}

	@Override
	public void delete(Account t) {
	}

	@Override
	public void delete(List<Account> t) {
	}

}
