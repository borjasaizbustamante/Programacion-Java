package interfacesPlus.bbdd.managers;

import java.util.ArrayList;
import java.util.List;

import interfacesPlus.bbdd.entities.Moba;
import interfacesPlus.bbdd.entities.OpenWorld;
import interfacesPlus.bbdd.entities.Shooter;
import interfacesPlus.bbdd.entities.Videogame;

public class VideogameManager {

	public List<Videogame> findAll() {
		List<Videogame> ret = new ArrayList<Videogame>();

		List<Moba> mobas = (new MobaManager()).findAll();
		if (null != mobas) {
			ret.add((Videogame) mobas);
		}
		
		List<Shooter> shooters = (new ShooterManager()).findAll();
		if (null != shooters) {
			ret.add((Videogame) shooters);
		}
		
		List<OpenWorld> openWorlds = (new OpenWorldManager()).findAll();
		if (null != openWorlds) {
			ret.add((Videogame) openWorlds);
		}
		
		return ret == null? null : ret;
	}

}
