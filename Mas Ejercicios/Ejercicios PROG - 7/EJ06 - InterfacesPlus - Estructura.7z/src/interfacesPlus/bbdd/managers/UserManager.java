package interfacesPlus.bbdd.managers;

import java.util.List;

import interfacesPlus.bbdd.entities.User;

public class UserManager implements ManagerInterface <User, String>{

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User findByID(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User find(String descriptor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(User t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(List<User> t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(User t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(User t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(List<User> t) {
		// TODO Auto-generated method stub
		
	}

}
