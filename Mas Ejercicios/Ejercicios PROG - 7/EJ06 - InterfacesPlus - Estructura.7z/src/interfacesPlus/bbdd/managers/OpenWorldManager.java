package interfacesPlus.bbdd.managers;

import java.util.List;

import interfacesPlus.bbdd.entities.OpenWorld;

public class OpenWorldManager implements ManagerInterface <OpenWorld, Integer>{

	@Override
	public List<OpenWorld> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OpenWorld findByID(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OpenWorld find(String descriptor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(OpenWorld t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(List<OpenWorld> t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(OpenWorld t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(OpenWorld t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(List<OpenWorld> t) {
		// TODO Auto-generated method stub
		
	}

}
