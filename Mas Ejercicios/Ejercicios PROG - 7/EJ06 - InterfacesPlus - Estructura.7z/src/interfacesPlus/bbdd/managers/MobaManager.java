package interfacesPlus.bbdd.managers;

import java.util.List;

import interfacesPlus.bbdd.entities.Moba;

public class MobaManager implements ManagerInterface <Moba, Integer>{

	@Override
	public List<Moba> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Moba findByID(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Moba find(String descriptor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Moba t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(List<Moba> t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Moba t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Moba t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(List<Moba> t) {
		// TODO Auto-generated method stub
		
	}

}
