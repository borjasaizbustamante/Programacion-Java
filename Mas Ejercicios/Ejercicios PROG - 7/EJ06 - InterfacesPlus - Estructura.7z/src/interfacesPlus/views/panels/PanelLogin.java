package interfacesPlus.views.panels;

public class PanelLogin extends MyPanel{

	private static final long serialVersionUID = -5569210247878767243L;

}
