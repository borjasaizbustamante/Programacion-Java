package interfacesPlus.views.panels;

public class MainPanel extends MyPanel{

	private static final long serialVersionUID = 879661880304761194L;

}
