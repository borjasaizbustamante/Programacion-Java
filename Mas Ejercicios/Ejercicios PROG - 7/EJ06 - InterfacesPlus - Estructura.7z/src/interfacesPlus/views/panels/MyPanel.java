package interfacesPlus.views.panels;

import javax.swing.JPanel;

public abstract class MyPanel extends JPanel{

	private static final long serialVersionUID = 9193738730152702567L;

}
