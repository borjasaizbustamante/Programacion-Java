package interfacesPlus.views.panels;

public class ConfigPanel extends MyPanel{

	private static final long serialVersionUID = -2458314126385454861L;

}
