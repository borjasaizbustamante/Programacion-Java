package interfacesPlus.views;

import javax.swing.JFrame;

public class Window {

	private JFrame frmInterfacesPlus;

	public Window() {
		initialize();
	}

	private void initialize() {
		frmInterfacesPlus = new JFrame();
		frmInterfacesPlus.setTitle("Interfaces Plus");
		frmInterfacesPlus.setBounds(100, 100, 450, 300);
		frmInterfacesPlus.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmInterfacesPlus.getContentPane().setLayout(null);
	}

	public JFrame getFrame() {
		return frmInterfacesPlus;
	}

}
