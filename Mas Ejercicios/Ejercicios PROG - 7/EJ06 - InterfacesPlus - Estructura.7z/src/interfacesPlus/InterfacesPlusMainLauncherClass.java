package interfacesPlus;

import java.awt.EventQueue;
import java.util.List;

import interfacesPlus.bbdd.entities.Account;
import interfacesPlus.bbdd.entities.Moba;
import interfacesPlus.bbdd.entities.Shooter;
import interfacesPlus.bbdd.entities.Videogame;
import interfacesPlus.views.Window;

public class InterfacesPlusMainLauncherClass {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					(new Window()).getFrame().setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
//	public void a () {
//		
//		Moba moba = new Moba();
//		Shooter shooter = new Shooter();
//		
//		Account account = new Account ();
//		account.getVideogames().add(shooter);
//		account.getVideogames().add(moba);
//		
//		List<Videogame> list = account.getVideogames();
//
//		if (list.getFirst() instanceof Moba) {
//			Moba miMoba = (Moba) list.getFirst();
//		} else {
//			Shooter miShooter = (Shooter) list.getFirst();
//		}
//		
//		
//		
//		
//		
//		
//	}
}

