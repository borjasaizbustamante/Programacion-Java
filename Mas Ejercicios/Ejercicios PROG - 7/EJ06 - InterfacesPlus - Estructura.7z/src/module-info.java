/**
 * 
 */
/**
 * 
 */
module InterfacesPlus {
	requires java.desktop;
}