package gestorFicherosSencillo;

import gestorFicherosSencillo.gestor.Menu;

public class GestorFicherosSencillo {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.mostrarMenu();
	}
}
