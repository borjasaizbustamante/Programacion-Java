package gestorFicherosSencillo.gestor;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Menu {

	private Scanner teclado = null;
	private Gestor gestor = null;

	public Menu() {
		teclado = new Scanner(System.in);
		gestor = new Gestor();
	}

	private int escribirMenu() {
		int ret = 0;
		do {
			try {
				pintarMenu();
				System.out.print("Escoge una opcion: ");
				ret = teclado.nextInt();
				teclado.nextLine();
			} catch (Exception e) {
				System.out.println("Error!!! Opcion incorrecta");
				teclado.nextLine();
				ret = -1;
			}
		} while ((ret < 0) || (ret > 6));
		return ret;
	}

	private void pintarMenu() {
		System.out.println(" ");
		System.out.println("- Menu Inicial -");
		System.out.println("----------------");
		System.out.println("1. Escribir fichero");
		System.out.println("2. Mostrar todo el fichero");
		System.out.println("3. Aniadir al final");
		System.out.println("---");
		System.out.println("4. Buscar palabra");
		System.out.println("5. Eliminar fila");
		System.out.println("6. Contar filas");
		System.out.println("0. Salir");
		System.out.println(" ");
	}

	public void mostrarMenu() {
		int opcionMenu = 0;

		do {
			opcionMenu = escribirMenu();

			switch (opcionMenu) {
			case 0:
				System.out.println("Adios !!!");
				break;
			case 1:
				escribir();
				break;
			case 2:
				leer();
				break;
			case 3:
				actualizar();
				break;
			case 4:
				buscarPalabra();
				break;
			case 5:
				eliminarFilas();
				break;
			case 6:
				contarFilas();
				break;
			default:
				System.out.println("Esta opcion no deberia salir");
			}

		} while (opcionMenu != 0);

		teclado.close();
	}

	private void escribir() {
		String texto = leerDeTeclado();
		gestor.sobreescribirFichero(texto);
		System.out.println("Fichero escrito...");
	}

	private void leer() {
		String textoLeido = gestor.leerFichero();
		if (null != textoLeido)
			System.out.println("El contenido es: " + textoLeido);
	}

	private void actualizar() {
		String texto = leerDeTeclado();
		gestor.actualizarFichero(texto);
		System.out.println("Fichero actualizado...");
	}

	private void buscarPalabra() {
		System.out.println("Buscando palabras...");
		String palabra = leerDeTeclado();
		String textoLeido = gestor.leerFichero();

		// Obtenemos las frases del fichero
		List<String> frases = obtenerFrases(textoLeido);

		// Buscamos en cada frase la palabra a buscar...
		for (String frase : frases) {
			String found = buscar(palabra, frase);
			if (null != found) {
				System.out.println("Frase encontrada: " + found);
			}
		}
		System.out.println("Fin de la busqueda");
	}

	private List<String> obtenerFrases(String text) {
		List<String> ret = null != text ? new ArrayList<String>() : null;
		if (ret != null) {
			// Las diferentes "frases" nos vienen separadas por \n
			StringTokenizer stringTokenizer = new StringTokenizer(text, "\n", true);
			while (stringTokenizer.hasMoreTokens()) {
				ret.add(stringTokenizer.nextToken());
			}
		}
		return ret;
	}

	private String buscar(String palabra, String frase) {
		return frase.indexOf(palabra) > -1 ? frase : null;
	}

	private void eliminarFilas() {
		System.out.println("Buscando palabras...");
		String palabra = leerDeTeclado();
		String textoLeido = gestor.leerFichero();

		// Obtenemos las frases del fichero
		List<String> frases = obtenerFrases(textoLeido);

		// Buscamos en cada frase la palabra a buscar y eliminamos
		// las filas con la palabra buscada de la lista de frases
		List<String> foundList = new ArrayList<String>();
		for (String frase : frases) {
			String found = buscar(palabra, frase);
			if (null != found) {
				foundList.add(frase);
			}
		}
		frases.removeAll(foundList);

		// Sobreescribimos el fichero

		if (frases.size() == 0 || frases.get(0).equals("\n"))
			gestor.borrarFichero();
		else
			for (String frase : frases) {
				// No nos interesa meter el /n en el fichero
				if (!frase.equals("\n"))
					gestor.sobreescribirFichero(frase);
			}
	}

	private void contarFilas() {
		System.out.println("Buscando palabras...");
		String palabra = leerDeTeclado();
		String textoLeido = gestor.leerFichero();

		// Obtenemos las frases del fichero
		List<String> frases = obtenerFrases(textoLeido);

		// Buscamos en cada frase la palabra a buscar...
		int contador = 0;
		for (String frase : frases) {
			String found = buscar(palabra, frase);
			if (null != found) {
				contador++;
			}
		}
		System.out.println("Filas con la palabra " + palabra + ": " + contador);
		System.out.println("Fin de la busqueda");
	}

	private String leerDeTeclado() {
		String ret = null;
		System.out.print("Dame un texto: ");
		ret = teclado.nextLine();
		return ret;
	}
}
